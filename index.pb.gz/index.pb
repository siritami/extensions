
	KeiyoushiKEI@9add655a78e96c4ec7a53ef89dccb557cb5d767489fac5e785d671a5a75d4da2"<
https://keiyoushi.github.iohttps://discord.gg/3FbCpdKbdY���)
�
AHottie)eu.kanade.tachiyomi.extension.all.ahottie�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.ahottie-v1.4.3.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.ahottie.png"1.4(21.4.38B-�����WAHottieall"https://ahottie.top
�
Akuma'eu.kanade.tachiyomi.extension.all.akuma�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.akuma-v1.4.10.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.akuma.png"1.4(
21.4.108B)��������Akumaall"https://akuma.moeB(�����vAkumaen"https://akuma.moeB(���Ȋ���Akumaid"https://akuma.moeB(�蘫����5Akumajv"https://akuma.moeB(���ጆ��Akumaca"https://akuma.moeB)��ȿ����EAkumaceb"https://akuma.moeB(�䲾����7Akumacs"https://akuma.moeB(�ڦ���̍SAkumada"https://akuma.moeB(����팍�vAkumade"https://akuma.moeB(�������qAkumaet"https://akuma.moeB(�܊��JAkumaes"https://akuma.moeB(���񲃮�Akumaeo"https://akuma.moeB(����櫭�Akumafr"https://akuma.moeB(��ӡ���FAkumait"https://akuma.moeB(��������Akumahi"https://akuma.moeB(��㆏��Akumahu"https://akuma.moeB(�������MAkumanl"https://akuma.moeB(���ȓ��qAkumapl"https://akuma.moeB(��ѳ����HAkumapt"https://akuma.moeB(���ٵ�Akumavi"https://akuma.moeB(������&Akumatr"https://akuma.moeB(����Ѕ�aAkumaru"https://akuma.moeB(��������HAkumauk"https://akuma.moeB(����ދ�wAkumaar"https://akuma.moeB(��������sAkumako"https://akuma.moeB(�����ک�hAkumazh"https://akuma.moeB(�����ɚ�IAkumaja"https://akuma.moe
�
AllPornComics.co1eu.kanade.tachiyomi.extension.all.allporncomicsco�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.allporncomicsco-v1.4.50.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.allporncomicsco.png"1.4(221.4.508B;�����˨�XAllPornComics.coall"https://allporncomics.co
�
	AsmHentai+eu.kanade.tachiyomi.extension.all.asmhentai�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.asmhentai-v1.4.11.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.asmhentai.png"1.4(21.4.118B0�ڌ��˫�U	AsmHentaien"https://asmhentai.comB0��譫���k	AsmHentaija"https://asmhentai.comB0񨔴Ѻ��'	AsmHentaizh"https://asmhentai.comB1��֍��Ӈl	AsmHentaiall"https://asmhentai.com
�
BaoBua(eu.kanade.tachiyomi.extension.all.baobua�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.baobua-v1.4.6.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.baobua.png"1.4(21.4.68B+��ܰ�BaoBuaall"https://baobua.net
�%
XBatCat(eu.kanade.tachiyomi.extension.all.batoto�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.batoto-v1.4.61.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.batoto.png"1.4(=21.4.618B*��������>XBatCatall"https://xbat.appB)՘յ��ſmXBatCaten"https://xbat.appB)��ʦ����FXBatCatar"https://xbat.appB)����䕑�ZXBatCatbg"https://xbat.appB)��������+XBatCatzh"https://xbat.appB)���ほ�iXBatCatcs"https://xbat.appB)��������IXBatCatda"https://xbat.appB)ևҴ����"XBatCatnl"https://xbat.appB*��ڗ��XBatCatfil"https://xbat.appB)��݆��XBatCatfi"https://xbat.appB)λ�����PXBatCatfr"https://xbat.appB)�������XBatCatde"https://xbat.appB)��ٝ�¾�uXBatCatel"https://xbat.appB)�ӛ��͵!XBatCathe"https://xbat.appB)�ɱ����bXBatCathi"https://xbat.appB)��������>XBatCathu"https://xbat.appB)��Բ��XBatCatid"https://xbat.appB)��㫉��XBatCatit"https://xbat.appB)������ؚHXBatCatja"https://xbat.appB)��������tXBatCatko"https://xbat.appB)�����SXBatCatms"https://xbat.appB)ض����ǎ/XBatCatpl"https://xbat.appB)��������UXBatCatpt"https://xbat.appB,֖���0XBatCatpt-BR"https://xbat.appB)��������GXBatCatro"https://xbat.appB)�����ǻ�HXBatCatru"https://xbat.appB)�ẜɑ��VXBatCates"https://xbat.appB-�˸�����cXBatCates-419"https://xbat.appB)��؂����{XBatCatsv"https://xbat.appB)�ׂ�Կ��YXBatCattr"https://xbat.appB)��ɘ��XBatCatuk"https://xbat.appB)�܍�Ư��+XBatCatvi"https://xbat.appB)��۩����XBatCataf"https://xbat.appB)��ܤ��˃_XBatCatsq"https://xbat.appB)��������#XBatCatam"https://xbat.appB)������΂XBatCathy"https://xbat.appB)�º�����	XBatCataz"https://xbat.appB)�������dXBatCatbe"https://xbat.appB)��������/XBatCatbn"https://xbat.appB)��������_XBatCatbs"https://xbat.appB)ϸ��Σ��OXBatCatmy"https://xbat.appB)��麘��^XBatCatkm"https://xbat.appB)�������XBatCatca"https://xbat.appB*���ܿ�ӁQXBatCatceb"https://xbat.appB.�����멏'XBatCatzh-Hans"https://xbat.appB-�����ՉEXBatCatzh-Hant"https://xbat.appB)��������jXBatCathr"https://xbat.appB)����ی��)XBatCatet"https://xbat.appB)��뱌���jXBatCatfo"https://xbat.appB)����ې��QXBatCatka"https://xbat.appB)����ɐ��CXBatCatgn"https://xbat.appB)�������CXBatCatgu"https://xbat.appB)�������yXBatCatht"https://xbat.appB)ґ�����pXBatCatha"https://xbat.appB)ߒ��֒��#XBatCatis"https://xbat.appB)��������/XBatCatig"https://xbat.appB)�א���Ϻ3XBatCatga"https://xbat.appB)�ݙ�����_XBatCatjv"https://xbat.appB)�������XBatCatkn"https://xbat.appB)��������DXBatCatkk"https://xbat.appB)�����ǜRXBatCatku"https://xbat.appB)����ʡ��XBatCatky"https://xbat.appB)�����әXBatCatlo"https://xbat.appB)�ů�����gXBatCatlv"https://xbat.appB)���窟��(XBatCatlt"https://xbat.appB)���۱��oXBatCatlb"https://xbat.appB)������Ǯ>XBatCatmk"https://xbat.appB)ʟǏɠ��lXBatCatmg"https://xbat.appB)�����֔�/XBatCatml"https://xbat.appB)��������fXBatCatmt"https://xbat.appB)���Š͡�rXBatCatmi"https://xbat.appB)���ߵ���SXBatCatmr"https://xbat.appB)����؎{XBatCatmo"https://xbat.appB)������߭XBatCatmn"https://xbat.appB)�������XBatCatne"https://xbat.appB)������ܜ6XBatCatno"https://xbat.appB)��������OXBatCatny"https://xbat.appB)�ή����TXBatCatps"https://xbat.appB)�ן�����XBatCatfa"https://xbat.appB)��������sXBatCatrm"https://xbat.appB)˹������'XBatCatsm"https://xbat.appB)�������[XBatCatsr"https://xbat.appB)�������%XBatCatsh"https://xbat.appB)���ϼ���nXBatCatst"https://xbat.appB)������٭!XBatCatsn"https://xbat.appB)�Ȭ�����bXBatCatsd"https://xbat.appB)ڴ����(XBatCatsi"https://xbat.appB)��Ȁ����cXBatCatsk"https://xbat.appB)��������tXBatCatsl"https://xbat.appB)��܏����(XBatCatso"https://xbat.appB)��������XBatCatsw"https://xbat.appB)��ՠ����tXBatCattg"https://xbat.appB)᱊˂��uXBatCatta"https://xbat.appB)̑�꟭��XXBatCatte"https://xbat.appB)Ƈ�í���%XBatCatth"https://xbat.appB)�֊��⊊MXBatCatti"https://xbat.appB)ښ������!XBatCatto"https://xbat.appB)����ܲ��2XBatCattk"https://xbat.appB)˅�Ή���iXBatCatur"https://xbat.appB)���Ȝ���?XBatCatuz"https://xbat.appB)���苰��
XBatCatyo"https://xbat.appB)���σ���4XBatCatzu"https://xbat.appB,�˿�����XBatCatother"https://xbat.app
�&

Bato.to V4*eu.kanade.tachiyomi.extension.all.batotov4�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.batotov4-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.batotov4.png"1.4(21.4.28B,����߈�� 
Bato.to V4all"https://bato.siB+����ב��]
Bato.to V4en"https://bato.siB+�����銷
Bato.to V4ar"https://bato.siB+�������	
Bato.to V4bg"https://bato.siB+�ٛ۹㤞G
Bato.to V4zh"https://bato.siB+���꽔��:
Bato.to V4cs"https://bato.siB+׮�Ќ���O
Bato.to V4da"https://bato.siB+��������

Bato.to V4nl"https://bato.siB,����ϭ��4
Bato.to V4fil"https://bato.siB+��������	
Bato.to V4fi"https://bato.siB+�����ɋ#
Bato.to V4fr"https://bato.siB+�׾�����#
Bato.to V4de"https://bato.siB+�ˉ�����(
Bato.to V4el"https://bato.siB+����卝�W
Bato.to V4he"https://bato.siB+����Ņ��
Bato.to V4hi"https://bato.siB+�ĕ����D
Bato.to V4hu"https://bato.siB+���Π��
Bato.to V4id"https://bato.siB+��ˠ����t
Bato.to V4it"https://bato.siB+ಹ��
Bato.to V4ja"https://bato.siB+��������
Bato.to V4ko"https://bato.siB+��������Q
Bato.to V4ms"https://bato.siB+������4
Bato.to V4pl"https://bato.siB+��˅��Ǎy
Bato.to V4pt"https://bato.siB.�����կ�
Bato.to V4pt-BR"https://bato.siB+�Ї���7
Bato.to V4ro"https://bato.siB+󻭠�詆Y
Bato.to V4ru"https://bato.siB+»�҅���
Bato.to V4es"https://bato.siB/�ƶ��﬌8
Bato.to V4es-419"https://bato.siB+���ԃ���4
Bato.to V4sv"https://bato.siB+�������#
Bato.to V4tr"https://bato.siB+Ԑ������
Bato.to V4uk"https://bato.siB+�������U
Bato.to V4vi"https://bato.siB+�焁��
Bato.to V4af"https://bato.siB+����ޤf
Bato.to V4sq"https://bato.siB+��ڜה��P
Bato.to V4am"https://bato.siB+��������k
Bato.to V4hy"https://bato.siB+�Ĕ�����_
Bato.to V4az"https://bato.siB+��������I
Bato.to V4be"https://bato.siB+������)
Bato.to V4bn"https://bato.siB+Ι��鹘�q
Bato.to V4bs"https://bato.siB+�����غ�
Bato.to V4my"https://bato.siB+̢��餐�
Bato.to V4km"https://bato.siB+�ˋ����@
Bato.to V4ca"https://bato.siB,�ٝ�����e
Bato.to V4ceb"https://bato.siB0����ӎ��e
Bato.to V4zh-Hans"https://bato.siB0�ι�����
Bato.to V4zh-Hant"https://bato.siB+ɡ��ۘ��0
Bato.to V4hr"https://bato.siB+���إЇ�#
Bato.to V4et"https://bato.siB+��Ŧ���~
Bato.to V4fo"https://bato.siB+�������k
Bato.to V4ka"https://bato.siB+��ڈ����
Bato.to V4gn"https://bato.siB+���܍��h
Bato.to V4gu"https://bato.siB+�������
Bato.to V4ht"https://bato.siB+���ў暫
Bato.to V4ha"https://bato.siB+���̵��
Bato.to V4is"https://bato.siB+ޡɢ�l
Bato.to V4ig"https://bato.siB+ӣ����͓.
Bato.to V4ga"https://bato.siB+��̳����
Bato.to V4jv"https://bato.siB+���ćϟ�
Bato.to V4kn"https://bato.siB+�ƅ΂���d
Bato.to V4kk"https://bato.siB+�ᷨ���
Bato.to V4ku"https://bato.siB+�󥍐���%
Bato.to V4ky"https://bato.siB+�������J
Bato.to V4lo"https://bato.siB+΋�מ���
Bato.to V4lv"https://bato.siB+Ϫ˯����]
Bato.to V4lt"https://bato.siB+�����˗�R
Bato.to V4lb"https://bato.siB+ɇ��֎��$
Bato.to V4mk"https://bato.siB+��������-
Bato.to V4mg"https://bato.siB+���鐴��
Bato.to V4ml"https://bato.siB+��ߑ�㠉6
Bato.to V4mt"https://bato.siB+��������v
Bato.to V4mi"https://bato.siB+����귁n
Bato.to V4mr"https://bato.siB+��������Z
Bato.to V4mo"https://bato.siB+����ԇ��3
Bato.to V4mn"https://bato.siB+�愫����G
Bato.to V4ne"https://bato.siB+�̛�����$
Bato.to V4no"https://bato.siB+��Ѯن��x
Bato.to V4ny"https://bato.siB+�ج�����
Bato.to V4ps"https://bato.siB+�������m
Bato.to V4fa"https://bato.siB*�������T
Bato.to V4rm"https://bato.siB+����Α��P
Bato.to V4sm"https://bato.siB+�ȿ���[
Bato.to V4sr"https://bato.siB+����邳�
Bato.to V4sh"https://bato.siB+���뚰܏A
Bato.to V4st"https://bato.siB+�������"
Bato.to V4sn"https://bato.siB+��گ��
Bato.to V4sd"https://bato.siB+�����ά�Y
Bato.to V4si"https://bato.siB*������x
Bato.to V4sk"https://bato.siB+�����՗� 
Bato.to V4sl"https://bato.siB+�؟�����M
Bato.to V4so"https://bato.siB+��������c
Bato.to V4sw"https://bato.siB+���И���z
Bato.to V4tg"https://bato.siB+����ԅ��+
Bato.to V4ta"https://bato.siB+ǲ掭���
Bato.to V4te"https://bato.siB+Ɯ�ߢ��j
Bato.to V4th"https://bato.siB+�ܢཏ��`
Bato.to V4ti"https://bato.siB+�����ѽ�
Bato.to V4to"https://bato.siB+��٬���)
Bato.to V4tk"https://bato.siB+����ǟ�
Bato.to V4ur"https://bato.siB+ѯ������
Bato.to V4uz"https://bato.siB+ڙ�򓂞�
Bato.to V4yo"https://bato.siB+��ʮ����
Bato.to V4zu"https://bato.siB.����ˇ�y
Bato.to V4other"https://bato.si
�
3600000 Beauty/eu.kanade.tachiyomi.extension.all.beauty3600000�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.beauty3600000-v1.4.6.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.beauty3600000.png"1.4(21.4.68B4������ɦL3600000 Beautyall"https://3600000.xyz
�
Buon Dua)eu.kanade.tachiyomi.extension.all.buondua�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.buondua-v1.4.10.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.buondua.png"1.4(
21.4.108B.�����Ҡ�Buon Duaall"https://buondua.com
�

Comic Fury+eu.kanade.tachiyomi.extension.all.comicfury�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.comicfury-v1.4.8.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.comicfury.png"1.4(21.4.88B2�脲���G
Comic Furyall"https://comicfury.comB1�ɾӧ���V
Comic Furyen"https://comicfury.comB1����ྖE
Comic Furyes"https://comicfury.comB4�����ώx
Comic Furypt-BR"https://comicfury.comB1����ȼ��g
Comic Furyde"https://comicfury.comB1��џ����'
Comic Furyfr"https://comicfury.comB1��ơ����=
Comic Furyit"https://comicfury.comB1�Зќ���n
Comic Furypl"https://comicfury.comB1����ӎ��z
Comic Furyja"https://comicfury.comB1;������U
Comic Furyzh"https://comicfury.comB1������)
Comic Furyru"https://comicfury.comB1��������X
Comic Furyfi"https://comicfury.comB4�͍��̲�
Comic Furyother"https://comicfury.comB>�������#Comic Fury (No Text)other"https://comicfury.com
�
Comic Growl,eu.kanade.tachiyomi.extension.all.comicgrowl�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.comicgrowl-v1.4.11.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.comicgrowl.png"1.4(21.4.11B5�������Comic Growlall"https://comic-growl.com
�

Comick (Unoriginal),eu.kanade.tachiyomi.extension.all.comicklive�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.comicklive-v1.4.5.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.comicklive.png"1.4(21.4.58B8�����ځEComick (Unoriginal)en"https://comick.liveB8۔���ќ�Comick (Unoriginal)ru"https://comick.liveB8��������Comick (Unoriginal)vi"https://comick.liveB8�������0Comick (Unoriginal)fr"https://comick.liveB8�������FComick (Unoriginal)pl"https://comick.liveB8�͵�����|Comick (Unoriginal)id"https://comick.liveB8ӄ������nComick (Unoriginal)tr"https://comick.liveB8�כ؝���3Comick (Unoriginal)it"https://comick.liveB8���Ɵ���=Comick (Unoriginal)es"https://comick.liveB8ѭ��̹�KComick (Unoriginal)uk"https://comick.liveB8�񴧹�ˌ8Comick (Unoriginal)de"https://comick.liveB8������!Comick (Unoriginal)ko"https://comick.liveB8�����κ�Comick (Unoriginal)th"https://comick.liveB8�Ǵ�����9Comick (Unoriginal)ro"https://comick.liveB8�̊�����+Comick (Unoriginal)ms"https://comick.liveB8��������Comick (Unoriginal)ja"https://comick.liveB8ٗ����LComick (Unoriginal)sv"https://comick.liveB8���ĒŚ�'Comick (Unoriginal)no"https://comick.live
�
Comico(eu.kanade.tachiyomi.extension.all.comico�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.comico-v1.4.7.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.comico.png"1.4(21.4.78B;��Ϳ���BPOCKET COMICSen"https://www.pocketcomics.comB;�ĥ��݇YPOCKET COMICSzh"https://www.pocketcomics.comB0ȳ������E	コミコja"https://www.comico.jpB0��������k	코미코ko"https://www.comico.kr
�
ComicsKingdom/eu.kanade.tachiyomi.extension.all.comicskingdom�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.comicskingdom-v1.4.3.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.comicskingdom.png"1.4(21.4.3B<���Ӹ���.Comics Kingdomen"https://wp.comicskingdom.comB<����π��YComics Kingdomes"https://wp.comicskingdom.com
�
Comics Valley.eu.kanade.tachiyomi.extension.all.comicsvalley�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.comicsvalley-v1.4.52.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.comicsvalley.png"1.4(421.4.528B8�Ӫ���קComics Valleyall"https://comicsvalley.com
�
Comikey)eu.kanade.tachiyomi.extension.all.comikey�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.comikey-v1.4.7.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.comikey.png"1.4(21.4.7B,ͼ���֠�&Comikeyen"https://comikey.comB,ſ������Comikeyes"https://comikey.comB,�嗗����Comikeyid"https://comikey.comB/�������9Comikeypt-BR"https://comikey.comB9�����DComikey Brasilpt-BR"https://br.comikey.com
�
Commit Strip-eu.kanade.tachiyomi.extension.all.commitstrip�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.commitstrip-v1.4.4.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.commitstrip.png"1.4(21.4.4B9Ԓ������ICommit Stripen"https://www.commitstrip.comB9��ܠ�Ў:Commit Stripfr"https://www.commitstrip.com
�
Coomer(eu.kanade.tachiyomi.extension.all.coomer�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.coomer-v1.4.24.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.coomer.png"1.4(21.4.248B*�ƽ�����xCoomerall"https://coomer.st
�
	Corona EX*eu.kanade.tachiyomi.extension.all.coronaex�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.coronaex-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.coronaex.png"1.4(21.4.1B3����ԌňB	Corona EXja"https://to-corona-ex.comB6��媩��w	Corona EXen"https://en.to-corona-ex.com
�
CosplayTele-eu.kanade.tachiyomi.extension.all.cosplaytele�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.cosplaytele-v1.4.5.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.cosplaytele.png"1.4(21.4.58B5���Ǿ�fCosplayTeleall"https://cosplaytele.com
�
Cubari(eu.kanade.tachiyomi.extension.all.cubari�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.cubari-v1.4.26.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.cubari.png"1.4(21.4.26B*Ց�ݘ���WCubarien"https://cubari.moeB+��ಓ��Cubariall"https://cubari.moeB-�͙�в��Cubariother"https://cubari.moe
�
Danbooru*eu.kanade.tachiyomi.extension.all.danbooru�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.danbooru-v1.4.3.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.danbooru.png"1.4(21.4.38B5��������iDanbooruall"https://danbooru.donmai.us
�

DeviantArt,eu.kanade.tachiyomi.extension.all.deviantart�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.deviantart-v1.4.10.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.deviantart.png"1.4(
21.4.108B7΋�̿���H
DeviantArtall"https://www.deviantart.com
�
Dragon Ball Multiverse6eu.kanade.tachiyomi.extension.all.dragonballmultiverse�
xhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.dragonballmultiverse-v1.4.8.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.dragonballmultiverse.png"1.4(21.4.8BM����آРQDragon Ball Multiverseen"%https://www.dragonball-multiverse.comBM����׆��nDragon Ball Multiversefr"%https://www.dragonball-multiverse.comBM���ך���Dragon Ball Multiverseja"%https://www.dragonball-multiverse.comBM���⭁��DDragon Ball Multiversezh"%https://www.dragonball-multiverse.comBM��������&Dragon Ball Multiversees"%https://www.dragonball-multiverse.comBMƭ������pDragon Ball Multiverseit"%https://www.dragonball-multiverse.comBM���Ѽܘ�LDragon Ball Multiversept"%https://www.dragonball-multiverse.comBM����̛�iDragon Ball Multiversede"%https://www.dragonball-multiverse.comBM������tDragon Ball Multiversepl"%https://www.dragonball-multiverse.comBM��᧷¾EDragon Ball Multiversenl"%https://www.dragonball-multiverse.comBT��ӏ���MDragon Ball Multiverse Parodyfr"%https://www.dragonball-multiverse.comBM��ݓ����gDragon Ball Multiversetr"%https://www.dragonball-multiverse.comBP�֗�ߺDragon Ball Multiversept-BR"%https://www.dragonball-multiverse.comBM������ХDragon Ball Multiversehu"%https://www.dragonball-multiverse.comBM���랻��ADragon Ball Multiversega"%https://www.dragonball-multiverse.comBM�������zDragon Ball Multiverseca"%https://www.dragonball-multiverse.comBM��Ћ╯�_Dragon Ball Multiverseno"%https://www.dragonball-multiverse.comBM����즽�nDragon Ball Multiverseru"%https://www.dragonball-multiverse.comBM����ޮ$Dragon Ball Multiversero"%https://www.dragonball-multiverse.comBM���ڊ���RDragon Ball Multiverseeu"%https://www.dragonball-multiverse.comBM�߀Ϗ��ODragon Ball Multiverselt"%https://www.dragonball-multiverse.comBM��ة����|Dragon Ball Multiversehr"%https://www.dragonball-multiverse.comBM��������Dragon Ball Multiverseko"%https://www.dragonball-multiverse.comBM����ٴ��+Dragon Ball Multiversefi"%https://www.dragonball-multiverse.comBM������GDragon Ball Multiversehe"%https://www.dragonball-multiverse.comBM���Ʈ���CDragon Ball Multiversebg"%https://www.dragonball-multiverse.comBM��������Dragon Ball Multiversesv"%https://www.dragonball-multiverse.comBM��������Dragon Ball Multiverseel"%https://www.dragonball-multiverse.comBQ�ؔ�����9Dragon Ball Multiversees-419"%https://www.dragonball-multiverse.comBM�ԡ�����3Dragon Ball Multiversear"%https://www.dragonball-multiverse.comBN�������,Dragon Ball Multiversefil"%https://www.dragonball-multiverse.comBM�µ�����8Dragon Ball Multiversela"%https://www.dragonball-multiverse.comBM���ϋ���+Dragon Ball Multiverseda"%https://www.dragonball-multiverse.comBM���猋��vDragon Ball Multiverseco"%https://www.dragonball-multiverse.comBM��ó��ެDragon Ball Multiversebr"%https://www.dragonball-multiverse.comBN���̀���^Dragon Ball Multiversevec"%https://www.dragonball-multiverse.comBN����Ƣ��zDragon Ball Multiverselmo"%https://www.dragonball-multiverse.com
�
e621&eu.kanade.tachiyomi.extension.all.e621�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.e621-v1.4.2.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.e621.png"1.4(21.4.28B'�嶱����1e621all"https://e621.net
�
E-Hentai)eu.kanade.tachiyomi.extension.all.ehentai�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.ehentai-v1.4.27.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.ehentai.png"1.4(21.4.278B.�և���͵pE-Hentaija"https://e-hentai.orgB-����Ҟ�eE-Hentaien"https://e-hentai.orgB.�������@E-Hentaizh"https://e-hentai.orgB.���𓁾�E-Hentainl"https://e-hentai.orgB.ɢ��̆��6E-Hentaifr"https://e-hentai.orgB.�͘�찎�<E-Hentaide"https://e-hentai.orgB.��������
E-Hentaihu"https://e-hentai.orgB.ޙ������OE-Hentaiit"https://e-hentai.orgB.���ޮ��E-Hentaiko"https://e-hentai.orgB.ت��ٓ��TE-Hentaipl"https://e-hentai.orgB1�ϐ����cE-Hentaipt-BR"https://e-hentai.orgB.���㻡�E-Hentairu"https://e-hentai.orgB.զ�Ɩϋ*E-Hentaies"https://e-hentai.orgB.�䪝����RE-Hentaith"https://e-hentai.orgB.����褤TE-Hentaivi"https://e-hentai.orgB0�ɩ��ũ�LE-Hentainone"https://e-hentai.orgB1�옼��כUE-Hentaiother"https://e-hentai.org
�
Elite Babes,eu.kanade.tachiyomi.extension.all.elitebabes�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.elitebabes-v1.4.2.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.elitebabes.png"1.4(21.4.28B8������^Elite Babesall"https://www.elitebabes.com
�
Everia.club,eu.kanade.tachiyomi.extension.all.everiaclub�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.everiaclub-v1.4.12.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.everiaclub.png"1.4(21.4.128B1����ծ��jEveria.cluball"https://everia.club
�
EveriaClub (unoriginal)/eu.kanade.tachiyomi.extension.all.everiaclubcom�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.everiaclubcom-v1.4.1.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.everiaclubcom.png"1.4(21.4.18BD���ج���xEveriaClub (unoriginal)all"https://www.everiaclub.com
�
Femjoy Hunter.eu.kanade.tachiyomi.extension.all.femjoyhunter�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.femjoyhunter-v1.4.2.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.femjoyhunter.png"1.4(21.4.28B<ё�����Femjoy Hunterall"https://www.femjoyhunter.com
�
FoamGirl*eu.kanade.tachiyomi.extension.all.foamgirl�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.foamgirl-v1.4.5.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.foamgirl.png"1.4(21.4.58B/����켸�QFoamGirlall"https://foamgirl.net
�
FoolSlide Customizable7eu.kanade.tachiyomi.extension.all.foolslidecustomizable�
yhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.foolslidecustomizable-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.foolslidecustomizable.png"1.4(21.4.5B<������ޑXFoolSlide Customizableother"https://127.0.0.1
�
4KHD)eu.kanade.tachiyomi.extension.all.fourkhd�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.fourkhd-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.fourkhd.png"1.4(21.4.28B+�ϑ�����Z4KHDall"https://www.4khd.com
�

FTV Hunter+eu.kanade.tachiyomi.extension.all.ftvhunter�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.ftvhunter-v1.4.2.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.ftvhunter.png"1.4(21.4.28B6֌������!
FTV Hunterall"https://www.ftvhunter.com
�
GlobalComix-eu.kanade.tachiyomi.extension.all.globalcomix�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.globalcomix-v1.4.4.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.globalcomix.png"1.4(21.4.48B4������.GlobalComixsq"https://globalcomix.comB4�����GlobalComixar"https://globalcomix.comB4�������^GlobalComixbg"https://globalcomix.comB4��������GlobalComixbn"https://globalcomix.comB7�����Ɣ_GlobalComixpt-BR"https://globalcomix.comB9ϩ���ވ�cGlobalComixzh-Hans"https://globalcomix.comB4����Տ��?GlobalComixcs"https://globalcomix.comB4�����۸rGlobalComixde"https://globalcomix.comB4���ՇFGlobalComixda"https://globalcomix.comB4���҉���EGlobalComixel"https://globalcomix.comB4���Е���GlobalComixen"https://globalcomix.comB4���뷻��CGlobalComixes"https://globalcomix.comB4��١����*GlobalComixfa"https://globalcomix.comB4��蠰�ٌsGlobalComixfi"https://globalcomix.comB5����դ��cGlobalComixfil"https://globalcomix.comB4ރ览���GlobalComixfr"https://globalcomix.comB4Ä������lGlobalComixhi"https://globalcomix.comB4�ũ����GlobalComixhu"https://globalcomix.comB4��������PGlobalComixid"https://globalcomix.comB4ʎ؅�ѥ�	GlobalComixit"https://globalcomix.comB4������DGlobalComixhe"https://globalcomix.comB4������HGlobalComixja"https://globalcomix.comB4Ͳ������bGlobalComixko"https://globalcomix.comB4ߓ�����GlobalComixlv"https://globalcomix.comB4������ӑ8GlobalComixms"https://globalcomix.comB4������xGlobalComixnl"https://globalcomix.comB4�����ٖ�GlobalComixno"https://globalcomix.comB4��������}GlobalComixpl"https://globalcomix.comB4�Ý�ӣ��GlobalComixpt"https://globalcomix.comB4�����צ�GlobalComixro"https://globalcomix.comB4����Ѭ��wGlobalComixru"https://globalcomix.comB4��嬩౲2GlobalComixsv"https://globalcomix.comB4��Ļ;��-GlobalComixsk"https://globalcomix.comB4�۴�����GlobalComixsl"https://globalcomix.comB4��������LGlobalComixta"https://globalcomix.comB4�Կ����mGlobalComixth"https://globalcomix.comB4ߠ�����$GlobalComixtr"https://globalcomix.comB4��������GlobalComixuk"https://globalcomix.comB4��מ��GlobalComixur"https://globalcomix.comB4���ு��`GlobalComixvi"https://globalcomix.comB9����/GlobalComixzh-Hant"https://globalcomix.com
�
Grabber Zone-eu.kanade.tachiyomi.extension.all.grabberzone�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.grabberzone-v1.4.50.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.grabberzone.png"1.4(221.4.50B3ɹ��칤�aGrabber Zoneall"https://grabber.zone
�
HDoujin)eu.kanade.tachiyomi.extension.all.hdoujin�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.hdoujin-v1.4.4.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hdoujin.png"1.4(21.4.48B-Λ��ݦ��HDoujinall"https://hdoujin.orgB,��ѡ���3HDoujinen"https://hdoujin.orgB,ǁ������[HDoujines"https://hdoujin.orgB,�ݟ��О@HDoujinja"https://hdoujin.orgB,�Ǭ�ڸ�tHDoujinko"https://hdoujin.orgB,����Ɲ��$HDoujinzh"https://hdoujin.org
�
Hennojin*eu.kanade.tachiyomi.extension.all.hennojin�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.hennojin-v1.4.3.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hennojin.png"1.4(21.4.38B.�у�����"Hennojinen"https://hennojin.comB.��������]Hennojinja"https://hennojin.com
�
3Hentai)eu.kanade.tachiyomi.extension.all.hentai3�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.hentai3-v1.4.3.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hentai3.png"1.4(21.4.38B-�����͞�_3Hentaiall"https://3hentai.netB,�ܭ⋊��l3Hentaien"https://3hentai.netB,��ѯ����'3Hentaija"https://3hentai.netB,��������3Hentaiko"https://3hentai.netB,��������V3Hentaizh"https://3hentai.netB,���Ƨ���w3Hentaimo"https://3hentai.netB,�������3Hentaies"https://3hentai.netB,���Љ���3Hentaipt"https://3hentai.netB+᷾�宅X3Hentaiid"https://3hentai.netB,�����¶�i3Hentaijv"https://3hentai.netB,�������63Hentaitl"https://3hentai.netB,�ԝ¾���T3Hentaivi"https://3hentai.netB,����ɖ�*3Hentaith"https://3hentai.netB,��ԗ���03Hentaimy"https://3hentai.netB,��������3Hentaitr"https://3hentai.netB,�������D3Hentairu"https://3hentai.netB,��֕�س�03Hentaiuk"https://3hentai.netB,����܄��n3Hentaipl"https://3hentai.netB,���ϥ��	3Hentaifi"https://3hentai.netB,��ƅܫ��a3Hentaide"https://3hentai.netB,�������3Hentaiit"https://3hentai.netB,��������;3Hentaifr"https://3hentai.netB,�������j3Hentainl"https://3hentai.netB,����䕽�53Hentaics"https://3hentai.netB,�������w3Hentaihu"https://3hentai.netB,���ğ��3Hentaibg"https://3hentai.netB,��������{3Hentaiis"https://3hentai.netB,�����忷E3Hentaila"https://3hentai.netB,�������3Hentaiar"https://3hentai.net
�
Hentai Cosplay/eu.kanade.tachiyomi.extension.all.hentaicosplay�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.hentaicosplay-v1.4.8.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hentaicosplay.png"1.4(21.4.88B?Ŝ��֋¿/Hentai Cosplayall"https://hentai-cosplay-xxx.com
�

HentaiEnvy,eu.kanade.tachiyomi.extension.all.hentaienvy�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.hentaienvy-v1.4.9.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hentaienvy.png"1.4(	21.4.98B2�掕��݄p
HentaiEnvyen"https://hentaienvy.comB2��ߔ�̍�n
HentaiEnvyja"https://hentaienvy.comB2��ڎ���
HentaiEnvyes"https://hentaienvy.comB2��������
HentaiEnvyfr"https://hentaienvy.comB2�����Ǐ�$
HentaiEnvyko"https://hentaienvy.comB2��Ϭ�"
HentaiEnvyde"https://hentaienvy.comB2���袃�\
HentaiEnvyru"https://hentaienvy.comB3��������
HentaiEnvyall"https://hentaienvy.com
�
	HentaiEra+eu.kanade.tachiyomi.extension.all.hentaiera�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.hentaiera-v1.4.11.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hentaiera.png"1.4(21.4.118B0�����ҷ�	HentaiEraen"https://hentaiera.comB0������"	HentaiEraja"https://hentaiera.comB0͵��̛��	HentaiEraes"https://hentaiera.comB0��ݬ���_	HentaiErafr"https://hentaiera.comB0��������R	HentaiErako"https://hentaiera.comB0���؜���	HentaiErade"https://hentaiera.comB0�ݏ�����D	HentaiEraru"https://hentaiera.comB1�������H	HentaiEraall"https://hentaiera.com
�
	HentaiFox+eu.kanade.tachiyomi.extension.all.hentaifox�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.hentaifox-v1.4.16.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hentaifox.png"1.4(21.4.168B0䃇��ɛ�n	HentaiFoxen"https://hentaifox.comB0����䭊�w	HentaiFoxja"https://hentaifox.comB0��쬂��-	HentaiFoxzh"https://hentaifox.comB0�����ō�	HentaiFoxko"https://hentaifox.comB1���䖦�%	HentaiFoxall"https://hentaifox.com
�

HentaiHand,eu.kanade.tachiyomi.extension.all.hentaihand�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.hentaihand-v1.4.10.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hentaihand.png"1.4(
21.4.108B3�������
HentaiHandall"https://hentaihand.comB2����֡��
HentaiHanden"https://hentaihand.comB2�����ǂ
HentaiHandzh"https://hentaihand.comB2��޲��ˤE
HentaiHandja"https://hentaihand.comB5��������e
HentaiHandother"https://hentaihand.comB2��������U
HentaiHandeo"https://hentaihand.comB3��������
HentaiHandceb"https://hentaihand.comB2��������^
HentaiHandcs"https://hentaihand.comB2��ި�� L
HentaiHandar"https://hentaihand.comB2أ���1
HentaiHandsk"https://hentaihand.comB2���د���:
HentaiHandmn"https://hentaihand.comB2����☒�
HentaiHanduk"https://hentaihand.comB2�������*
HentaiHandla"https://hentaihand.comB2��������q
HentaiHandtl"https://hentaihand.comB2��������
HentaiHandes"https://hentaihand.comB2���ɮ���r
HentaiHandit"https://hentaihand.comB2�ؤ����&
HentaiHandko"https://hentaihand.comB2�ꆭ�
HentaiHandth"https://hentaihand.comB2������U
HentaiHandpl"https://hentaihand.comB2��������
HentaiHandfr"https://hentaihand.comB5��ԃ����"
HentaiHandpt-BR"https://hentaihand.comB2�����翘s
HentaiHandde"https://hentaihand.comB2�����צ�C
HentaiHandfi"https://hentaihand.comB2��쟴�ݩP
HentaiHandru"https://hentaihand.comB2�絝����Z
HentaiHandhu"https://hentaihand.comB2��������
HentaiHandid"https://hentaihand.comB2�᬴�Ҫ�
HentaiHandvi"https://hentaihand.comB2्��ې�m
HentaiHandnl"https://hentaihand.comB2��������
HentaiHandhi"https://hentaihand.comB2����䄿W
HentaiHandtr"https://hentaihand.comB2���˰�~
HentaiHandel"https://hentaihand.comB2�毝���
HentaiHandsr"https://hentaihand.comB2�����ϸq
HentaiHandjv"https://hentaihand.comB2���ɶ���h
HentaiHandbg"https://hentaihand.com
�
	HentaiRox+eu.kanade.tachiyomi.extension.all.hentairox�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.hentairox-v1.4.9.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hentairox.png"1.4(	21.4.98B0ʕ������&	HentaiRoxen"https://hentairox.comB0��������	HentaiRoxja"https://hentairox.comB0��ޜ��/	HentaiRoxzh"https://hentairox.comB1��ĕ����-	HentaiRoxall"https://hentairox.com
�
	HentaiZap+eu.kanade.tachiyomi.extension.all.hentaizap�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.hentaizap-v1.4.9.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hentaizap.png"1.4(	21.4.98B0➞����*	HentaiZapen"https://hentaizap.comB0������Z	HentaiZapja"https://hentaizap.comB0��������B	HentaiZapes"https://hentaizap.comB0��������m	HentaiZapfr"https://hentaizap.comB0��������	HentaiZapko"https://hentaizap.comB0�ϯ��Ԉ�	HentaiZapde"https://hentaizap.comB0���٘���[	HentaiZapru"https://hentaizap.comB1�І�����	HentaiZapall"https://hentaizap.com
�
Hitomi(eu.kanade.tachiyomi.extension.all.hitomi�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.hitomi-v1.4.41.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hitomi.png"1.4()21.4.418B*񼐏����	Hitomiall"https://hitomi.laB)�혷����yHitomien"https://hitomi.laB)��������Hitomiid"https://hitomi.laB)�З�����ZHitomijv"https://hitomi.laB)ݰ�Յ���ZHitomica"https://hitomi.laB*�ِ�����9Hitomiceb"https://hitomi.laB)񹆄����VHitomics"https://hitomi.laB)��ڇ����Hitomida"https://hitomi.laB)�������0Hitomide"https://hitomi.laB)��������+Hitomiet"https://hitomi.laB)���՛���@Hitomies"https://hitomi.laB)�抁����&Hitomieo"https://hitomi.laB)����矷�"Hitomifr"https://hitomi.laB)ȟ���Ԫ�_Hitomiit"https://hitomi.laB)�������Hitomihi"https://hitomi.laB)���Р��RHitomihu"https://hitomi.laB)С��꒻�
Hitomipl"https://hitomi.laB)�����JHitomipt"https://hitomi.laB)�ǜ�����4Hitomivi"https://hitomi.laB)��ް���JHitomitr"https://hitomi.laB)꙰�����6Hitomiru"https://hitomi.laB)��������8Hitomiuk"https://hitomi.laB)�է��ޙ�^Hitomiar"https://hitomi.laB)��齓���}Hitomiko"https://hitomi.laB)�����ߗ�Hitomizh"https://hitomi.laB)�ެ����cHitomija"https://hitomi.la
�
HNI-Scantrad-eu.kanade.tachiyomi.extension.all.hniscantrad�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.hniscantrad-v1.4.9.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hniscantrad.png"1.4(	21.4.9B7��������EHNI-Scantradall"https://hni-scantrad.net
�
HOLONOMETRIA.eu.kanade.tachiyomi.extension.all.holonometria�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.holonometria-v1.4.4.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.holonometria.png"1.4(21.4.4B3�茿���yHOLONOMETRIAja"https://holoearth.comB3��������HOLONOMETRIAen"https://holoearth.comB3��ƀ΍��FHOLONOMETRIAid"https://holoearth.com
�
	Honeytoon+eu.kanade.tachiyomi.extension.all.honeytoon�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.honeytoon-v1.4.2.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.honeytoon.png"1.4(21.4.28B0�����җ�w	Honeytoonde"https://honeytoon.comB0�������	Honeytoonen"https://honeytoon.comB0�������L	Honeytoones"https://honeytoon.comB0�ʭ��ܟ�[	Honeytoonfr"https://honeytoon.comB0��������}	Honeytoonit"https://honeytoon.comB3�ݠ�����g	Honeytoonpt-BR"https://honeytoon.com
�
IMHentai*eu.kanade.tachiyomi.extension.all.imhentai�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.imhentai-v1.4.24.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.imhentai.png"1.4(21.4.248B.�������IMHentaien"https://imhentai.xxxB.��롈���'IMHentaija"https://imhentai.xxxB.�ŀ����IMHentaies"https://imhentai.xxxB.���̻ZIMHentaifr"https://imhentai.xxxB.ؽ�ڧ�ԜIMHentaiko"https://imhentai.xxxB.�る����IMHentaide"https://imhentai.xxxB.������єhIMHentairu"https://imhentai.xxxB/������Ə/IMHentaiall"https://imhentai.xxx
�
izneo (webtoons)'eu.kanade.tachiyomi.extension.all.izneo�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.izneo-v1.4.8.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.izneo.png"1.4(21.4.8B7ÿ���꠰cizneoen" https://www.izneo.com/en/webtoonB7������izneofr" https://www.izneo.com/fr/webtoon
�
JJCOS'eu.kanade.tachiyomi.extension.all.jjcos�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.jjcos-v1.4.1.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.jjcos.png"1.4(21.4.18B)�����OJJCOSall"https://jjcos.com
�

Joymii Hub+eu.kanade.tachiyomi.extension.all.joymiihub�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.joymiihub-v1.4.2.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.joymiihub.png"1.4(21.4.28B6���濲��t
Joymii Huball"https://www.joymiihub.com
�
Junmeitu*eu.kanade.tachiyomi.extension.all.junmeitu�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.junmeitu-v1.4.7.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.junmeitu.png"1.4(21.4.78B/쒍�����AJunmeituall"https://meijuntu.com
�
Kagane(eu.kanade.tachiyomi.extension.all.kagane�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.kagane-v1.4.26.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.kagane.png"1.4(21.4.268B)�չ����7Kaganeen"https://kagane.toB)�퐿����Kaganeja"https://kagane.toB)��������Kaganeko"https://kagane.toB)��к����Kaganezh"https://kagane.toB)�������WKaganees"https://kagane.toB-������׋-Kaganees-419"https://kagane.toB)դ���ʧ�TKaganefr"https://kagane.toB)�ս�ڥ��Kaganede"https://kagane.toB)��������-Kaganept"https://kagane.toB,�ݩ�����{Kaganept-BR"https://kagane.toB)�ㄒ��yKaganeru"https://kagane.toB)��������Kaganeit"https://kagane.toB)������jKaganeid"https://kagane.toB)���鋑ׁzKaganevi"https://kagane.toB)�ӳ�����Kaganeth"https://kagane.toB)��Г�џ�Kaganepl"https://kagane.toB)�����ײ�}Kaganehi"https://kagane.toB)�����ʍmKaganear"https://kagane.to
�
Kanjiku)eu.kanade.tachiyomi.extension.all.kanjiku�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.kanjiku-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.kanjiku.png"1.4(21.4.1B,������{Kanjikude"https://kanjiku.netB0��᫾ߞ�BKanjikuen"https://eng.kanjiku.net
�
Kemono(eu.kanade.tachiyomi.extension.all.kemono�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.kemono-v1.4.25.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.kemono.png"1.4(21.4.258B*��������Kemonoall"https://kemono.cr
�
Kiutaku)eu.kanade.tachiyomi.extension.all.kiutaku�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.kiutaku-v1.4.6.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.kiutaku.png"1.4(21.4.68B-�Щ�����*Kiutakuall"https://kiutaku.com
�
Kodoku Studio.eu.kanade.tachiyomi.extension.all.kodokustudio�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.kodokustudio-v1.4.50.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.kodokustudio.png"1.4(221.4.50B8�����Kodoku Studioall"https://kodokustudio.com
�
SchaleNetwork(eu.kanade.tachiyomi.extension.all.koharu�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.koharu-v1.4.20.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.koharu.png"1.4(21.4.208B6�����ߏ�	SchaleNetworkall"https://schale.networkB5���͉���SchaleNetworken"https://schale.networkB5��������vSchaleNetworkja"https://schale.networkB5����ψ��zSchaleNetworkzh"https://schale.network
�
Komga'eu.kanade.tachiyomi.extension.all.komga�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.komga-v1.4.65.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.komga.png"1.4(A21.4.65BЧ����>KomgaallB����Ǻ��p	Komga (2)allB��ۖ��ڝG	Komga (3)all
�
	LANraragi+eu.kanade.tachiyomi.extension.all.lanraragi�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.lanraragi-v1.4.21.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.lanraragi.png"1.4(21.4.21B5����惾�>LANraragi (1)all"http://127.0.0.1:3000B5�����ә�ULANraragi (2)all"http://127.0.0.1:3000
�
League of Legends1eu.kanade.tachiyomi.extension.all.leagueoflegends�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.leagueoflegends-v1.4.2.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.leagueoflegends.png"1.4(21.4.2BTَ���駞KLeague of Legendsen"1https://universe.leagueoflegends.com/en_us/comic/BT���ۇ��League of Legendsde"1https://universe.leagueoflegends.com/de_de/comic/BT��������"League of Legendses"1https://universe.leagueoflegends.com/es_es/comic/BT�罷�؛�{League of Legendsfr"1https://universe.leagueoflegends.com/fr_fr/comic/BT��ќ����)League of Legendsit"1https://universe.leagueoflegends.com/it_it/comic/BT��������8League of Legendspl"1https://universe.leagueoflegends.com/pl_pl/comic/BT�������/League of Legendsel"1https://universe.leagueoflegends.com/el_gr/comic/BT��������qLeague of Legendsro"1https://universe.leagueoflegends.com/ro_ro/comic/BTѣ������vLeague of Legendshu"1https://universe.leagueoflegends.com/hu_hu/comic/BT��������League of Legendscs"1https://universe.leagueoflegends.com/cs_cz/comic/BX��������,League of Legendses-419"1https://universe.leagueoflegends.com/es_mx/comic/BW��������jLeague of Legendspt-BR"1https://universe.leagueoflegends.com/pt_br/comic/BT߉�ׯ�ϸLeague of Legendsja"1https://universe.leagueoflegends.com/ja_jp/comic/BT�����ݸ�XLeague of Legendsru"1https://universe.leagueoflegends.com/ru_ru/comic/BT��������ELeague of Legendstr"1https://universe.leagueoflegends.com/tr_tr/comic/BTЌ�򰁥League of Legendsko"1https://universe.leagueoflegends.com/ko_kr/comic/
�
Little Garden.eu.kanade.tachiyomi.extension.all.littlegarden�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.littlegarden-v1.4.3.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.littlegarden.png"1.4(21.4.3B:�ؒ�����@Little Gardenall"https://littlexgarden.com/
�
Lunar Manga,eu.kanade.tachiyomi.extension.all.lunaranime�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.lunaranime-v1.4.7.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.lunaranime.png"1.4(21.4.78B3��������PLunar Mangaall"https://lunaranime.ruB2�������eLunar Mangaen"https://lunaranime.ruB2��������3Lunar Mangaar"https://lunaranime.ruB2����ÿ�%Lunar Mangabg"https://lunaranime.ruB2ϴ���鿥1Lunar Mangabn"https://lunaranime.ruB2�㊚����Lunar Mangada"https://lunaranime.ruB2ԅ�̌���DLunar Mangade"https://lunaranime.ruB2��«椥�Lunar Mangaes"https://lunaranime.ruB6�ێ�����?Lunar Mangaes-419"https://lunaranime.ruB2ܬ������kLunar Mangafa"https://lunaranime.ruB2��꽄���Lunar Mangafi"https://lunaranime.ruB2�����sLunar Mangafr"https://lunaranime.ruB2Ǳ��ə��DLunar Mangahe"https://lunaranime.ruB2�ǹ�����>Lunar Mangahi"https://lunaranime.ruB2��������pLunar Mangaid"https://lunaranime.ruB2�����rLunar Mangait"https://lunaranime.ruB2���ʠ���'Lunar Mangaja"https://lunaranime.ruB2Ҍٳډ��RLunar Mangako"https://lunaranime.ruB2�������Lunar Mangams"https://lunaranime.ruB2��ܳ���Lunar Manganl"https://lunaranime.ruB2����آ��Lunar Mangano"https://lunaranime.ruB2��캚��Lunar Mangapl"https://lunaranime.ruB2��������	Lunar Mangapt"https://lunaranime.ruB5ȝ������Lunar Mangapt-BR"https://lunaranime.ruB2��������BLunar Mangaru"https://lunaranime.ruB2�ܥ�ݲ��=Lunar Mangasv"https://lunaranime.ruB2�ԁ�����+Lunar Mangath"https://lunaranime.ruB2�������`Lunar Mangatl"https://lunaranime.ruB2�������5Lunar Mangatr"https://lunaranime.ruB2լ������,Lunar Mangaur"https://lunaranime.ruB2�ٳ꘨ƇELunar Mangavi"https://lunaranime.ruB2����ޖ��)Lunar Mangazh"https://lunaranime.ru
�
Luscious*eu.kanade.tachiyomi.extension.all.luscious�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.luscious-v1.4.32.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.luscious.png"1.4( 21.4.328B2��Ϲ濨�&Lusciousen"https://www.luscious.netB2��������Lusciousja"https://www.luscious.netB2ۥ����;Lusciouses"https://www.luscious.netB2���ٯ�Lusciousit"https://www.luscious.netB2�������GLusciousde"https://www.luscious.netB2��݁߶�Lusciousfr"https://www.luscious.netB2Ȓѵ��HLusciouszh"https://www.luscious.netB2�������Lusciousko"https://www.luscious.netB5򼡄̓ÙLusciousother"https://www.luscious.netB5���⟆��PLusciouspt-BR"https://www.luscious.netB2�������$Lusciousth"https://www.luscious.netB3����ߛ�@Lusciousall"https://www.luscious.net
�
Magical Translators4eu.kanade.tachiyomi.extension.all.magicaltranslators�
vhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.magicaltranslators-v1.4.8.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.magicaltranslators.png"1.4(21.4.8B>�ë҃���7Magical Translatorsen"https://mahoushoujobu.comB>���쭪ţxMagical Translatorses"https://mahoushoujobu.comB>��������Magical Translatorspl"https://mahoushoujobu.com
�
	Manga18Me+eu.kanade.tachiyomi.extension.all.manga18me�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.manga18me-v1.4.3.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.manga18me.png"1.4(21.4.38B/���ĺ��
Manga18.meall"https://manga18.meB.��ԛ����V
Manga18.meen"https://manga18.me
�

Manga Ball+eu.kanade.tachiyomi.extension.all.mangaball�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangaball-v1.4.3.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangaball.png"1.4(21.4.38B1ޗԔ����O
Manga Ballar"https://mangaball.netB1���ٴ���y
Manga Ballbg"https://mangaball.netB1�������
Manga Ballbn"https://mangaball.netB1��������~
Manga Ballca"https://mangaball.netB1�������c
Manga Ballcs"https://mangaball.netB1ҥ������0
Manga Ballda"https://mangaball.netB1��Ӝ����
Manga Ballde"https://mangaball.netB1�ү����M
Manga Ballel"https://mangaball.netB1�������
Manga Ballen"https://mangaball.netB1���Ԉ�
Manga Balles"https://mangaball.netB1���Ӓ���E
Manga Ballfa"https://mangaball.netB1��ۧį��J
Manga Ballfi"https://mangaball.netB1���ï���B
Manga Ballfr"https://mangaball.netB1�������!
Manga Ballhe"https://mangaball.netB1�ͩ�����.
Manga Ballhi"https://mangaball.netB0�䯂�ʏ=
Manga Ballhu"https://mangaball.netB1騏ᨺ��'
Manga Ballid"https://mangaball.netB1�����ݾ�1
Manga Ballit"https://mangaball.netB1����­ƕb
Manga Ballis"https://mangaball.netB1��Ӥ���1
Manga Ballja"https://mangaball.netB1�Ҽ�ɮ��[
Manga Ballko"https://mangaball.netB1�п�����y
Manga Ballkn"https://mangaball.netB1��ý̸��?
Manga Ballml"https://mangaball.netB1����С��r
Manga Ballms"https://mangaball.netB1Ӫ������
Manga Ballne"https://mangaball.netB1������L
Manga Ballnl"https://mangaball.netB1���ϝ��4
Manga Ballno"https://mangaball.netB1����݅�P
Manga Ballpl"https://mangaball.netB3ǔ�����?
Manga Ballpt-BR"https://mangaball.netB1��˗ҩ��.
Manga Ballro"https://mangaball.netB1���Ԯ۟�c
Manga Ballru"https://mangaball.netB1��ј����p
Manga Ballsk"https://mangaball.netB1��ѵѝ�
Manga Ballsl"https://mangaball.netB1��ǭ����n
Manga Ballsq"https://mangaball.netB1�������@
Manga Ballsr"https://mangaball.netB1�Џ�����D
Manga Ballsv"https://mangaball.netB1�����ӝ�
Manga Ballta"https://mangaball.netB1�����〉^
Manga Ballth"https://mangaball.netB1��ץ�ˏ�x
Manga Balltr"https://mangaball.netB1����ˬ��U
Manga Balluk"https://mangaball.netB1Ĭ��Ÿ��
Manga Ballvi"https://mangaball.netB1��������
Manga Ballzh"https://mangaball.net
�

MangaCrazy,eu.kanade.tachiyomi.extension.all.mangacrazy�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangacrazy-v1.4.50.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangacrazy.png"1.4(221.4.508B3�Ϧ�����^
MangaCrazyall"https://mangacrazy.net
�
MangaDex*eu.kanade.tachiyomi.extension.all.mangadex�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangadex-v1.4.210.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangadex.png"1.4(�21.4.2108B.���ׯ���"MangaDexen"https://mangadex.orgB.��֑����@MangaDexaf"https://mangadex.orgB.��ɻ����MangaDexsq"https://mangadex.orgB.��������.MangaDexar"https://mangadex.orgB.��������~MangaDexaz"https://mangadex.orgB.��������MangaDexeu"https://mangadex.orgB.͒������1MangaDexbe"https://mangadex.orgB.���˨���9MangaDexbn"https://mangadex.orgB.ğ͌필�KMangaDexbg"https://mangadex.orgB.�؂����MangaDexmy"https://mangadex.orgB.�����贪QMangaDexca"https://mangadex.orgB3��������GMangaDexzh-Hans"https://mangadex.orgB3��������MangaDexzh-Hant"https://mangadex.orgB.����庡�MangaDexcv"https://mangadex.orgB.򍀿����vMangaDexhr"https://mangadex.orgB.�Κ����1MangaDexcs"https://mangadex.orgB.�����MangaDexda"https://mangadex.orgB.���خ��]MangaDexnl"https://mangadex.orgB.���΂���'MangaDexeo"https://mangadex.orgB.�����݂�yMangaDexet"https://mangadex.orgB/�����ё�wMangaDexfil"https://mangadex.orgB.ǲ����rMangaDexfi"https://mangadex.orgB.������>MangaDexfr"https://mangadex.orgB.�ܹ�����|MangaDexka"https://mangadex.orgB.���㦜��FMangaDexde"https://mangadex.orgB.��䕠-MangaDexel"https://mangadex.orgB.��������MangaDexhe"https://mangadex.orgB.�������^MangaDexhi"https://mangadex.orgB.�ߏ��̻;MangaDexhu"https://mangadex.orgB.�����׃�3MangaDexga"https://mangadex.orgB.�񎥝��4MangaDexid"https://mangadex.orgB.������ɋMangaDexit"https://mangadex.orgB.����Ӄ��MangaDexjv"https://mangadex.orgB.���ڧ���MangaDexja"https://mangadex.orgB.и���굥{MangaDexkk"https://mangadex.orgB.ضĘ����-MangaDexko"https://mangadex.orgB.��������
MangaDexla"https://mangadex.orgB.Ƈ�ҥ���
MangaDexlt"https://mangadex.orgB.��ӄ����MangaDexms"https://mangadex.orgB.���ұ���RMangaDexmn"https://mangadex.orgB.��׈���MangaDexne"https://mangadex.orgB.����̅��CMangaDexno"https://mangadex.orgB.���ĵ��4MangaDexfa"https://mangadex.orgB.܍ώ����oMangaDexpl"https://mangadex.orgB1��ݹ����$MangaDexpt-BR"https://mangadex.orgB.��ƕ���HMangaDexpt"https://mangadex.orgB.�߱൳��BMangaDexro"https://mangadex.orgB.��峐MangaDexru"https://mangadex.orgB.����趭�0MangaDexsr"https://mangadex.orgB.�Ŭ�����'MangaDexsk"https://mangadex.orgB2�͎�����DMangaDexes-419"https://mangadex.orgB.��乔���XMangaDexes"https://mangadex.orgB.����̨��MangaDexsv"https://mangadex.orgB.״�����;MangaDexta"https://mangadex.orgB.���Ľ���_MangaDexte"https://mangadex.orgB.��������MangaDexth"https://mangadex.orgB.���Į���5MangaDextr"https://mangadex.orgB.�����љPMangaDexuk"https://mangadex.orgB.ݷ���ꨁMangaDexur"https://mangadex.orgB.������ɲ'MangaDexuz"https://mangadex.orgB.洛����MangaDexvi"https://mangadex.org
�
MangaDNA*eu.kanade.tachiyomi.extension.all.mangadna�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangadna-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangadna.png"1.4(21.4.28B.�������GMangaDNAen"https://mangadna.comB/��������VMangaDNAall"https://mangadna.com
�
Manga Draft,eu.kanade.tachiyomi.extension.all.mangadraft�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangadraft-v1.4.1.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangadraft.png"1.4(21.4.1B3��ϳ�ń�_
MangaDraftall"https://mangadraft.com
�
	MangaFire+eu.kanade.tachiyomi.extension.all.mangafire�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangafire-v1.4.24.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangafire.png"1.4(21.4.248B/�������T	MangaFireen"https://mangafire.toB/��ç���p	MangaFirees"https://mangafire.toB3��˽��5	MangaFirees-419"https://mangafire.toB/����֞��V	MangaFirefr"https://mangafire.toB/����׃��	MangaFireja"https://mangafire.toB/ۄ�ʾ���
	MangaFirept"https://mangafire.toB2�����ȷ�l	MangaFirept-BR"https://mangafire.to
�
MangaForFree.net.eu.kanade.tachiyomi.extension.all.mangaforfree�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangaforfree-v1.4.52.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangaforfree.png"1.4(421.4.528B:�ӏ��Ѷ�gMangaForFree.neten"https://mangaforfree.netB:�ϗր�ѭMangaForFree.netko"https://mangaforfree.netB:�������MangaForFree.netall"https://mangaforfree.net
�
Manga Hosted-eu.kanade.tachiyomi.extension.all.mangahosted�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangahosted-v1.4.3.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangahosted.png"1.4(21.4.38B7؈���־�pManga Hosteden"https://mangago.fit/mangaB=����ꖩ�uManga Hosted v2en"https://mangago.fit/manga-v2B>��ܦ�Ԣ�]Manga Hosted Comicsen"https://mangago.fit/comicB?������2Manga Hostedes"!https://mangago.fit/manga-spanishB<����ųĩ9Manga Hostedid"https://mangago.fit/manga-indoB>�������=Manga Hostedit" https://mangago.fit/manga-italiaB:����ň��Manga Hostedja"https://mangago.fit/mangarawB=��������MManga Hostedpt-BR"https://mangago.fit/manga-brB:����ڪ��rManga Hostedru"https://mangago.fit/manga-ruBE�麓��ݬLManga Hosted +18ru"#https://mangago.fit/manga-ru-hentaiBH�������uManga Hosted +18 Yaoiru"!https://mangago.fit/manga-ru-yaoi
�)
	MangaPark+eu.kanade.tachiyomi.extension.all.mangapark�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangapark-v1.4.25.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangapark.png"1.4(21.4.258B0�̡�˪��#	MangaParkaf"https://mangapark.netB0���霄��:	MangaParksq"https://mangapark.netB0�����휇a	MangaParkam"https://mangapark.netB0�������	MangaParkar"https://mangapark.netB0���밺׭o	MangaParkhy"https://mangapark.netB0���ᇣ��Q	MangaParkaz"https://mangapark.netB0��ؽ���(	MangaParkbe"https://mangapark.netB0��������	MangaParkbn"https://mangapark.netB0��������*	MangaParkbs"https://mangapark.netB0�ǯ꩏*	MangaParkbg"https://mangapark.netB0���ڥ���\	MangaParkmy"https://mangapark.netB0������ǽ	MangaParkkm"https://mangapark.netB0����钺�6	MangaParkca"https://mangapark.netB1�惗����3	MangaParkceb"https://mangapark.netB0ҧ������#	MangaParkzh"https://mangapark.netB5��ՠ����t	MangaParkzh-Hans"https://mangapark.netB5��������X	MangaParkzh-Hant"https://mangapark.netB0��������z	MangaParkhr"https://mangapark.netB0��ڴ�ǘ�0	MangaParkcs"https://mangapark.netB0������؋	MangaParkda"https://mangapark.netB0������כ	MangaParknl"https://mangapark.netB0�ꆪ����	MangaParken"https://mangapark.netB0��������?	MangaParkeo"https://mangapark.netB0���ȁ���	MangaParket"https://mangapark.netB0���ɭ��<	MangaParkfo"https://mangapark.netB1��ҟ����	MangaParkfil"https://mangapark.netB0��؞��p	MangaParkfi"https://mangapark.netB0��̘����I	MangaParkfr"https://mangapark.netB0����И��e	MangaParkka"https://mangapark.netB0������,	MangaParkde"https://mangapark.netB0��������>	MangaParkel"https://mangapark.netB0����֨�f	MangaParkgn"https://mangapark.netB0���𭙓}	MangaParkht"https://mangapark.netB0��������*	MangaParkha"https://mangapark.netB0�쎦���8	MangaParkhe"https://mangapark.netB0�ٯ�����3	MangaParkhi"https://mangapark.netB0��Ѡ����	MangaParkhu"https://mangapark.netB0��������	MangaParkis"https://mangapark.netB0�������	MangaParkig"https://mangapark.netB0����۰��Y	MangaParkid"https://mangapark.netB0���򅱪�"	MangaParkga"https://mangapark.netB0�Ȩ���6	MangaParkit"https://mangapark.netB0�����ޥ�p	MangaParkja"https://mangapark.netB0�������	MangaParkjv"https://mangapark.netB0��������t	MangaParkkk"https://mangapark.netB0�������4	MangaParkko"https://mangapark.netB0Ș�ȍ���j	MangaParkku"https://mangapark.netB0�������>	MangaParkky"https://mangapark.netB0�������	MangaParklo"https://mangapark.netB0����Շ��	MangaParklv"https://mangapark.netB0��ζ����x	MangaParklt"https://mangapark.netB0������ˋJ	MangaParklb"https://mangapark.netB0��������V	MangaParkmk"https://mangapark.netB0�ߴ��鯨I	MangaParkmg"https://mangapark.netB0������øG	MangaParkms"https://mangapark.netB0�ꑫ����H	MangaParkml"https://mangapark.netB0���в��t	MangaParkmt"https://mangapark.netB0�������h	MangaParkmi"https://mangapark.netB0�Ѧ埚��J	MangaParkmo"https://mangapark.netB0�������i	MangaParkmn"https://mangapark.netB0߮���ռ�	MangaParkne"https://mangapark.netB0�����c	MangaParkno"https://mangapark.netB0�𾾱���a	MangaParkny"https://mangapark.netB0�������@	MangaParkps"https://mangapark.netB0��������	MangaParkfa"https://mangapark.netB0�ܡϮ��	MangaParkpl"https://mangapark.netB0�����«�c	MangaParkpt"https://mangapark.netB3��������.	MangaParkpt-BR"https://mangapark.netB0��������	MangaParkro"https://mangapark.netB0��������8	MangaParkrm"https://mangapark.netB0�ݱ�ק��R	MangaParkru"https://mangapark.netB0����ܡ��L	MangaParksm"https://mangapark.netB0���逡ͷ=	MangaParksr"https://mangapark.netB0Ӂ�ޚ���	MangaParksh"https://mangapark.netB0�������w	MangaParkst"https://mangapark.netB0Ἕ�쨯�	MangaParksn"https://mangapark.netB0�����ʅ�
	MangaParksd"https://mangapark.netB0��Â����k	MangaParksi"https://mangapark.netB0���铲��y	MangaParksk"https://mangapark.netB0�����ľ�u	MangaParksl"https://mangapark.netB0��������m	MangaParkso"https://mangapark.netB0���ظ：,	MangaParkes"https://mangapark.netB4����ܕ��8	MangaParkes-419"https://mangapark.netB0����²�H	MangaParksw"https://mangapark.netB0���祧��	MangaParksv"https://mangapark.netB/�������*	MangaParktg"https://mangapark.netB0��ŷ�ܫ�	MangaParkta"https://mangapark.netB0���ξ��(	MangaParkth"https://mangapark.netB0��ø����K	MangaParkti"https://mangapark.netB0��й�ԃ�k	MangaParkto"https://mangapark.netB0���ȱ��,	MangaParktr"https://mangapark.netB0�������	MangaParktk"https://mangapark.netB0����ࡀ"	MangaParkuk"https://mangapark.netB0Ȗ�񷣉%	MangaParkur"https://mangapark.netB0�ⳛ���&	MangaParkuz"https://mangapark.netB0�Ƃ����w	MangaParkvi"https://mangapark.netB0Ë������v	MangaParkyo"https://mangapark.netB0�ܧ�����3	MangaParkzu"https://mangapark.netB3��������+	MangaParkother"https://mangapark.net
�
MANGA Plus by SHUEISHA+eu.kanade.tachiyomi.extension.all.mangaplus�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangaplus-v1.4.62.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangaplus.png"1.4(>21.4.62BH��������MANGA Plus by SHUEISHAen" https://mangaplus.shueisha.co.jpBHΦ��ڙ��MANGA Plus by SHUEISHAes" https://mangaplus.shueisha.co.jpBH�ـ�����jMANGA Plus by SHUEISHAfr" https://mangaplus.shueisha.co.jpBH﷯����MANGA Plus by SHUEISHAid" https://mangaplus.shueisha.co.jpBK�������/MANGA Plus by SHUEISHApt-BR" https://mangaplus.shueisha.co.jpBH��ć���0MANGA Plus by SHUEISHAru" https://mangaplus.shueisha.co.jpBH����ߓ��XMANGA Plus by SHUEISHAth" https://mangaplus.shueisha.co.jpBH������AMANGA Plus by SHUEISHAvi" https://mangaplus.shueisha.co.jpBH�����ǣMANGA Plus by SHUEISHAde" https://mangaplus.shueisha.co.jp
�
MANGA Plus Creators by SHUEISHA3eu.kanade.tachiyomi.extension.all.mangapluscreators�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangapluscreators-v1.4.3.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangapluscreators.png"1.4(21.4.3BN�Ѧ�Ť��EMANGA Plus Creators by SHUEISHAen"https://mangaplus-creators.jpBN��������MANGA Plus Creators by SHUEISHAes"https://mangaplus-creators.jp
�
	MangaTaro+eu.kanade.tachiyomi.extension.all.mangataro�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangataro-v1.4.11.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangataro.png"1.4(21.4.11B0��Ȥ����s	MangaTaroen"https://mangataro.orgB3֖������	MangaTaropt-BR"https://mangataro.org
�
MangaToon (Limited)+eu.kanade.tachiyomi.extension.all.mangatoon�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangatoon-v1.4.8.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangatoon.png"1.4(21.4.8B;����␂�NMangaToon (Limited)zh"https://mangatoon.mobiB;�ڨ�����BMangaToon (Limited)en"https://mangatoon.mobiB;�޾�紬�[MangaToon (Limited)id"https://mangatoon.mobiB;������_MangaToon (Limited)vi"https://mangatoon.mobiB;��웧羦MangaToon (Limited)es"https://mangatoon.mobiB>���Ӽ��MangaToon (Limited)pt-BR"https://mangatoon.mobiB;��������VMangaToon (Limited)th"https://mangatoon.mobiB;��б����\MangaToon (Limited)fr"https://mangatoon.mobiB;��������0MangaToon (Limited)ja"https://mangatoon.mobi
�
	Manga UP!)eu.kanade.tachiyomi.extension.all.mangaup�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mangaup-v1.4.8.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangaup.png"1.4(21.4.8B6��������j	Manga UP!en"https://global.manga-up.com
�
Mango'eu.kanade.tachiyomi.extension.all.mango�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mango-v1.4.11.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mango.png"1.4(21.4.11Bχ����(Mangoen
�
Manhuarm*eu.kanade.tachiyomi.extension.all.manhuarm�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.manhuarm-v1.4.73.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.manhuarm.png"1.4(I21.4.738B0竨ͣ���Manhuarmar"https://manhuarmtl.comB0�ç����jManhuarmen"https://manhuarmtl.comB0�������vManhuarmes"https://manhuarmtl.comB0����׍��vManhuarmfr"https://manhuarmtl.comB0������ݎYManhuarmid"https://manhuarmtl.comB0��˴ۣ�iManhuarmit"https://manhuarmtl.comB3�ܢ�����MManhuarmpt-BR"https://manhuarmtl.com
�
Manhwa18.cc,eu.kanade.tachiyomi.extension.all.manhwa18cc�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.manhwa18cc-v1.4.56.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.manhwa18cc.png"1.4(821.4.568B0������CManhwa18.ccen"https://manhwa18.ccB0߇������_Manhwa18.ccko"https://manhwa18.ccB1�������Manhwa18.ccall"https://manhwa18.cc
�
Manhwa18.net-eu.kanade.tachiyomi.extension.all.manhwa18net�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.manhwa18net-v1.4.13.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.manhwa18net.png"1.4(21.4.138B2��������	Manhwa18.Neten"https://manhwa18.net
�
Manhwa 18 Uncensored4eu.kanade.tachiyomi.extension.all.manhwa18uncensored�
whttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.manhwa18uncensored-v1.4.50.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.manhwa18uncensored.png"1.4(221.4.508BD��������xManhwa 18 Uncensoreden"https://manhwa18uncensored.comBE��ނ����Manhwa 18 Uncensoredall"https://manhwa18uncensored.com
�
ManhwaClub.net/eu.kanade.tachiyomi.extension.all.manhwaclubnet�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.manhwaclubnet-v1.4.50.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.manhwaclubnet.png"1.4(221.4.508B6�ӧ�봫�]ManhwaClub.neten"https://manhwaclub.netB6��鄐�ʪ0ManhwaClub.netko"https://manhwaclub.net
�

Manhwa-raw/eu.kanade.tachiyomi.extension.all.manhwadashraw�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.manhwadashraw-v1.4.52.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.manhwadashraw.png"1.4(421.4.528B3�����Ǩ�M
Manhwa-rawall"https://manhwa-raw.com
�
Manta Comics'eu.kanade.tachiyomi.extension.all.manta�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.manta-v1.4.8.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.manta.png"1.4(21.4.88B+·˞��ϼyMantaen"https://manta.net/enB+�������'Mantaes"https://manta.net/es
�
MayoTune*eu.kanade.tachiyomi.extension.all.mayotune�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mayotune-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mayotune.png"1.4(21.4.2B.��Ҝ����MayoTuneen"https://mayochuu.xyzB.��������\MayoTuneja"https://mayochuu.xyz
�
Metart Hunter.eu.kanade.tachiyomi.extension.all.metarthunter�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.metarthunter-v1.4.2.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.metarthunter.png"1.4(21.4.28B<��������1Metart Hunterall"https://www.metarthunter.com
�
	Miau Scan*eu.kanade.tachiyomi.extension.all.miauscan�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.miauscan-v1.4.39.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.miauscan.png"1.4('21.4.398B.�����Ɍ�(	Miau Scanes"https://leemiau.comB1�����ې�]	Miau Scanpt-BR"https://leemiau.com
�
Mihentai*eu.kanade.tachiyomi.extension.all.mihentai�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mihentai-v1.4.32.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mihentai.png"1.4( 21.4.328B/̝�缭ΰ1Mihentaiall"https://mihentai.com
�
MissKon)eu.kanade.tachiyomi.extension.all.misskon�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.misskon-v1.4.4.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.misskon.png"1.4(21.4.48B-��������MissKonall"https://misskon.com
�
Mitaku(eu.kanade.tachiyomi.extension.all.mitaku�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.mitaku-v1.4.4.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mitaku.png"1.4(21.4.48B+֝������hMitakuall"https://mitaku.net
�
MyReadingManga0eu.kanade.tachiyomi.extension.all.myreadingmanga�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.myreadingmanga-v1.4.61.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.myreadingmanga.png"1.4(=21.4.618B;ή놌���CMyReadingMangaar"https://myreadingmanga.infoB;屹�����zMyReadingMangaid"https://myreadingmanga.infoB;���봚��sMyReadingMangazh"https://myreadingmanga.infoB;��ᛐ���WMyReadingMangaen"https://myreadingmanga.infoB;����ԥ�MyReadingMangade"https://myreadingmanga.infoB;��������.MyReadingMangait"https://myreadingmanga.infoB;�ب�����iMyReadingMangaja"https://myreadingmanga.infoB;��ݪ����sMyReadingMangako"https://myreadingmanga.infoB>􄕆�ՠ�bMyReadingMangapt-BR"https://myreadingmanga.infoB;�����ռ:MyReadingMangaru"https://myreadingmanga.infoB;�筦Ќ��1MyReadingMangaes"https://myreadingmanga.infoB;П�ݻ���MyReadingMangatr"https://myreadingmanga.infoB;�ؙ���9MyReadingMangavi"https://myreadingmanga.info
�
NamiComi*eu.kanade.tachiyomi.extension.all.namicomi�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.namicomi-v1.4.6.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.namicomi.png"1.4(21.4.6B.Կ�����^NamiComien"https://namicomi.comB.����Έ��lNamiComiar"https://namicomi.comB.��������mNamiComibg"https://namicomi.comB.���̫���JNamiComica"https://namicomi.comB3��������NamiComizh-Hans"https://namicomi.comB3���޼�mNamiComizh-Hant"https://namicomi.comB.޹ě֌��NamiComihr"https://namicomi.comB.޿�����NamiComics"https://namicomi.comB.��������hNamiComida"https://namicomi.comB.����Ġ��9NamiCominl"https://namicomi.comB.�ﭐ����NamiComiet"https://namicomi.comB/��鿲���lNamiComifil"https://namicomi.comB.������{NamiComifi"https://namicomi.comB.�����Ȣ�%NamiComifr"https://namicomi.comB.��������[NamiComide"https://namicomi.comB.��ʆ����jNamiComiel"https://namicomi.comB.������׫NamiComihe"https://namicomi.comB.����ݱ��RNamiComihi"https://namicomi.comB.�����lNamiComihu"https://namicomi.comB.�ل�����NamiComiis"https://namicomi.comB.ѯ��ϸш1NamiComiga"https://namicomi.comB.���ۗͯ�NamiComiid"https://namicomi.comB.���ڼ���RNamiComiit"https://namicomi.comB.��Ŧ큁�_NamiComija"https://namicomi.comB.������NamiComiko"https://namicomi.comB.�너����UNamiComilt"https://namicomi.comB.��Ԭ����TNamiComims"https://namicomi.comB.�����ጏNamiComine"https://namicomi.comB.�����ݥ�[NamiComino"https://namicomi.comB.��悾���
NamiComipa"https://namicomi.comB.����˂��NamiComifa"https://namicomi.comB.�������INamiComipl"https://namicomi.comB1�����鳺NamiComipt-BR"https://namicomi.comB.��ќ���BNamiComipt"https://namicomi.comB.���ᆽ��NamiComiru"https://namicomi.comB.�׎�����NamiComisk"https://namicomi.comB.��������NamiComisl"https://namicomi.comB2��է���3NamiComies-419"https://namicomi.comB.��������gNamiComies"https://namicomi.comB.��ި����7NamiComisv"https://namicomi.comB.렩�����^NamiComith"https://namicomi.comB.Ȑ�ϣ��NamiComitr"https://namicomi.comB.�ޢ����gNamiComiuk"https://namicomi.com
�
NHentai)eu.kanade.tachiyomi.extension.all.nhentai�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.nhentai-v1.4.54.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.nhentai.png"1.4(621.4.548B,�Ѧ�����+NHentaien"https://nhentai.netB,�ᘘ����ANHentaija"https://nhentai.netB,����ŗ��NHentaizh"https://nhentai.netB-��������eNHentaiall"https://nhentai.net
�
nHentai.com (unoriginal),eu.kanade.tachiyomi.extension.all.nhentaicom�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.nhentaicom-v1.4.9.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.nhentaicom.png"1.4(	21.4.98B>�߯���nHentai.com (unoriginal)all"https://nhentai.comB=�����vnHentai.com (unoriginal)zh"https://nhentai.comB=��צ����MnHentai.com (unoriginal)en"https://nhentai.comB=�Ә�����qnHentai.com (unoriginal)ja"https://nhentai.comB@��������PnHentai.com (unoriginal)other"https://nhentai.comB=���ʧ���nHentai.com (unoriginal)ar"https://nhentai.comB=�������EnHentai.com (unoriginal)jv"https://nhentai.comB=׬��՞��JnHentai.com (unoriginal)bg"https://nhentai.comB=ĸ������nHentai.com (unoriginal)cs"https://nhentai.comB=���♗��nHentai.com (unoriginal)uk"https://nhentai.comB=��컸���qnHentai.com (unoriginal)sk"https://nhentai.comB=��환���KnHentai.com (unoriginal)eo"https://nhentai.comB=쏯�ß��2nHentai.com (unoriginal)mn"https://nhentai.comB=����ӄ��]nHentai.com (unoriginal)la"https://nhentai.comB>��͡��snHentai.com (unoriginal)ceb"https://nhentai.comB=ʥ���߹�<nHentai.com (unoriginal)tl"https://nhentai.comB=��ֱ����vnHentai.com (unoriginal)fi"https://nhentai.comB=�ӣ���͑YnHentai.com (unoriginal)tr"https://nhentai.comB=�喙����nHentai.com (unoriginal)sr"https://nhentai.comB=�������SnHentai.com (unoriginal)el"https://nhentai.comB=��������ZnHentai.com (unoriginal)ko"https://nhentai.comB=�ٮ�����rnHentai.com (unoriginal)ro"https://nhentai.com
�
NHentai.xxx,eu.kanade.tachiyomi.extension.all.nhentaixxx�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.nhentaixxx-v1.4.9.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.nhentaixxx.png"1.4(	21.4.98B0�����NHentai.xxxen"https://nhentai.xxxB0���靶RNHentai.xxxja"https://nhentai.xxxB0���È���NHentai.xxxzh"https://nhentai.xxxB1���ܗ�܋!NHentai.xxxall"https://nhentai.xxx
�
Niadd'eu.kanade.tachiyomi.extension.all.niadd�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.niadd-v1.4.2.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.niadd.png"1.4(21.4.28B.Т�����iNiaddpt-BR"https://br.niadd.comB,��������VNiadden"https://www.niadd.comB+ʙԝ�ǁNiaddes"https://es.niadd.comB+���䍖�rNiaddit"https://it.niadd.comB+�賃����Niaddru"https://ru.niadd.comB+㫞�����.Niaddde"https://de.niadd.comB+�ژ�����(Niaddfr"https://fr.niadd.com
�
	NineManga+eu.kanade.tachiyomi.extension.all.ninemanga�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.ninemanga-v1.4.26.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.ninemanga.png"1.4(21.4.268B6��Ĭ����NineMangaEnen"https://www.ninemanga.comB5�������8NineMangaEses"https://es.ninemanga.comB8�����磳cNineMangaBrpt-BR"https://br.ninemanga.comB5Ɉ��钲�ZNineMangaRuru"https://ru.ninemanga.comB5��Բ����uNineMangaDede"https://de.ninemanga.comB5������;NineMangaItit"https://it.ninemanga.comB5����ǻ�/NineMangaFrfr"https://fr.ninemanga.com
�
	NovelCool+eu.kanade.tachiyomi.extension.all.novelcool�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.novelcool-v1.4.8.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.novelcool.png"1.4(21.4.88B4���Įᙇi	NovelCoolen"https://www.novelcool.comB3�є���׊	NovelCooles"https://es.novelcool.comB3��������B	NovelCoolde"https://de.novelcool.comB3��������	NovelCoolru"https://ru.novelcool.comB3��������	NovelCoolit"https://it.novelcool.comB6�������!	NovelCoolpt-BR"https://br.novelcool.comB3�􂋋��	NovelCoolfr"https://fr.novelcool.com
�
One Piece Fans.eu.kanade.tachiyomi.extension.all.onepiecefans�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.onepiecefans-v1.4.1.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.onepiecefans.png"1.4(21.4.1B;꯷�汩�)One Piece Fanses"https://one-piece-fans2.comB;��҄˒��[One Piece Fansen"https://one-piece-fans2.com
�
OSOSEDKI*eu.kanade.tachiyomi.extension.all.ososedki�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.ososedki-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.ososedki.png"1.4(21.4.18B/͎�ɖ���	OSOSEDKIall"https://ososedki.com
�
PandaChaika-eu.kanade.tachiyomi.extension.all.pandachaika�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.pandachaika-v1.4.3.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.pandachaika.png"1.4(21.4.38B6��ܵ����qPandaChaikaall"https://panda.chaika.moeB5��������1PandaChaikaen"https://panda.chaika.moeB5�������cPandaChaikazh"https://panda.chaika.moeB5�ϧ���ȢfPandaChaikako"https://panda.chaika.moeB5�����õ�PandaChaikaes"https://panda.chaika.moeB5�ɰ�����HPandaChaikaru"https://panda.chaika.moeB5��������PandaChaikapt"https://panda.chaika.moeB5��󤇥��jPandaChaikafr"https://panda.chaika.moeB5��������PandaChaikath"https://panda.chaika.moeB5�����ѽ&PandaChaikavi"https://panda.chaika.moeB5̫�����0PandaChaikaja"https://panda.chaika.moeB5��������#PandaChaikaid"https://panda.chaika.moeB5���஫��_PandaChaikaar"https://panda.chaika.moeB5��ˈ����PandaChaikauk"https://panda.chaika.moeB5����ʻ��^PandaChaikatr"https://panda.chaika.moeB5�ϕ���APandaChaikacs"https://panda.chaika.moeB5������`PandaChaikatl"https://panda.chaika.moeB5������כJPandaChaikafi"https://panda.chaika.moeB5����׷��KPandaChaikajv"https://panda.chaika.moeB5��˖����zPandaChaikael"https://panda.chaika.moe
�
Pepper&Carrot.eu.kanade.tachiyomi.extension.all.peppercarrot�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.peppercarrot-v1.4.5.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.peppercarrot.png"1.4(21.4.5B<��Ĩ�Í�Pepper&Carrotall"https://www.peppercarrot.com
�
Photos18*eu.kanade.tachiyomi.extension.all.photos18�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.photos18-v1.4.6.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.photos18.png"1.4(21.4.68B3��������Photos18all"https://www.photos18.com
�
Pixiv'eu.kanade.tachiyomi.extension.all.pixiv�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.pixiv-v1.4.12.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.pixiv.png"1.4(21.4.128B,ކ���ŧ�DPixiven"https://www.pixiv.netB,����ÿ��Pixivja"https://www.pixiv.netB,��Ǜ�ೞ`Pixivzh"https://www.pixiv.netB/���ǚ�kPixivzh-tw"https://www.pixiv.netB,������эGPixivko"https://www.pixiv.net
�
Playmate Hunter0eu.kanade.tachiyomi.extension.all.playmatehunter�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.playmatehunter-v1.4.2.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.playmatehunter.png"1.4(21.4.28B9ű���͐�Playmate Hunterall"https://pmatehunter.com
�
PornPics*eu.kanade.tachiyomi.extension.all.pornpics�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.pornpics-v1.4.3.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.pornpics.png"1.4(21.4.38B2��ȷ���PornPicsen"https://www.pornpics.comB2�¯���bPornPicszh"https://www.pornpics.com
�
Project Suki-eu.kanade.tachiyomi.extension.all.projectsuki�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.projectsuki-v1.4.8.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.projectsuki.png"1.4(21.4.8B7�����ն|Project Sukiall"https://projectsuki.com/
�
Pururin)eu.kanade.tachiyomi.extension.all.pururin�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.pururin-v1.4.10.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.pururin.png"1.4(
21.4.108B,���׹��<Pururinall"https://pururin.meB+������Pururinen"https://pururin.meB+�Ƥ�����Pururinja"https://pururin.me
�
QToon'eu.kanade.tachiyomi.extension.all.qtoon�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.qtoon-v1.4.1.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.qtoon.png"1.4(21.4.18B(�҇���ЭkQToonen"https://qtoon.comB(��񓤀ܿ&QToones"https://qtoon.comB+ռ����ܨ[QToonpt-BR"https://qtoon.com
�
Ravens Scans-eu.kanade.tachiyomi.extension.all.ravensscans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.ravensscans-v1.4.8.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.ravensscans.png"1.4(21.4.88B6�����ō6Ravens Scanses"https://ravens-scans.comB6������ĤRavens Scansen"https://ravens-scans.com
�

RokuHentai,eu.kanade.tachiyomi.extension.all.rokuhentai�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.rokuhentai-v1.4.1.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.rokuhentai.png"1.4(21.4.18B4�����ۀ^Roku Hentaiall"https://rokuhentai.com
�
BlossomManhwa.eu.kanade.tachiyomi.extension.all.sakuramanhwa�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.sakuramanhwa-v1.4.5.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.sakuramanhwa.png"1.4(21.4.58B<��ڄ���BlossomManhwaall"https://api.cherrymanhwa.com
�
Sandra and Woo.eu.kanade.tachiyomi.extension.all.sandraandwoo�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.sandraandwoo-v1.4.3.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.sandraandwoo.png"1.4(21.4.3B<�ո�����pSandra und Woode"https://www.sandraandwoo.comB<�������vSandra and Wooen"https://www.sandraandwoo.com
�
SeraphicDeviltry2eu.kanade.tachiyomi.extension.all.seraphicdeviltry�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.seraphicdeviltry-v1.4.52.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.seraphicdeviltry.png"1.4(421.4.528B?Ҫ�����JSeraphicDeviltryen"https://seraphic-deviltry.comBG�����ӫ�[SeraphicDeviltryes"%https://spanish.seraphic-deviltry.com
�
Simply Cosplay/eu.kanade.tachiyomi.extension.all.simplycosplay�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.simplycosplay-v1.4.4.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.simplycosplay.png"1.4(21.4.48B?��������LSimply Cosplayall"https://www.simply-cosplay.com
�
Simply Hentai.eu.kanade.tachiyomi.extension.all.simplyhentai�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.simplyhentai-v1.4.8.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.simplyhentai.png"1.4(21.4.88B<׽���恓Simply Hentaien"https://www.simply-hentai.comB<��������
Simply Hentaija"https://www.simply-hentai.comB<��ɤ���XSimply Hentaizh"https://www.simply-hentai.comB<���ש���KSimply Hentaiko"https://www.simply-hentai.comB<ݪ���̔�	Simply Hentaies"https://www.simply-hentai.comB<�����̔�RSimply Hentairu"https://www.simply-hentai.comB<��݇܏��=Simply Hentaifr"https://www.simply-hentai.comB<ߝʑܗ��PSimply Hentaide"https://www.simply-hentai.comB<���ΰ���~Simply Hentaiit"https://www.simply-hentai.comB<ʣ������%Simply Hentaipl"https://www.simply-hentai.com
�
StashApp*eu.kanade.tachiyomi.extension.all.stashapp�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.stashapp-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.stashapp.png"1.4(21.4.18B0������ߐ<StashAppall"http://localhost:9999
�
Taddy INK (Webtoons)*eu.kanade.tachiyomi.extension.all.taddyink�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.taddyink-v1.4.3.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.taddyink.png"1.4(21.4.3B8���Ӆ� Taddy INK (Webtoons)all"https://taddy.org
�
	Tappytoon+eu.kanade.tachiyomi.extension.all.tappytoon�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.tappytoon-v1.4.10.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.tappytoon.png"1.4(
21.4.108B7�������a	Tappytoonen"https://www.tappytoon.com/enB7������٫s	Tappytoonfr"https://www.tappytoon.com/frB7�ҵŎ���x	Tappytoonde"https://www.tappytoon.com/de
�
The Library of Ohara3eu.kanade.tachiyomi.extension.all.thelibraryofohara�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.thelibraryofohara-v1.4.2.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.thelibraryofohara.png"1.4(21.4.2BC�É�����<The Library of Oharaid"https://thelibraryofohara.comBCɵ������%The Library of Oharaen"https://thelibraryofohara.comBC��ͨ��́The Library of Oharaes"https://thelibraryofohara.comBC��ϥ����The Library of Oharait"https://thelibraryofohara.comBC�߹�����qThe Library of Oharaar"https://thelibraryofohara.comBC����񉵘dThe Library of Oharafr"https://thelibraryofohara.com
�
Thunder Scans.eu.kanade.tachiyomi.extension.all.thunderscans�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.thunderscans-v1.4.44.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.thunderscans.png"1.4(,21.4.44B1��������,
Lava Scansar"https://lavascans.comB:܆Ζ����'Thunder Scansen"https://en-thunderscans.com
�
Toomics)eu.kanade.tachiyomi.extension.all.toomics�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.toomics-v1.4.10.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.toomics.png"1.4(
21.4.108BH������њaToomics (Only free chapters)en"https://global.toomics.comBM�㶘���Toomics (Only free chapters)zh-Hans"https://global.toomics.comBM��������Toomics (Only free chapters)zh-Hant"https://global.toomics.comBL����󊙖fToomics (Only free chapters)es-419"https://global.toomics.comBH�����ӿCToomics (Only free chapters)es"https://global.toomics.comBH�������jToomics (Only free chapters)it"https://global.toomics.comBHɣ�㑁��:Toomics (Only free chapters)de"https://global.toomics.comBH�����Toomics (Only free chapters)fr"https://global.toomics.comBK����麖�>Toomics (Only free chapters)pt-BR"https://global.toomics.com
�
Twicomi)eu.kanade.tachiyomi.extension.all.twicomi�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.twicomi-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.twicomi.png"1.4(21.4.18B-�������?Twicomiall"https://twicomi.com
�
Uncensored Manhwa2eu.kanade.tachiyomi.extension.all.uncensoredmanhwa�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.uncensoredmanhwa-v1.4.50.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.uncensoredmanhwa.png"1.4(221.4.508B>󾜳�̠�Uncensored Manhwaen"https://uncensoredmanhwa.usB?�٥��Ш�rUncensored Manhwaall"https://uncensoredmanhwa.us
�
Vinne Veritas - CCC/eu.kanade.tachiyomi.extension.all.vinnieVeritas�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.vinnieVeritas-v1.4.3.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.vinnieVeritas.png"1.4(21.4.3BCު������|Vinnie Veritas - CCCen"https://ccc.vinnieveritas.comBC����ԟ�Vinnie Veritas - CCCes"https://ccc.vinnieveritas.com
�
Webtoons.com*eu.kanade.tachiyomi.extension.all.webtoons�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.webtoons-v1.4.55.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.webtoons.png"1.4(721.4.55B6ر����Ȁ#Webtoons.comen"https://www.webtoons.comB6ʮŮ�yWebtoons.comid"https://www.webtoons.comB6����ϔ�.Webtoons.comth"https://www.webtoons.comB6��҈��ԟxWebtoons.comes"https://www.webtoons.comB6��ҩ�͈�rWebtoons.comfr"https://www.webtoons.comB;��ӗ����)Webtoons.comzh-Hant"https://www.webtoons.comB6��������Webtoons.comde"https://www.webtoons.com
�
Webtoons.com Translations3eu.kanade.tachiyomi.extension.all.webtoonstranslate�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.webtoonstranslate-v1.4.9.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.webtoonstranslate.png"1.4(	21.4.9BI���弐��(Webtoons.com Translationsen"https://translate.webtoons.comBN������HWebtoons.com Translationszh-Hans"https://translate.webtoons.comBN������Webtoons.com Translationszh-Hant"https://translate.webtoons.comBI�������Webtoons.com Translationsth"https://translate.webtoons.comBI�Ե᭟��~Webtoons.com Translationsid"https://translate.webtoons.comBI��������%Webtoons.com Translationsfr"https://translate.webtoons.comBI��������Webtoons.com Translationsvi"https://translate.webtoons.comBI��Ά�̗�LWebtoons.com Translationsru"https://translate.webtoons.comBI��������~Webtoons.com Translationsar"https://translate.webtoons.comBJ��ˀ����Webtoons.com Translationsfil"https://translate.webtoons.comBI���Υޛ�Webtoons.com Translationsde"https://translate.webtoons.comBI��ƙ����BWebtoons.com Translationshi"https://translate.webtoons.comBI��̏����tWebtoons.com Translationsit"https://translate.webtoons.comBIȢ���ȍ�.Webtoons.com Translationsja"https://translate.webtoons.comBL���Ւ��Webtoons.com Translationspt-BR"https://translate.webtoons.comBI��������Webtoons.com Translationstr"https://translate.webtoons.comBI䪨˰�̠cWebtoons.com Translationsms"https://translate.webtoons.comBI������Webtoons.com Translationspl"https://translate.webtoons.comBI�������Webtoons.com Translationspt"https://translate.webtoons.comBI����ק�>Webtoons.com Translationsbg"https://translate.webtoons.comBI��ȭ���VWebtoons.com Translationsda"https://translate.webtoons.comBI�������JWebtoons.com Translationsnl"https://translate.webtoons.comBI������׏Webtoons.com Translationsro"https://translate.webtoons.comBIٖ�ѽ���~Webtoons.com Translationsmn"https://translate.webtoons.comBI�˄�����#Webtoons.com Translationsel"https://translate.webtoons.comBI����α� Webtoons.com Translationslt"https://translate.webtoons.comBI����̗��PWebtoons.com Translationscs"https://translate.webtoons.comBI����ؓ��Webtoons.com Translationssv"https://translate.webtoons.comBI̡��ތ��8Webtoons.com Translationsbn"https://translate.webtoons.comBI�͘�Ň��Webtoons.com Translationsfa"https://translate.webtoons.comBI��������[Webtoons.com Translationsuk"https://translate.webtoons.comBI�������$Webtoons.com Translationses"https://translate.webtoons.com
�
WeebDex)eu.kanade.tachiyomi.extension.all.weebdex�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.weebdex-v1.4.6.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.weebdex.png"1.4(21.4.68B-��������-WeebDexall"https://weebdex.orgB,���ǀ�׌5WeebDexaf"https://weebdex.orgB,�ݤ�����WeebDexsq"https://weebdex.orgB,�￹����.WeebDexar"https://weebdex.orgB,���Ϸ���/WeebDexaz"https://weebdex.orgB,������#WeebDexeu"https://weebdex.orgB,��������rWeebDexbe"https://weebdex.orgB,��������WeebDexbn"https://weebdex.orgB,���Ӧò�WeebDexbg"https://weebdex.orgB,銴��ɛ�GWeebDexmy"https://weebdex.orgB,���Ր���WeebDexca"https://weebdex.orgB1��������WeebDexzh-Hans"https://weebdex.orgB1����¸��RWeebDexzh-Hant"https://weebdex.orgB,��Ԡ��WeebDexcv"https://weebdex.orgB,�͡���(WeebDexhr"https://weebdex.orgB,��������.WeebDexcs"https://weebdex.orgB,���ǧ���+WeebDexda"https://weebdex.orgB,��ȟ����9WeebDexnl"https://weebdex.orgB,������ݔWeebDexen"https://weebdex.orgB,��៸���xWeebDexeo"https://weebdex.orgB,�ř�湨�
WeebDexet"https://weebdex.orgB-�������LWeebDexfil"https://weebdex.orgB,�����ĿWeebDexfi"https://weebdex.orgB,�ܗ����WeebDexfr"https://weebdex.orgB,������޲"WeebDexka"https://weebdex.orgB,�����Џ�cWeebDexde"https://weebdex.orgB,�������%WeebDexel"https://weebdex.orgB,�±�����TWeebDexhe"https://weebdex.orgB,����Ң��bWeebDexhi"https://weebdex.orgB,����䯉EWeebDexhu"https://weebdex.orgB,����ն��"WeebDexid"https://weebdex.orgB,�ܾ���jWeebDexga"https://weebdex.orgB,�Ӧ��WeebDexit"https://weebdex.orgB,��ٰ����XWeebDexja"https://weebdex.orgB,����˓ԙ2WeebDexjv"https://weebdex.orgB,�٬����pWeebDexkk"https://weebdex.orgB,��ވ����WeebDexko"https://weebdex.orgB,����܊�`WeebDexla"https://weebdex.orgB,��щ���pWeebDexlt"https://weebdex.orgB,�����1WeebDexms"https://weebdex.orgB,��͘����;WeebDexmn"https://weebdex.orgB,ǧ������[WeebDexne"https://weebdex.orgB,�������WeebDexno"https://weebdex.orgB,�Ŋ۲�WeebDexfa"https://weebdex.orgB,�������=WeebDexpl"https://weebdex.orgB,��麥˺�yWeebDexpt"https://weebdex.orgB/������`WeebDexpt-BR"https://weebdex.orgB,����΃��WeebDexro"https://weebdex.orgB,�������WeebDexru"https://weebdex.orgB,���ྌ��WeebDexsr"https://weebdex.orgB,��٩����4WeebDexsk"https://weebdex.orgB,��ʬ��شWeebDexsl"https://weebdex.orgB,���Ǐ��WeebDexes"https://weebdex.orgB0�ԙ���WeebDexes-419"https://weebdex.orgB,�������vWeebDexsv"https://weebdex.orgB,�����ì3WeebDexta"https://weebdex.orgB,ɬ����>WeebDexte"https://weebdex.orgB+ְ�ف��WeebDexth"https://weebdex.orgB,���﫱�WeebDextr"https://weebdex.orgB,��������dWeebDexuk"https://weebdex.orgB,۔�����oWeebDexur"https://weebdex.orgB,�ܫ���߶OWeebDexuz"https://weebdex.orgB,�Ƒٱ���WeebDexvi"https://weebdex.org
�
XArt Hunter,eu.kanade.tachiyomi.extension.all.xarthunter�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.xarthunter-v1.4.2.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.xarthunter.png"1.4(21.4.28B8��џ�殆gXArt Hunterall"https://www.xarthunter.com
�
Xasiat Albums.eu.kanade.tachiyomi.extension.all.xasiatalbums�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.xasiatalbums-v1.4.3.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.xasiatalbums.png"1.4(21.4.38B6�����cXAsiat Albumsall"https://www.xasiat.com
�
XGMN&eu.kanade.tachiyomi.extension.all.xgmn�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.xgmn-v1.4.3.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.xgmn.png"1.4(21.4.38B/����Ǩ�'性感美女all"http://xgmn8.vip
�

Xinmeitulu,eu.kanade.tachiyomi.extension.all.xinmeitulu�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.xinmeitulu-v1.4.7.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.xinmeitulu.png"1.4(21.4.78B7��к���i
Xinmeituluall"https://www.xinmeitulu.com
�
Xiutaku)eu.kanade.tachiyomi.extension.all.xiutaku�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.xiutaku-v1.4.4.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.xiutaku.png"1.4(21.4.48B-���֝��ZXiutakuall"https://xiutaku.com
�
xkcd&eu.kanade.tachiyomi.extension.all.xkcd�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.xkcd-v1.4.16.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.xkcd.png"1.4(21.4.16B&��������xkcden"https://xkcd.comB)�����ʼ�_xkcdes"https://es.xkcd.comB%�Φ��ڊ�qxkcdzh"https://xkcd.twB,���ּ���xkcdfr"https://xkcd.lapin.orgB%��������3xkcdru"https://xkcd.ru
�
Yabai'eu.kanade.tachiyomi.extension.all.yabai�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.yabai-v1.4.3.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.yabai.png"1.4(21.4.38B(��͇����Yabaiall"https://yabai.si
�
Yaoi Manga Online1eu.kanade.tachiyomi.extension.all.yaoimangaonline�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.yaoimangaonline-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.yaoimangaonline.png"1.4(21.4.58B?������nYaoi Manga Onlineall"https://yaoimangaonline.com
�

YellowNote,eu.kanade.tachiyomi.extension.all.yellownote�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.yellownote-v1.4.6.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.yellownote.png"1.4(21.4.68B0�è�����	小黄书all"https://en.xchina.co
�

YSK Comics+eu.kanade.tachiyomi.extension.all.yskcomics�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-all.yskcomics-v1.4.1.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.yskcomics.png"1.4(21.4.1B6������
YSK Comicsar"https://www.ysk-comics.comB6�ְч���
YSK Comicsen"https://www.ysk-comics.com
�
Anyone Manga,eu.kanade.tachiyomi.extension.ar.anyonemanga�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.anyonemanga-v1.4.50.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.anyonemanga.png"1.4(221.4.50B5�����߇�Anyone Mangaar"https://anyonemanga.com
�
Arabs Hentai,eu.kanade.tachiyomi.extension.ar.arabshentai�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.arabshentai-v1.4.4.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.arabshentai.png"1.4(21.4.48B>������Ϙ0هنتاي العربar"https://arabshentai.com
�

Arab Toons*eu.kanade.tachiyomi.extension.ar.arabtoons�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.arabtoons-v1.4.51.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.arabtoons.png"1.4(321.4.518B6薭զ���!عرب تونزar"https://arabtoons.net
�
	ArbxComix*eu.kanade.tachiyomi.extension.ar.arbxcomix�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.arbxcomix-v1.4.50.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.arbxcomix.png"1.4(221.4.508B0��������X	ArbxComixar"https://arbxcomix.com
�

Area Manga*eu.kanade.tachiyomi.extension.ar.areamanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.areamanga-v1.4.34.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.areamanga.png"1.4("21.4.34B<�������pأريا مانجاar"https://ar.kenmanga.com
�

Area Scans*eu.kanade.tachiyomi.extension.ar.areascans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.areascans-v1.4.34.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.areascans.png"1.4("21.4.34B4�Ǌ��
Area Scansar"https://ar.areascans.org
�
AriaToon)eu.kanade.tachiyomi.extension.ar.ariatoon�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.ariatoon-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.ariatoon.png"1.4(21.4.1B.��ΓΠ��qAriaToonar"https://ariatoon.com
�
Azora&eu.kanade.tachiyomi.extension.ar.azora�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.azora-v1.4.67.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.azora.png"1.4(C21.4.67B,��ڒ�й"Azoraar"https://azoramoon.com
�
	Umi Manga+eu.kanade.tachiyomi.extension.ar.beastscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.beastscans-v1.4.33.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.beastscans.png"1.4(!21.4.33B3ь�Џ���X	Umi Mangaar"https://www.umimanga.com
�
Comic Verse+eu.kanade.tachiyomi.extension.ar.comicverse�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.comicverse-v1.4.15.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.comicverse.png"1.4(21.4.15B>琈�����gComic Versear"!https://arcomixverse.blogspot.com
�
Hadess*eu.kanade.tachiyomi.extension.ar.crowscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.crowscans-v1.4.47.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.crowscans.png"1.4(/21.4.47B.������RHadessar"https://www.hadess.xyz
�
Despair Manga-eu.kanade.tachiyomi.extension.ar.despairmanga�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.despairmanga-v1.4.32.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.despairmanga.png"1.4( 21.4.32B8����ׄ�Despair Mangaar"https://despair-manga.net
�
Detective Conan Ar1eu.kanade.tachiyomi.extension.ar.detectiveconanar�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.detectiveconanar-v1.4.53.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.detectiveconanar.png"1.4(521.4.53BV��Č����O"شبكة كونان العربيةar""https://manga.detectiveconanar.com
�
Dilar&eu.kanade.tachiyomi.extension.ar.dilar�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.dilar-v1.4.8.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.dilar.png"1.4(21.4.8B)�Ɗ�ß��iDilarar"https://dilar.tube
�
Empire Webtoon.eu.kanade.tachiyomi.extension.ar.empirewebtoon�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.empirewebtoon-v1.4.56.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.empirewebtoon.png"1.4(821.4.568B<̘�����$Empire Webtoonar"https://webtoonempire-bl.com
�
Golden Manga,eu.kanade.tachiyomi.extension.ar.goldenmanga�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.goldenmanga-v1.4.50.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.goldenmanga.png"1.4(221.4.508B5Ȓ���湶0Golden Mangaar"https://goldenmanga.net
�

Goon Scans*eu.kanade.tachiyomi.extension.ar.goonscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.goonscans-v1.4.32.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.goonscans.png"1.4( 21.4.328B1�ҡ��ۨ�(
Goon Scansar"https://goonscans.org
�
Hentai Slayer-eu.kanade.tachiyomi.extension.ar.hentaislayer�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.hentaislayer-v1.4.6.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.hentaislayer.png"1.4(21.4.68B?ƪߖ��əهنتاي سلايرar"https://hentaislayer.net
�
Hijala'eu.kanade.tachiyomi.extension.ar.hijala�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.hijala-v1.4.35.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.hijala.png"1.4(#21.4.35B*��������Hijalaar"https://hijala.com
�
	ARESManga(eu.kanade.tachiyomi.extension.ar.iimanga�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.iimanga-v1.4.33.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.iimanga.png"1.4(!21.4.33B.���˘	ARESMangaar"https://fl-ares.com
�
Loner Translations2eu.kanade.tachiyomi.extension.ar.lonertranslations�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.lonertranslations-v1.4.13.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.lonertranslations.png"1.4(21.4.13BA��������Loner Translationsar"https://loner-tl.blogspot.com
�
3asq*eu.kanade.tachiyomi.extension.ar.manga3asq�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.manga3asq-v1.4.52.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.manga3asq.png"1.4(421.4.52B9�����مانجا العاشقar"https://3asq.org
�
Manga Ai Land,eu.kanade.tachiyomi.extension.ar.mangaailand�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.mangaailand-v1.4.13.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.mangaailand.png"1.4(21.4.13BA�範����bManga Ai Landar""https://manga-ai-land.blogspot.com
�
MangaHub)eu.kanade.tachiyomi.extension.ar.mangahub�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.mangahub-v1.4.15.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.mangahub.png"1.4(21.4.158B6�Ζ���MangaHubar"https://www.mangaxhentai.com
�
Mangalek)eu.kanade.tachiyomi.extension.ar.mangalek�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.mangalek-v1.4.59.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.mangalek.png"1.4(;21.4.59B���������مانجا ليكar"yhttps://lekmanga.net#, https://lekmanga.online#, https://like-manga.net#, https://lekmanga.site#, https://manga-leko.site
�
	Mangalink*eu.kanade.tachiyomi.extension.ar.mangalink�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.mangalink-v1.4.55.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.mangalink.png"1.4(721.4.55B;����ٙ��1مانجا لينكar"https://link-manga.net
�

MangaLionz+eu.kanade.tachiyomi.extension.ar.mangalionz�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.mangalionz-v1.4.55.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.mangalionz.png"1.4(721.4.55B3�ܠ�����#
MangaLionzar"https://manga-lionz.org
�
	MangaPeak*eu.kanade.tachiyomi.extension.ar.mangapeak�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.mangapeak-v1.4.45.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.mangapeak.png"1.4(-21.4.45B0��������:	MangaPeakar"https://mangapeak.org
�
ProChan)eu.kanade.tachiyomi.extension.ar.mangapro�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.mangapro-v1.4.47.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.mangapro.png"1.4(/21.4.478B,ꣲ�����aProChanar"https://prochan.net
�

MangaRabic+eu.kanade.tachiyomi.extension.ar.mangarabic�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.mangarabic-v1.4.47.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.mangarabic.png"1.4(/21.4.47B2��������
MangaRabicar"https://mangarabic.com
�

Manga Rose*eu.kanade.tachiyomi.extension.ar.mangarose�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.mangarose-v1.4.45.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.mangarose.png"1.4(-21.4.45B1��������b
Manga Rosear"https://mangarose.net
�

MangaSpark+eu.kanade.tachiyomi.extension.ar.mangaspark�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.mangaspark-v1.4.56.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.mangaspark.png"1.4(821.4.56B3��������!
MangaSparkar"https://manga-spark.net
�
Manga Starz+eu.kanade.tachiyomi.extension.ar.mangastarz�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.mangastarz-v1.4.59.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.mangastarz.png"1.4(;21.4.59B4�ù��ʻ�TManga Starzar"https://manga-starz.net
�
	MangaSwat*eu.kanade.tachiyomi.extension.ar.mangaswat�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.mangaswat-v1.4.61.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.mangaswat.png"1.4(=21.4.61B0������ɡj	MangaSwatar"https://meshmanga.com
�
Manga Tales+eu.kanade.tachiyomi.extension.ar.mangatales�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.mangatales-v1.4.4.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.mangatales.png"1.4(21.4.4B7��׾���HManga Talesar"https://www.mangatales.com
�
MangaTek)eu.kanade.tachiyomi.extension.ar.mangatek�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.mangatek-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.mangatek.png"1.4(21.4.2B.���܆��MangaTekar"https://mangatek.com
�
	MangaTime*eu.kanade.tachiyomi.extension.ar.mangatime�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.mangatime-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.mangatime.png"1.4(21.4.1B0��������	MangaTimear"https://mangatime.org
�
Manga Trend+eu.kanade.tachiyomi.extension.ar.mangatrend�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.mangatrend-v1.4.30.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.mangatrend.png"1.4(21.4.30B4��ސ����0Manga Trendar"https://mangaatrend.net
�
MangaTuk)eu.kanade.tachiyomi.extension.ar.mangatuk�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.mangatuk-v1.4.50.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.mangatuk.png"1.4(221.4.508B.����ᵄ�:MangaTukar"https://mangatuk.com
�
Mangax Core+eu.kanade.tachiyomi.extension.ar.mangaxcore�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.mangaxcore-v1.4.50.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.mangaxcore.png"1.4(221.4.50B3�ʮ�����}Mangax Corear"https://mangaxcore.xyz
�
Manhatic)eu.kanade.tachiyomi.extension.ar.manhatic�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.manhatic-v1.4.50.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.manhatic.png"1.4(221.4.508B.������ȎManhaticar"https://manhatic.com
�
Manhatok)eu.kanade.tachiyomi.extension.ar.manhatok�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.manhatok-v1.4.14.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.manhatok.png"1.4(21.4.14B7������
Manhatokar"https://manhatok.blogspot.com
�
Murim&eu.kanade.tachiyomi.extension.ar.murim�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.murim-v1.4.14.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.murim.png"1.4(21.4.14B-�����ǁ�DMurimar"https://www.murim.site
�
Niji Translations1eu.kanade.tachiyomi.extension.ar.nijitranslations�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.nijitranslations-v1.4.46.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.nijitranslations.png"1.4(.21.4.46B@����ͮ��Niji Translationsar"https://niji-translations.com
�
Oduto&eu.kanade.tachiyomi.extension.ar.oduto�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.oduto-v1.4.1.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.oduto.png"1.4(21.4.1B1��������Odutoar"https://nb19u.blogspot.com
�
Olaoe&eu.kanade.tachiyomi.extension.ar.olaoe�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.olaoe-v1.4.45.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.olaoe.png"1.4(-21.4.45B)�˓����ZOlaoear"https://olaoe.cyou
�
Onma%eu.kanade.tachiyomi.extension.ar.onma�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.onma-v1.4.16.apkuhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.onma.png"1.4(21.4.16B;�������مانجا اون لاينar"https://onma.me
�

Orca Manga*eu.kanade.tachiyomi.extension.ar.orcamanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.orcamanga-v1.4.13.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.orcamanga.png"1.4(21.4.13B6���և���N
Orca Mangaar"https://www.orcamanga.site
�
Paradise BL+eu.kanade.tachiyomi.extension.ar.paradisebl�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.paradisebl-v1.4.50.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.paradisebl.png"1.4(221.4.508B4�ი����DParadise BLar"https://paradise-bl.com
�
Rocks Manga+eu.kanade.tachiyomi.extension.ar.rocksmanga�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.rocksmanga-v1.4.53.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.rocksmanga.png"1.4(521.4.53B3���ۘ���-Rocks Mangaar"https://rocksmanga.com
�
Scans 4u(eu.kanade.tachiyomi.extension.ar.scans4u�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.scans4u-v1.4.18.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.scans4u.png"1.4(21.4.18B-����ė�Scans 4uar"https://4uscans.com
�
Shqqaa Manga'eu.kanade.tachiyomi.extension.ar.shqqaa�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.shqqaa-v1.4.2.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.shqqaa.png"1.4(21.4.2B;����ʝ��Vمانجا شقاعar"https://www.shqqaa.com
�
StellarSaber-eu.kanade.tachiyomi.extension.ar.stellarsaber�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.stellarsaber-v1.4.32.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.stellarsaber.png"1.4( 21.4.32B6ۊ®Ӽ��StellarSaberar"https://stellarsaber.pro
�
Team X&eu.kanade.tachiyomi.extension.ar.teamx�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.teamx-v1.4.29.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.teamx.png"1.4(21.4.29B/⼚߈���9Team Xar"https://olympustaff.com
�
	WaveTeamy*eu.kanade.tachiyomi.extension.ar.waveteamy�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.waveteamy-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.waveteamy.png"1.4(21.4.2B0���޹���	WaveTeamyar"https://waveteamy.com
�
XSano Manga+eu.kanade.tachiyomi.extension.ar.xsanomanga�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.xsanomanga-v1.4.13.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.xsanomanga.png"1.4(21.4.13B8��������UXSano Mangaar"https://www.xsano-manga.com
�
Yokai&eu.kanade.tachiyomi.extension.ar.yokai�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.yokai-v1.4.15.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.yokai.png"1.4(21.4.15B6ՔЍ����<Yokaiar"https://yokai-team.blogspot.com
�
Yona Bar(eu.kanade.tachiyomi.extension.ar.yonabar�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.yonabar-v1.4.50.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.yonabar.png"1.4(221.4.508B-�����ݧ�oYona Barar"https://yonaber.com
�
Yuri Moon Sub,eu.kanade.tachiyomi.extension.ar.yurimoonsub�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ar.yurimoonsub-v1.4.15.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ar.yurimoonsub.png"1.4(21.4.158B?��������lYuri Moon Subar" https://yurimoonsub.blogspot.com
�

Utsukushii+eu.kanade.tachiyomi.extension.bg.utsukushii�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-bg.utsukushii-v1.4.14.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.bg.utsukushii.png"1.4(21.4.14B5������ϓ=
Utsukushiibg"https://utsukushii-bg.com
�
Fansubs.cat+eu.kanade.tachiyomi.extension.ca.fansubscat�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ca.fansubscat-v1.4.6.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ca.fansubscat.png"1.4(21.4.6B6��������7Fansubs.catca"https://manga.fansubs.cat
�

Hentai.cat1eu.kanade.tachiyomi.extension.ca.fansubscathentai�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ca.fansubscathentai-v1.4.6.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ca.fansubscathentai.png"1.4(21.4.68B4���ݙːi
Hentai.catca"https://manga.hentai.cat
�
Evil production/eu.kanade.tachiyomi.extension.cs.evilproduction�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-cs.evilproduction-v1.4.32.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.cs.evilproduction.png"1.4( 21.4.328B6����î�Evil productioncs"https://evil-manga.eu
�

Manga Tube*eu.kanade.tachiyomi.extension.de.mangatube�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-de.mangatube-v1.4.3.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.de.mangatube.png"1.4(21.4.3B1�ր���̊_
Manga Tubede"https://manga-tube.me
�
Adult Webtoon-eu.kanade.tachiyomi.extension.en.adultwebtoon�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.adultwebtoon-v1.4.49.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.adultwebtoon.png"1.4(121.4.498B7ݚэ����+Adult Webtoonen"https://adultwebtoon.com
�

Aein Scans*eu.kanade.tachiyomi.extension.en.aeinscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.aeinscans-v1.4.19.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.aeinscans.png"1.4(21.4.19B1����ތ��G
Aein Scansen"https://aeinscans.com
�

Akai Comic*eu.kanade.tachiyomi.extension.en.akaicomic�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.akaicomic-v1.4.3.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.akaicomic.png"1.4(21.4.3B1��ۖ���
Akai Comicen"https://akaicomic.org
�
Alandal(eu.kanade.tachiyomi.extension.en.alandal�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.alandal-v1.4.2.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.alandal.png"1.4(21.4.2B,��Ƈ�ɕ�Alandalen"https://alandal.com
�
AllManga)eu.kanade.tachiyomi.extension.en.allanime�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.allanime-v1.4.19.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.allanime.png"1.4(21.4.198B-��ظֹ��AAllMangaen"https://allmanga.to
�
AllPornComic-eu.kanade.tachiyomi.extension.en.allporncomic�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.allporncomic-v1.4.52.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.allporncomic.png"1.4(421.4.528B6��������vAllPornComicen"https://allporncomic.com
�
AllPornComic.io/eu.kanade.tachiyomi.extension.en.allporncomicio�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.allporncomicio-v1.4.50.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.allporncomicio.png"1.4(221.4.508B8�ѹ�����\AllPornComic.ioen"https://allporncomic.io
�
Anisa Scans+eu.kanade.tachiyomi.extension.en.anisascans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.anisascans-v1.4.51.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.anisascans.png"1.4(321.4.518B2Յ���Î�{Anisa Scansen"https://anisascans.in
�
	AP Comics)eu.kanade.tachiyomi.extension.en.apcomics�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.apcomics-v1.4.50.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.apcomics.png"1.4(221.4.508B/���ѵ���l	AP Comicsen"https://apcomics.org
�

Aqua Manga*eu.kanade.tachiyomi.extension.en.aquamanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.aquamanga-v1.4.61.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.aquamanga.png"1.4(=21.4.61B2������
Aqua Mangaen"https://aquareader.org
�
Arcanescans,eu.kanade.tachiyomi.extension.en.arcanescans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.arcanescans-v1.4.45.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.arcanescans.png"1.4(-21.4.45B4��������3Arcanescansen"https://arcanescans.com
�
Arc-Relight+eu.kanade.tachiyomi.extension.en.arcrelight�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.arcrelight-v1.4.15.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.arcrelight.png"1.4(21.4.15B4�����ƙ�^Arc-Relighten"https://arc-relight.com
�
Arena Scans+eu.kanade.tachiyomi.extension.en.arenascans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.arenascans-v1.4.32.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.arenascans.png"1.4( 21.4.32B2����ٽ��zArena Scansen"https://arenascan.com
�

Armageddon+eu.kanade.tachiyomi.extension.en.armageddon�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.armageddon-v1.4.34.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.armageddon.png"1.4("21.4.348B7���Ꭹ��
Armageddonen"https://www.silentquill.net
�
	Art Lapsa)eu.kanade.tachiyomi.extension.en.artlapsa�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.artlapsa-v1.4.25.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.artlapsa.png"1.4(21.4.25B/�����Ș
	Art Lapsaen"https://artlapsa.com
�
Arven Scans,eu.kanade.tachiyomi.extension.en.arvencomics�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.arvencomics-v1.4.52.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.arvencomics.png"1.4(421.4.52B4�ޢ�����Arven Scansen"https://arvencomics.com
�
Vortex Scans+eu.kanade.tachiyomi.extension.en.arvenscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.arvenscans-v1.4.61.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.arvenscans.png"1.4(=21.4.61B5��������#Vortex Scansen"https://vortexscans.org
�

Arya Scans*eu.kanade.tachiyomi.extension.en.aryascans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.aryascans-v1.4.51.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.aryascans.png"1.4(321.4.51B6˲������i
Arya Scansen"https://brainrotcomics.com
�
AsiaToon)eu.kanade.tachiyomi.extension.en.asiatoon�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.asiatoon-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.asiatoon.png"1.4(21.4.18B.��ݬ��vAsiaToonen"https://asiatoon.net
�
Asmodeus Scans)eu.kanade.tachiyomi.extension.en.asmotoon�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.asmotoon-v1.4.22.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.asmotoon.png"1.4(21.4.22B4����ж��HAsmodeus Scansen"https://asmotoon.com
�
Assorted Scans.eu.kanade.tachiyomi.extension.en.assortedscans�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.assortedscans-v1.4.17.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.assortedscans.png"1.4(21.4.17B9��������pAssorted Scansen"https://assortedscans.com
�
Asura Scans+eu.kanade.tachiyomi.extension.en.asurascans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.asurascans-v1.4.62.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.asurascans.png"1.4(>21.4.62B3�������VAsura Scansen"https://asurascans.com
�
Athrea Scans,eu.kanade.tachiyomi.extension.en.athreascans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.athreascans-v1.4.33.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.athreascans.png"1.4(!21.4.338B5�㠏����Athrea Scansen"https://athreascans.com
�
Atsumaru)eu.kanade.tachiyomi.extension.en.atsumaru�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.atsumaru-v1.4.19.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.atsumaru.png"1.4(21.4.198B*�à�� Atsumaruen"https://atsu.moe
�
aurora'eu.kanade.tachiyomi.extension.en.aurora�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.aurora-v1.4.4.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.aurora.png"1.4(21.4.4B/��ܤӚ��~Auroraen"https://comicaurora.com
�
azComic(eu.kanade.tachiyomi.extension.en.azcomic�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.azcomic-v1.4.3.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.azcomic.png"1.4(21.4.3B,ī�˥ؗFazComicen"https://azcomic.com
�
Omoi&eu.kanade.tachiyomi.extension.en.azuki�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.azuki-v1.4.2.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.azuki.png"1.4(21.4.28B*��¼���qOmoien"https://www.omoi.com
�

Baek Toons*eu.kanade.tachiyomi.extension.en.baektoons�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.baektoons-v1.4.30.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.baektoons.png"1.4(21.4.30B1�������
Baek Toonsen"https://baektoons.com
�
Bakkin'eu.kanade.tachiyomi.extension.en.bakkin�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.bakkin-v1.4.7.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.bakkin.png"1.4(21.4.7B2ߵ�߷���Bakkinen"https://bakkin.moe/reader/
�
Bakkin Self-hosted1eu.kanade.tachiyomi.extension.en.bakkinselfhosted�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.bakkinselfhosted-v1.4.7.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.bakkinselfhosted.png"1.4(21.4.7B5��������VBakkin Self-hosteden"http://127.0.0.1/
�
BatCave(eu.kanade.tachiyomi.extension.en.batcave�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.batcave-v1.4.6.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.batcave.png"1.4(21.4.6B,����񄦀gBatCaveen"https://batcave.biz
�
!Battle In 5 Seconds After Meeting@eu.kanade.tachiyomi.extension.en.battleinfivesecondsaftermeeting�
�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.battleinfivesecondsaftermeeting-v1.4.50.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.battleinfivesecondsaftermeeting.png"1.4(221.4.50BJ�犋����#!Battle In 5 Seconds After Meetingen"https://www.deatte5.com
�
Bbato&eu.kanade.tachiyomi.extension.en.bbato�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.bbato-v1.4.1.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.bbato.png"1.4(21.4.18B(����Ϡ��Bbatoen"https://bbato.com
�
	BeeHentai*eu.kanade.tachiyomi.extension.en.beehentai�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.beehentai-v1.4.24.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.beehentai.png"1.4(21.4.248B0�����ٖ�5	BeeHentaien"https://beehentai.com
�

BookWalker+eu.kanade.tachiyomi.extension.en.bookwalker�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.bookwalker-v1.4.6.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.bookwalker.png"1.4(21.4.68B2������&
BookWalkeren"https://bookwalker.com
�
Borat Scans+eu.kanade.tachiyomi.extension.en.boratscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.boratscans-v1.4.50.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.boratscans.png"1.4(221.4.50B3�������mBorat Scansen"https://boratscans.com
�
	BoxManhwa*eu.kanade.tachiyomi.extension.en.boxmanhwa�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.boxmanhwa-v1.4.23.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.boxmanhwa.png"1.4(21.4.238B0����ߣ�m	BoxManhwaen"https://boxmanhwa.com
�
Broccoli Soup-eu.kanade.tachiyomi.extension.en.broccolisoup�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.broccolisoup-v1.4.1.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.broccolisoup.png"1.4(21.4.1B8�������Broccoli Soupen"https://politeandgood.com
�
	Bun Manga)eu.kanade.tachiyomi.extension.en.bunmanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.bunmanga-v1.4.50.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.bunmanga.png"1.4(221.4.50B/���ڒ��R	Bun Mangaen"https://bunmanga.com
�

buttsmithy+eu.kanade.tachiyomi.extension.en.buttsmithy�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.buttsmithy-v1.4.4.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.buttsmithy.png"1.4(21.4.48B9������G
Buttsmithyen"https://incase.buttsmithy.com
�
Clone Manga+eu.kanade.tachiyomi.extension.en.clonemanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.clonemanga-v1.4.3.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.clonemanga.png"1.4(21.4.3B9��������OClone Mangaen"https://manga.clone-army.org
�
Clown Corps+eu.kanade.tachiyomi.extension.en.clowncorps�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.clowncorps-v1.4.3.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.clowncorps.png"1.4(21.4.3B3��������Clown Corpsen"https://clowncorps.net
�
CManhua(eu.kanade.tachiyomi.extension.en.cmanhua�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.cmanhua-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.cmanhua.png"1.4(21.4.18B,�ݯ�����qCManhuaen"https://cmanhua.com
�
Cocomic(eu.kanade.tachiyomi.extension.en.cocomic�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.cocomic-v1.4.52.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.cocomic.png"1.4(421.4.528B+���߸���1Cocomicen"https://cocomic.co
�
Coffee Manga,eu.kanade.tachiyomi.extension.en.coffeemanga�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.coffeemanga-v1.4.55.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.coffeemanga.png"1.4(721.4.558B5��ʫ����iCoffee Mangaen"https://coffeemanga.ink
�
Collected Curios0eu.kanade.tachiyomi.extension.en.collectedcurios�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.collectedcurios-v1.4.2.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.collectedcurios.png"1.4(21.4.2BAܛ����ިCollected Curiosen"https://www.collectedcurios.com
�
Comic Asura+eu.kanade.tachiyomi.extension.en.comicasura�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.comicasura-v1.4.34.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.comicasura.png"1.4("21.4.348B3�;����Comic Asuraen"https://comicasura.net
�
Comic CX(eu.kanade.tachiyomi.extension.en.comiccx�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.comiccx-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.comiccx.png"1.4(21.4.18B*÷������Comic CXen"https://comic.cx
�
ComicHubFree-eu.kanade.tachiyomi.extension.en.comichubfree�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.comichubfree-v1.4.3.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.comichubfree.png"1.4(21.4.3B6巵����� ComicHubFreeen"https://comichubfree.com
�
ComicK Fanmade*eu.kanade.tachiyomi.extension.en.comickfan�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.comickfan-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.comickfan.png"1.4(21.4.28B5�팏̺��ComicK Fanmadeen"https://comickfan.com
�

Manhuagold*eu.kanade.tachiyomi.extension.en.comickiba�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.comickiba-v1.4.37.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.comickiba.png"1.4(%21.4.378B2��λ�ŵ�s
Manhuagolden"https://manhuagold.top
�
	ComicLand*eu.kanade.tachiyomi.extension.en.comicland�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.comicland-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.comicland.png"1.4(21.4.18B0��������X	ComicLanden"https://comicland.org
�
Comics Land+eu.kanade.tachiyomi.extension.en.comicsland�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.comicsland-v1.4.32.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.comicsland.png"1.4( 21.4.328B3�����ȃ� Comics Landen"https://comicsland.org
�
Comix&eu.kanade.tachiyomi.extension.en.comix�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.comix-v1.4.30.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.comix.png"1.4(21.4.308B'���牆��hComixen"https://comix.to
�

Crow Scans*eu.kanade.tachiyomi.extension.en.crowscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.crowscans-v1.4.32.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.crowscans.png"1.4( 21.4.32B1����ɓ��
Crow Scansen"https://crowscans.xyz
�
Cucumber Manga.eu.kanade.tachiyomi.extension.en.cucumbermanga�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.cucumbermanga-v1.4.50.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.cucumbermanga.png"1.4(221.4.508B9�������5Cucumber Mangaen"https://cucumbermanga.com
�
CulturedWorks.eu.kanade.tachiyomi.extension.en.culturedworks�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.culturedworks-v1.4.33.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.culturedworks.png"1.4(!21.4.338B8����Ę�CulturedWorksen"https://culturedworks.com
�
Cutie Comics,eu.kanade.tachiyomi.extension.en.cutiecomics�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.cutiecomics-v1.4.5.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.cutiecomics.png"1.4(21.4.58B5��ٲ����lCutie Comicsen"https://cutiecomics.com
�
Danke fürs Lesen/eu.kanade.tachiyomi.extension.en.dankefurslesen�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.dankefurslesen-v1.4.7.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.dankefurslesen.png"1.4(21.4.78B4�������Danke fürs Lesenen"https://danke.moe
�
Dark Legacy Comics1eu.kanade.tachiyomi.extension.en.darklegacycomics�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.darklegacycomics-v1.4.1.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.darklegacycomics.png"1.4(21.4.1BD����ǲ��Dark Legacy Comicsen" https://www.darklegacycomics.com
�

Dark Scans*eu.kanade.tachiyomi.extension.en.darkscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.darkscans-v1.4.52.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.darkscans.png"1.4(421.4.52B1�㈤����r
Dark Scansen"https://darkscans.net
�
Dark Science,eu.kanade.tachiyomi.extension.en.darkscience�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.darkscience-v1.4.1.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.darkscience.png"1.4(21.4.1B6��������Dark Scienceen"https://dresdencodak.com
�
Darths & Droids-eu.kanade.tachiyomi.extension.en.darthsdroids�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.darthsdroids-v1.4.2.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.darthsdroids.png"1.4(21.4.2B@�����뒮Darths & Droidsen"https://www.darthsanddroids.net
�
DAYcomics.me,eu.kanade.tachiyomi.extension.en.daycomicsme�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.daycomicsme-v1.4.2.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.daycomicsme.png"1.4(21.4.28B2��������uDAYcomics.meen"https://daycomics.me
�
Death Toll Scans/eu.kanade.tachiyomi.extension.en.deathtollscans�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.deathtollscans-v1.4.5.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.deathtollscans.png"1.4(21.4.5BC���Ʈ���ADeath Toll Scansen"!https://reader.deathtollscans.net
�
Decadence Scans/eu.kanade.tachiyomi.extension.en.decadencescans�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.decadencescans-v1.4.52.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.decadencescans.png"1.4(421.4.528BB�ҿ��gDecadence Scansen"!https://reader.decadencescans.com
�

DFlowScans+eu.kanade.tachiyomi.extension.en.dflowscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.dflowscans-v1.4.1.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.dflowscans.png"1.4(21.4.1B8�怗����O
DFlowScansen"https://dflow.alwaysdata.net
�
Digital Comic Museum3eu.kanade.tachiyomi.extension.en.digitalcomicmuseum�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.digitalcomicmuseum-v1.4.4.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.digitalcomicmuseum.png"1.4(21.4.4BD��­���Digital Comic Museumen"https://digitalcomicmuseum.com
�

Diva Scans*eu.kanade.tachiyomi.extension.en.divascans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.divascans-v1.4.23.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.divascans.png"1.4(21.4.238B0���Ѻ�ÉL
Diva Scansen"https://divatoon.com
�
Doujin.io - J18)eu.kanade.tachiyomi.extension.en.doujinio�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.doujinio-v1.4.3.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.doujinio.png"1.4(21.4.38B2ʰ�����&Doujin.io - J18en"https://doujin.io
�
Doujins(eu.kanade.tachiyomi.extension.en.doujins�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.doujins-v1.4.6.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.doujins.png"1.4(21.4.68B,��ʀ����3Doujinsen"https://doujins.com
�
	DragonTea*eu.kanade.tachiyomi.extension.en.dragontea�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.dragontea-v1.4.55.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.dragontea.png"1.4(721.4.55B0�贙���[	DragonTeaen"https://dragontea.ink
�
Drake Scans+eu.kanade.tachiyomi.extension.en.drakescans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.drakescans-v1.4.48.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.drakescans.png"1.4(021.4.48B3��ă����rDrake Scansen"https://drakecomic.org
�
	Dxd Scans)eu.kanade.tachiyomi.extension.en.dxdscans�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.dxdscans-v1.4.18.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.dxdscans.png"1.4(21.4.188B/���𩲡�S	Dxd Scansen"https://dxdscans.com
�
Dynasty(eu.kanade.tachiyomi.extension.en.dynasty�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.dynasty-v1.4.30.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.dynasty.png"1.4(21.4.308B8���ۡ�Ƥ	Dynasty Scansen"https://dynasty-scans.com
�
Eggporncomics.eu.kanade.tachiyomi.extension.en.eggporncomics�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.eggporncomics-v1.4.3.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.eggporncomics.png"1.4(21.4.38B8��ۗꐗ�dEggporncomicsen"https://eggporncomics.com
�
El Goonish Shive*eu.kanade.tachiyomi.extension.en.egscomics�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.egscomics-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.egscomics.png"1.4(21.4.2B;�����\El Goonish Shiveen"https://www.egscomics.com
�
18 Porn Comic2eu.kanade.tachiyomi.extension.en.eighteenporncomic�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.eighteenporncomic-v1.4.3.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.eighteenporncomic.png"1.4(21.4.38B6��͎����G18 Porn Comicen"https://18porncomic.com
�
8Muses+eu.kanade.tachiyomi.extension.en.eightmuses�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.eightmuses-v1.4.2.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.eightmuses.png"1.4(21.4.28B1������8Musesen"https://comics.8muses.com
�
Elan School+eu.kanade.tachiyomi.extension.en.elanschool�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.elanschool-v1.4.1.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.elanschool.png"1.4(21.4.1B0����郔�UElan Schoolen"https://elan.school
�
Elf Toon(eu.kanade.tachiyomi.extension.en.elftoon�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.elftoon-v1.4.34.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.elftoon.png"1.4("21.4.34B-��������6Elf Toonen"https://elftoon.com
�
emaqi&eu.kanade.tachiyomi.extension.en.emaqi�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.emaqi-v1.4.1.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.emaqi.png"1.4(21.4.18B(��������.emaqien"https://emaqi.com
�
	EpicManga*eu.kanade.tachiyomi.extension.en.epicmanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.epicmanga-v1.4.50.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.epicmanga.png"1.4(221.4.508B/𖿊��Σo	EpicMangaen"https://epicmanga.co
�

Eris Scans*eu.kanade.tachiyomi.extension.en.erisscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.erisscans-v1.4.20.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.erisscans.png"1.4(21.4.208B1��̴����s
Eris Scansen"https://erisscans.com
�
Ero18x'eu.kanade.tachiyomi.extension.en.ero18x�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.ero18x-v1.4.50.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ero18x.png"1.4(221.4.508B*����۱�QEro18xen"https://ero18x.com
�
Erofus'eu.kanade.tachiyomi.extension.en.erofus�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.erofus-v1.4.3.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.erofus.png"1.4(21.4.38B.ȴ����߲*Erofusen"https://www.erofus.com
�
Scythe Scans*eu.kanade.tachiyomi.extension.en.erosscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.erosscans-v1.4.39.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.erosscans.png"1.4('21.4.39B5�������Scythe Scansen"https://scythescans.com
�
	Eva Scans)eu.kanade.tachiyomi.extension.en.evascans�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.evascans-v1.4.34.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.evascans.png"1.4("21.4.34B/�Γ�����	Eva Scansen"https://evascans.org
�
Evil Flowers,eu.kanade.tachiyomi.extension.en.evilflowers�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.evilflowers-v1.4.50.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.evilflowers.png"1.4(221.4.50B5�����̡�@Evil Flowersen"https://evilflowers.com
�
Existential Comics2eu.kanade.tachiyomi.extension.en.existentialcomics�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.existentialcomics-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.existentialcomics.png"1.4(21.4.5BA�޶�����	Existential Comicsen"https://existentialcomics.com
�
Cyanide & Happiness(eu.kanade.tachiyomi.extension.en.explosm�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.explosm-v1.4.5.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.explosm.png"1.4(21.4.5B8��������Cyanide & Happinessen"https://explosm.net
�
EZmanga(eu.kanade.tachiyomi.extension.en.ezmanga�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.ezmanga-v1.4.62.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ezmanga.png"1.4(>21.4.62B,�،�ĵ�.EZmangaen"https://ezmanga.org
�
Fable Scans+eu.kanade.tachiyomi.extension.en.fablescans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.fablescans-v1.4.32.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.fablescans.png"1.4( 21.4.328B3�̤���CFable Scansen"https://fablescans.com
�
Fairy Scans+eu.kanade.tachiyomi.extension.en.fairyscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.fairyscans-v1.4.33.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.fairyscans.png"1.4(!21.4.338B3����ȣ��lFairy Scansen"https://fairyscans.com
�
	Firescans*eu.kanade.tachiyomi.extension.en.firescans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.firescans-v1.4.54.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.firescans.png"1.4(621.4.54B0�Ğ��ܴ�O	Firescansen"https://firescans.xyz
�
First Kiss Manhua0eu.kanade.tachiyomi.extension.en.firstkissmanhua�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.firstkissmanhua-v1.4.45.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.firstkissmanhua.png"1.4(-21.4.45B<�Ĵݘē�=First Kiss Manhuaen"https://1stkissmanhua.net
�
Flame Comics,eu.kanade.tachiyomi.extension.en.flamecomics�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.flamecomics-v1.4.49.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.flamecomics.png"1.4(121.4.49B5����욈�vFlame Comicsen"https://flamecomics.xyz
�
Free Comic Online0eu.kanade.tachiyomi.extension.en.freecomiconline�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.freecomiconline-v1.4.45.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.freecomiconline.png"1.4(-21.4.458B=���ߓ��Free Comic Onlineen"https://freecomiconline.me
�

Free Manga*eu.kanade.tachiyomi.extension.en.freemanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.freemanga-v1.4.48.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.freemanga.png"1.4(021.4.488B0�Ǟ���͔:
Free Mangaen"https://freemanga.me
�
FreeMangaTop-eu.kanade.tachiyomi.extension.en.freemangatop�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.freemangatop-v1.4.48.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.freemangatop.png"1.4(021.4.488B6ؤ�Ƹ���FreeMangaTopen"https://freemangatop.com
�
Frieren Online.eu.kanade.tachiyomi.extension.en.frierenonline�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.frierenonline-v1.4.50.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.frierenonline.png"1.4(221.4.50B9���ȹ��1Frieren Onlineen"https://www.frieren.online
�

GakaMangas+eu.kanade.tachiyomi.extension.en.gakamangas�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.gakamangas-v1.4.50.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.gakamangas.png"1.4(221.4.50B2�������H
GakaMangasen"https://gakamangas.com
�
GalaxyDegenScans1eu.kanade.tachiyomi.extension.en.galaxydegenscans�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.galaxydegenscans-v1.4.54.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.galaxydegenscans.png"1.4(621.4.548B5�Ͱ����?GalaxyDegenScansen"https://gdscans.com
�
Galaxy Manga,eu.kanade.tachiyomi.extension.en.galaxymanga�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.galaxymanga-v1.4.32.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.galaxymanga.png"1.4( 21.4.328B4؜������*Galaxy Mangaen"https://galaxymanga.io
�

GEDE Comix*eu.kanade.tachiyomi.extension.en.gedecomix�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.gedecomix-v1.4.50.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.gedecomix.png"1.4(221.4.508B1�מ�����6
GEDE Comixen"https://gedecomix.com
�

GingeRTooN+eu.kanade.tachiyomi.extension.en.gingertoon�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.gingertoon-v1.4.50.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.gingertoon.png"1.4(221.4.508B2��Ś���:
GingeRTooNen"https://gingertoon.com
�
GirlsTop)eu.kanade.tachiyomi.extension.en.girlstop�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.girlstop-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.girlstop.png"1.4(21.4.18B2�����ǟ�GirlsTopen"https://en.girlstop.info
�
Goda%eu.kanade.tachiyomi.extension.en.goda�
ghttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.goda-v1.4.3.apkuhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.goda.png"1.4(21.4.3B-⏣�����;Godaen"https://manhuascans.org
�
Gourmet Scans-eu.kanade.tachiyomi.extension.en.gourmetscans�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.gourmetscans-v1.4.50.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.gourmetscans.png"1.4(221.4.508B;��갲�ģ3Gourmet Scansen"https://gourmetsupremacy.com
�
Greed Scans+eu.kanade.tachiyomi.extension.en.greedscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.greedscans-v1.4.32.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.greedscans.png"1.4( 21.4.32B2������Greed Scansen"https://gojoscans.com
�

Grim Scans*eu.kanade.tachiyomi.extension.en.grimscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.grimscans-v1.4.20.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.grimscans.png"1.4(21.4.20B1������Șw
Grim Scansen"https://grimscans.com
�
Grrl Power Comic*eu.kanade.tachiyomi.extension.en.grrlpower�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.grrlpower-v1.4.4.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.grrlpower.png"1.4(21.4.4B@��ښ����Grrl Power Comicen"https://www.grrlpowercomic.com
�
Gunnerkrigg Court1eu.kanade.tachiyomi.extension.en.gunnerkriggcourt�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.gunnerkriggcourt-v1.4.3.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.gunnerkriggcourt.png"1.4(21.4.3B>��ֆ����SGunnerkrigg Courten"https://www.gunnerkrigg.com
�
Guya%eu.kanade.tachiyomi.extension.en.guya�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.guya-v1.4.25.apkuhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.guya.png"1.4(21.4.25B-������خ@Guyaen"https://guya.cubari.moe
�
Gone with the Blastwave%eu.kanade.tachiyomi.extension.en.gwtb�
ghttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.gwtb-v1.4.3.apkuhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.gwtb.png"1.4(21.4.3BH܃߃����7Gone with the Blastwaveen"https://www.blastwave-comic.com
�
Hachi&eu.kanade.tachiyomi.extension.en.hachi�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hachi-v1.4.2.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hachi.png"1.4(21.4.28B(�������Hachien"https://hachi.moe
�
	Hachirumi*eu.kanade.tachiyomi.extension.en.hachirumi�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hachirumi-v1.4.7.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hachirumi.png"1.4(21.4.78B0�������	Hachirumien"https://hachirumi.com
�
Hades Scans+eu.kanade.tachiyomi.extension.en.hadesscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hadesscans-v1.4.33.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hadesscans.png"1.4(!21.4.33B3����Ɣ�<Hades Scansen"https://hadesscans.com
�
Hanuman Scan,eu.kanade.tachiyomi.extension.en.hanumanscan�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hanumanscan-v1.4.30.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hanumanscan.png"1.4(21.4.30B5�������kHanuman Scanen"https://hanumanscan.com
�
	Harimanga*eu.kanade.tachiyomi.extension.en.harimanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.harimanga-v1.4.55.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.harimanga.png"1.4(721.4.558B/Ӆ������8	Harimangaen"https://harimanga.me
�
Hentai20)eu.kanade.tachiyomi.extension.en.hentai20�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentai20-v1.4.39.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentai20.png"1.4('21.4.398B-�����bHentai20en"https://hentai20.io
�
Hentai2Read,eu.kanade.tachiyomi.extension.en.hentai2read�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentai2read-v1.4.18.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentai2read.png"1.4(21.4.188B4���Ɣ��sHentai2Readen"https://hentai2read.com
�
Hentai3z.CC+eu.kanade.tachiyomi.extension.en.hentai3zcc�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentai3zcc-v1.4.3.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentai3zcc.png"1.4(21.4.38B0樳����Hentai3z.CCen"https://hentai3z.cc
�
Hentai4Free,eu.kanade.tachiyomi.extension.en.hentai4free�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentai4free-v1.4.50.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentai4free.png"1.4(221.4.508B4�쒢����[Hentai4Freeen"https://hentai4free.net
�
	HentaiDex*eu.kanade.tachiyomi.extension.en.hentaidex�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentaidex-v1.4.34.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaidex.png"1.4("21.4.348B0��������	HentaiDexen"https://dexhentai.com
�

Hentaidexy+eu.kanade.tachiyomi.extension.en.hentaidexy�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentaidexy-v1.4.34.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaidexy.png"1.4("21.4.348B0Ӷ���ڿ�,
Hentaidexyen"https://dexyscan.com
�

HentaiHere+eu.kanade.tachiyomi.extension.en.hentaihere�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentaihere-v1.4.7.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaihere.png"1.4(21.4.78B2���Ŕ���d
HentaiHereen"https://hentaihere.com
�
	HentaiKun*eu.kanade.tachiyomi.extension.en.hentaikun�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentaikun-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaikun.png"1.4(21.4.18B0�ׂ쿸�!	HentaiKunen"https://hentaikun.com
�
Hentai Manga,eu.kanade.tachiyomi.extension.en.hentaimanga�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentaimanga-v1.4.47.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaimanga.png"1.4(/21.4.478B4��˾����+Hentai Mangaen"https://hentaimanga.me
�
HentaiNexus,eu.kanade.tachiyomi.extension.en.hentainexus�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentainexus-v1.4.17.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentainexus.png"1.4(21.4.178B4��������kHentaiNexusen"https://hentainexus.com
�

HentaiRead+eu.kanade.tachiyomi.extension.en.hentairead�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentairead-v1.4.60.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentairead.png"1.4(<21.4.608B2��ࡲ���
HentaiReaden"https://hentairead.com
�
HentaiRead.io-eu.kanade.tachiyomi.extension.en.hentaireadio�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentaireadio-v1.4.1.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaireadio.png"1.4(21.4.18B4���䫙��HentaiRead.ioen"https://hentairead.io
�
	HentaiSco*eu.kanade.tachiyomi.extension.en.hentaisco�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentaisco-v1.4.50.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaisco.png"1.4(221.4.508B/֎ܯ���]	HentaiScoen"https://hentaisco.cc
�
HentaiWebtoon.eu.kanade.tachiyomi.extension.en.hentaiwebtoon�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentaiwebtoon-v1.4.48.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaiwebtoon.png"1.4(021.4.488B8����ߒ��HentaiWebtoonen"https://hentaiwebtoon.com
�
HentaiXComic-eu.kanade.tachiyomi.extension.en.hentaixcomic�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentaixcomic-v1.4.50.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaixcomic.png"1.4(221.4.508B6�����ƮjHentaiXComicen"https://hentaixcomic.com
�
HentaiXDickgirl0eu.kanade.tachiyomi.extension.en.hentaixdickgirl�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentaixdickgirl-v1.4.50.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaixdickgirl.png"1.4(221.4.508B<�Ǖ�����HentaiXDickgirlen"https://hentaixdickgirl.com
�
HentaiXYuri,eu.kanade.tachiyomi.extension.en.hentaixyuri�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentaixyuri-v1.4.50.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaixyuri.png"1.4(221.4.508B4��Ҟ�Х�HentaiXYurien"https://hentaixyuri.com
�
Hentara(eu.kanade.tachiyomi.extension.en.hentara�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hentara-v1.4.3.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentara.png"1.4(21.4.38B,倌��߰�aHentaraen"https://hentara.com
�
HeyToon(eu.kanade.tachiyomi.extension.en.heytoon�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.heytoon-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.heytoon.png"1.4(21.4.18B,�����ևHHeyToonen"https://heytoon.net
�
Hijala Scans,eu.kanade.tachiyomi.extension.en.hijalascans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hijalascans-v1.4.23.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hijalascans.png"1.4(21.4.23B3�ԅ�����Hijala Scansen"https://en-hijala.com
�
Hiperdex)eu.kanade.tachiyomi.extension.en.hiperdex�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hiperdex-v1.4.79.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hiperdex.png"1.4(O21.4.798B.�םό�*Hiperdexen"https://hiperdex.com
�
Hiveworks Comics*eu.kanade.tachiyomi.extension.en.hiveworks�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hiveworks-v1.4.12.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hiveworks.png"1.4(21.4.12B=���ݶ���[Hiveworks Comicsen"https://hiveworkscomics.com
�
HM2D%eu.kanade.tachiyomi.extension.en.hm2d�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hm2d-v1.4.52.apkuhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hm2d.png"1.4(421.4.528B0����՞��eHM2Den"https://doujindistrict.com
�
HonkaiImpact3-eu.kanade.tachiyomi.extension.en.honkaiimpact�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.honkaiimpact-v1.4.4.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.honkaiimpact.png"1.4(21.4.4BB����ꌹNHonkai Impact 3rden"https://manga.honkaiimpact3.com
�
	HotComics*eu.kanade.tachiyomi.extension.en.hotcomics�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hotcomics-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hotcomics.png"1.4(21.4.28B/������W	HotComicsen"https://hotcomics.me
�
Hyakuro Translations(eu.kanade.tachiyomi.extension.en.hyakuro�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.hyakuro-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hyakuro.png"1.4(21.4.18B9�������EHyakuro Translationsen"https://hyakuro.net
�
I,eu.kanade.tachiyomi.extension.en.imanevilgod�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.imanevilgod-v1.4.7.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.imanevilgod.png"1.4(21.4.7B8�������kI'm An Evil Goden"https://imanevilgod.com
�

Hive Scans2eu.kanade.tachiyomi.extension.en.infernalvoidscans�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.infernalvoidscans-v1.4.65.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.infernalvoidscans.png"1.4(A21.4.65B1��������W
Hive Scansen"https://hivetoons.org
�
InfinityScans.eu.kanade.tachiyomi.extension.en.infinityscans�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.infinityscans-v1.4.10.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.infinityscans.png"1.4(
21.4.108B8�ջ����kInfinityScansen"https://infinityscans.org
�
I Roved Out*eu.kanade.tachiyomi.extension.en.irovedout�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.irovedout-v1.4.5.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.irovedout.png"1.4(21.4.58B6��㗿���qI Roved Outen"https://www.irovedout.com
�
IsekaiScan.top (unoriginal).eu.kanade.tachiyomi.extension.en.isekaiscantop�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.isekaiscantop-v1.4.51.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.isekaiscantop.png"1.4(321.4.518BC׆������'IsekaiScan.top (unoriginal)en"https://isekaiscan.top
�

S2Manga.io(eu.kanade.tachiyomi.extension.en.jimanga�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.jimanga-v1.4.46.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.jimanga.png"1.4(.21.4.46B.�������9
S2Manga.ioen"https://s2manga.io
�
	Jinmangas*eu.kanade.tachiyomi.extension.en.jinmangas�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.jinmangas-v1.4.50.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.jinmangas.png"1.4(221.4.508B0�������O	Jinmangasen"https://jinmangas.com
�
J-Novel'eu.kanade.tachiyomi.extension.en.jnovel�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.jnovel-v1.4.3.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.jnovel.png"1.4(21.4.3B-������"J-Novelen"https://j-novel.club
�
Kagane'eu.kanade.tachiyomi.extension.en.kagane�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kagane-v1.4.24.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kagane.png"1.4(21.4.248B*�չ����7Kaganeen"https://kagane.org
�
	Kai Scans)eu.kanade.tachiyomi.extension.en.kaiscans�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kaiscans-v1.4.37.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kaiscans.png"1.4(%21.4.378B/銪�����B	Kai Scansen"https://kaiscans.org
�
Kaizen Scan+eu.kanade.tachiyomi.extension.en.kaizenscan�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kaizenscan-v1.4.20.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kaizenscan.png"1.4(21.4.208B3��ƲŬ��Kaizen Scanen"https://kaizenscan.com
�
KaliScan,eu.kanade.tachiyomi.extension.en.kaliscancom�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kaliscancom-v1.4.25.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kaliscancom.png"1.4(21.4.258B.����ͱ��jKaliScanen"https://kaliscan.com
�
KaliScan.io+eu.kanade.tachiyomi.extension.en.kaliscanio�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kaliscanio-v1.4.23.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kaliscanio.png"1.4(21.4.238B0�Ƥ����"KaliScan.ioen"https://kaliscan.io
�
KaliScan.me+eu.kanade.tachiyomi.extension.en.kaliscanme�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kaliscanme-v1.4.23.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kaliscanme.png"1.4(21.4.238B0��������KaliScan.meen"https://kaliscan.me
�
Kappa Beast+eu.kanade.tachiyomi.extension.en.kappabeast�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kappabeast-v1.4.33.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kappabeast.png"1.4(!21.4.338B3����뾀�$Kappa Beasten"https://kappabeast.com
�
Kawai Scans+eu.kanade.tachiyomi.extension.en.kawaiscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kawaiscans-v1.4.2.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kawaiscans.png"1.4(21.4.2B3̺������yKawai Scansen"https://kawaiscans.org
�

Kayn Scans*eu.kanade.tachiyomi.extension.en.kaynscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kaynscans-v1.4.26.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kaynscans.png"1.4(21.4.26B0�������/
Kayn Scansen"https://kaynscan.org
�
keenspot)eu.kanade.tachiyomi.extension.en.keenspot�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.keenspot-v1.4.3.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.keenspot.png"1.4(21.4.3B@�休����+Keenspot TwoKindsen"https://twokinds.keenspot.com
�
	Ken Scans)eu.kanade.tachiyomi.extension.en.kenscans�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kenscans-v1.4.32.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kenscans.png"1.4( 21.4.32B0���ڴ��l	Ken Scansen"https://kencomics.com
�

Kewn Scans*eu.kanade.tachiyomi.extension.en.kewnscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kewnscans-v1.4.21.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kewnscans.png"1.4(21.4.21B1��Ѻ��ˋ'
Kewn Scansen"https://kewnscans.org
�
Kill Six Billion Demons5eu.kanade.tachiyomi.extension.en.killsixbilliondemons�
whttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.killsixbilliondemons-v1.4.6.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.killsixbilliondemons.png"1.4(21.4.6BF՛ݱ����LKillSixBillionDemonsen" https://killsixbilliondemons.com
�
	KingComiX*eu.kanade.tachiyomi.extension.en.kingcomix�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kingcomix-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kingcomix.png"1.4(21.4.18B0������Ơ|	KingComiXen"https://kingcomix.com
�
King of Shojo,eu.kanade.tachiyomi.extension.en.kingofshojo�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kingofshojo-v1.4.32.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kingofshojo.png"1.4( 21.4.328B6��������King of Shojoen"https://kingofshojo.com
�
Kissmanga.in,eu.kanade.tachiyomi.extension.en.kissmangain�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kissmangain-v1.4.54.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kissmangain.png"1.4(621.4.548B2��ꠁ�ژ+Kissmanga.inen"https://kissmanga.in
�
K Manga'eu.kanade.tachiyomi.extension.en.kmanga�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kmanga-v1.4.5.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kmanga.png"1.4(21.4.5B4������ԁqK Mangaen"https://kmanga.kodansha.com
�
Kodansha)eu.kanade.tachiyomi.extension.en.kodansha�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kodansha-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kodansha.png"1.4(21.4.18B-������˝Kodanshaen"https://kodansha.us
�
KSGroupScans-eu.kanade.tachiyomi.extension.en.ksgroupscans�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.ksgroupscans-v1.4.50.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ksgroupscans.png"1.4(221.4.508B6��̮���;KSGroupScansen"https://ksgroupscans.com
�
	Kun Manga)eu.kanade.tachiyomi.extension.en.kunmanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kunmanga-v1.4.51.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kunmanga.png"1.4(321.4.518B/��訩��	Kun Mangaen"https://kunmanga.com
�
Kun Manga Online/eu.kanade.tachiyomi.extension.en.kunmangaonline�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kunmangaonline-v1.4.51.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kunmangaonline.png"1.4(321.4.518B=������nKun Manga Onlineen"https://www.kunmanga.online
�
	KuraManga*eu.kanade.tachiyomi.extension.en.kuramanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.kuramanga-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kuramanga.png"1.4(21.4.28B0��������b	KuraMangaen"https://kuramanga.com
�
Lagoon Scans,eu.kanade.tachiyomi.extension.en.lagoonscans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.lagoonscans-v1.4.32.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.lagoonscans.png"1.4( 21.4.32B5��к�ڤ�mLagoon Scansen"https://lagoonscans.com
�
Leslie&Victims.eu.kanade.tachiyomi.extension.en.leslievictims�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.leslievictims-v1.4.1.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.leslievictims.png"1.4(21.4.1B@������̅Leslie&Victimsen" https://leslie-victims.pages.dev
�
LHTranslation.eu.kanade.tachiyomi.extension.en.lhtranslation�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.lhtranslation-v1.4.51.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.lhtranslation.png"1.4(321.4.51B8�楕��ɔzLHTranslationen"https://lhtranslation.net
�
	LikeManga*eu.kanade.tachiyomi.extension.en.likemanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.likemanga-v1.4.8.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.likemanga.png"1.4(21.4.8B0��ݪ����V	LikeMangaen"https://likemanga.ink
�
MangaYY,eu.kanade.tachiyomi.extension.en.likemangain�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.likemangain-v1.4.51.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.likemangain.png"1.4(321.4.518B,���䇞��MangaYYen"https://mangayy.org
�

Lily Manga*eu.kanade.tachiyomi.extension.en.lilymanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.lilymanga-v1.4.57.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.lilymanga.png"1.4(921.4.578B1��灾��>
Lily Mangaen"https://lilymanga.net
�
	LinkManga*eu.kanade.tachiyomi.extension.en.linkmanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.linkmanga-v1.4.50.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.linkmanga.png"1.4(221.4.508B0��������w	LinkMangaen"https://linkmanga.com
�
Loading Artist.eu.kanade.tachiyomi.extension.en.loadingartist�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.loadingartist-v1.4.3.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.loadingartist.png"1.4(21.4.3B9������Loading Artisten"https://loadingartist.com
�
	Lua Scans)eu.kanade.tachiyomi.extension.en.luascans�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.luascans-v1.4.50.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.luascans.png"1.4(221.4.50B/��������	Lua Scansen"https://luacomic.org
�
Luminare Translations5eu.kanade.tachiyomi.extension.en.luminaretranslations�
whttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.luminaretranslations-v1.4.3.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.luminaretranslations.png"1.4(21.4.3BG��������Luminare Translationsen" https://luminaretranslations.com
�

Luna Toons*eu.kanade.tachiyomi.extension.en.lunatoons�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.lunatoons-v1.4.20.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.lunatoons.png"1.4(21.4.208B1��쇨��
Luna Toonsen"https://lunatoons.org
�
	MadaraDex*eu.kanade.tachiyomi.extension.en.madaradex�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.madaradex-v1.4.53.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.madaradex.png"1.4(521.4.538B0ǐ������	MadaraDexen"https://madaradex.org
�
Madara Scans,eu.kanade.tachiyomi.extension.en.madarascans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.madarascans-v1.4.34.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.madarascans.png"1.4("21.4.34B5������Ϡ}Madara Scansen"https://madarascans.com
�
Madokami)eu.kanade.tachiyomi.extension.en.madokami�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.madokami-v1.4.13.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.madokami.png"1.4(21.4.13B3Ѷ�Ӗ���eMadokamien"https://manga.madokami.al
�
Magus Manga+eu.kanade.tachiyomi.extension.en.magusmanga�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.magusmanga-v1.4.69.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.magusmanga.png"1.4(E21.4.69B2��������Magus Mangaen"https://magustoon.org
�
Mahouirexnohentaikarte7eu.kanade.tachiyomi.extension.en.mahouirexnohentaikarte�
zhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mahouirexnohentaikarte-v1.4.50.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mahouirexnohentaikarte.png"1.4(221.4.508BJ�ͬ�����Mahouirexnohentaikarteen""https://mahouirexnohentaikarte.com
�
Manga18.Club,eu.kanade.tachiyomi.extension.en.manga18club�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manga18club-v1.4.3.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manga18club.png"1.4(21.4.38B2ḉ�����/Manga18.Cluben"https://manga18.club
�
Manga18Free,eu.kanade.tachiyomi.extension.en.manga18free�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manga18free-v1.4.51.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manga18free.png"1.4(321.4.518B4��������=Manga18Freeen"https://manga18free.com
�
	Manga18fx*eu.kanade.tachiyomi.extension.en.manga18fx�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manga18fx-v1.4.55.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manga18fx.png"1.4(721.4.558B0������+	Manga18fxen"https://manga18fx.com
�
	Manga 18x)eu.kanade.tachiyomi.extension.en.manga18x�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manga18x-v1.4.51.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manga18x.png"1.4(321.4.518B/���ە��^	Manga 18xen"https://manga18x.net
�
Manga1s(eu.kanade.tachiyomi.extension.en.manga1s�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manga1s-v1.4.4.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manga1s.png"1.4(21.4.48B,�������|Manga1sen"https://manga1s.com
�
Mangabat)eu.kanade.tachiyomi.extension.en.mangabat�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangabat-v1.4.20.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangabat.png"1.4(21.4.208B3ڲ򭄪��:Mangabaten"https://www.mangabats.com
�
	Manga-Bay)eu.kanade.tachiyomi.extension.en.mangabay�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangabay-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangabay.png"1.4(21.4.18B5þ���ឹ 	Manga-Bayen"https://read.manga-bay.org
�

MangaBlaze+eu.kanade.tachiyomi.extension.en.mangablaze�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangablaze-v1.4.50.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangablaze.png"1.4(221.4.50B2��悙³�U
MangaBlazeen"https://mangablaze.com
�
	MangaBolt*eu.kanade.tachiyomi.extension.en.mangabolt�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangabolt-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangabolt.png"1.4(21.4.1B0��堂��	MangaBolten"https://mangabolt.com
�
MangaBTT)eu.kanade.tachiyomi.extension.en.mangabtt�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangabtt-v1.4.5.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangabtt.png"1.4(21.4.58B.���ޚ���lMangaBTTen"https://manhwabtt.cc
�
MangaK+eu.kanade.tachiyomi.extension.en.mangabuddy�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangabuddy-v1.4.29.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangabuddy.png"1.4(21.4.298B)�����ց�EMangaKen"https://mangak.io
�
MangaBuddy.me-eu.kanade.tachiyomi.extension.en.mangabuddyme�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangabuddyme-v1.4.23.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangabuddyme.png"1.4(21.4.238B4�����⨷+MangaBuddy.meen"https://mangabuddy.me
�
Mangack(eu.kanade.tachiyomi.extension.en.mangack�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangack-v1.4.2.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangack.png"1.4(21.4.2B,��č����dMangacken"https://mangack.com
�

MangaClash+eu.kanade.tachiyomi.extension.en.mangaclash�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangaclash-v1.4.56.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangaclash.png"1.4(821.4.568B2��������H
MangaClashen"https://mangaclash.com
�

MangaCloud+eu.kanade.tachiyomi.extension.en.mangacloud�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangacloud-v1.4.7.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangacloud.png"1.4(21.4.7B2�������y
MangaClouden"https://mangacloud.org
�
	MangaCute*eu.kanade.tachiyomi.extension.en.mangacute�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangacute-v1.4.23.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangacute.png"1.4(21.4.238B0������	MangaCuteen"https://mangacute.com
�

Manga Dass*eu.kanade.tachiyomi.extension.en.mangadass�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangadass-v1.4.51.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangadass.png"1.4(321.4.518B1���ϕ��M
Manga Dassen"https://mangadass.com
�
MangaDE(eu.kanade.tachiyomi.extension.en.mangade�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangade-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangade.png"1.4(21.4.18B+����ƞ��/MangaDEen"https://mangade.io
�
Manga Demon+eu.kanade.tachiyomi.extension.en.mangademon�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangademon-v1.4.19.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangademon.png"1.4(21.4.19B5ڹ�ܒ���(Manga Demonen"https://demonicscans.org
�
MangaDia)eu.kanade.tachiyomi.extension.en.mangadia�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangadia-v1.4.50.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangadia.png"1.4(221.4.50B.�ҥă��MangaDiaen"https://mangadia.com
�
Manga District.eu.kanade.tachiyomi.extension.en.mangadistrict�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangadistrict-v1.4.66.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangadistrict.png"1.4(B21.4.668B9��������)Manga Districten"https://mangadistrict.com
�
Mangadotnet,eu.kanade.tachiyomi.extension.en.mangadotnet�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangadotnet-v1.4.9.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangadotnet.png"1.4(	21.4.98B1��ٙ�ɕ�QMangadotneten"https://mangadot.net
�
Manga Drama+eu.kanade.tachiyomi.extension.en.mangadrama�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangadrama-v1.4.50.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangadrama.png"1.4(221.4.508B3�������,Manga Dramaen"https://mangadrama.com
�
MangaFab)eu.kanade.tachiyomi.extension.en.mangafab�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangafab-v1.4.23.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangafab.png"1.4(21.4.238B.����ܞ��;MangaFaben"https://mangafab.com
�
MangaForest,eu.kanade.tachiyomi.extension.en.mangaforest�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangaforest-v1.4.24.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangaforest.png"1.4(21.4.248B3��������5MangaForesten"https://mangaforest.me
�
Mangaforfree.com0eu.kanade.tachiyomi.extension.en.mangaforfreecom�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangaforfreecom-v1.4.52.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangaforfreecom.png"1.4(421.4.528B:����ԗΠMangaforfree.comen"https://mangaforfree.com
�
MangaFox)eu.kanade.tachiyomi.extension.en.mangafox�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangafox-v1.4.9.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangafox.png"1.4(	21.4.98B,Ц������YMangaFoxen"https://fanfox.net
�
MangaFoxFull-eu.kanade.tachiyomi.extension.en.mangafoxfull�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangafoxfull-v1.4.45.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangafoxfull.png"1.4(-21.4.458B6����ݷУMangaFoxFullen"https://mangafoxfull.com
�
MangaFox.fun,eu.kanade.tachiyomi.extension.en.mangafoxfun�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangafoxfun-v1.4.35.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangafoxfun.png"1.4(#21.4.358B2������߂qMangaFox.funen"https://mangafox.fun
�

Mangafreak+eu.kanade.tachiyomi.extension.en.mangafreak�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangafreak-v1.4.13.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangafreak.png"1.4(21.4.138B5�֬����
Mangafreaken"https://ww2.mangafreak.me
�
	Mangafree*eu.kanade.tachiyomi.extension.en.mangafree�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangafree-v1.4.50.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangafree.png"1.4(221.4.508B1��Ԫۧ��.	Mangafreeen"https://mangafree.info
�
MangaGG(eu.kanade.tachiyomi.extension.en.mangagg�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangagg-v1.4.53.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangagg.png"1.4(521.4.538B,Ά���նqMangaGGen"https://mangagg.com
�
Mangago(eu.kanade.tachiyomi.extension.en.mangago�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangago-v1.4.34.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangago.png"1.4("21.4.348B/ژ����ڣ"Mangagoen"https://www.mangago.me
�
MangaGo.fun+eu.kanade.tachiyomi.extension.en.mangagofun�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangagofun-v1.4.50.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangagofun.png"1.4(221.4.50B4��ڑо��XMangaGo.funen"https://www.mangago.fun
�
	MangaGojo*eu.kanade.tachiyomi.extension.en.mangagojo�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangagojo-v1.4.30.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangagojo.png"1.4(21.4.308B0��ݕ����)	MangaGojoen"https://mangagojo.com
�
MangaHe(eu.kanade.tachiyomi.extension.en.mangahe�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangahe-v1.4.50.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangahe.png"1.4(221.4.508B,��������MangaHeen"https://mangahe.com
�
Gensura)eu.kanade.tachiyomi.extension.en.mangahen�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangahen-v1.4.3.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangahen.png"1.4(21.4.38B,��﫱��[Gensuraen"https://gensura.net
�
Manga Hentai,eu.kanade.tachiyomi.extension.en.mangahentai�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangahentai-v1.4.54.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangahentai.png"1.4(621.4.548B4���嘑yManga Hentaien"https://mangahentai.me
�
	Mangahere*eu.kanade.tachiyomi.extension.en.mangahere�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangahere-v1.4.23.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangahere.png"1.4(21.4.238B+	Mangahereen"https://www.mangahere.cc
�
MangaHere.onl-eu.kanade.tachiyomi.extension.en.mangahereonl�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangahereonl-v1.4.35.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangahereonl.png"1.4(#21.4.358B4��������6MangaHere.onlen"https://mangahere.onl
�
MangaHub+eu.kanade.tachiyomi.extension.en.mangahubio�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangahubio-v1.4.45.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangahubio.png"1.4(-21.4.458B-�ۢ�����BMangaHuben"https://mangahub.io
�
MangaKa(eu.kanade.tachiyomi.extension.en.mangaka�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangaka-v1.4.50.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangaka.png"1.4(221.4.50B+��Ɔ����-MangaKaen"https://mangaka.cc
�
Mangakakalot-eu.kanade.tachiyomi.extension.en.mangakakalot�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangakakalot-v1.4.21.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangakakalot.png"1.4(21.4.218B9�闥����#Mangakakaloten"https://www.mangakakalot.gg
�
Mangakakalot.fun0eu.kanade.tachiyomi.extension.en.mangakakalotfun�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangakakalotfun-v1.4.35.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangakakalotfun.png"1.4(#21.4.358B:������ŊZMangakakalot.funen"https://mangakakalot.fun
�
MangaKatana,eu.kanade.tachiyomi.extension.en.mangakatana�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangakatana-v1.4.12.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangakatana.png"1.4(21.4.128B4��������,MangaKatanaen"https://mangakatana.com
�

Manga Kiss*eu.kanade.tachiyomi.extension.en.mangakiss�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangakiss-v1.4.51.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangakiss.png"1.4(321.4.51B1�����І�!
Manga Kissen"https://mangakiss.org
�
Manga Leveling.eu.kanade.tachiyomi.extension.en.mangaleveling�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangaleveling-v1.4.46.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangaleveling.png"1.4(.21.4.46B9�Ŧ����_Manga Levelingen"https://mangaleveling.com
�
MangaManiacs-eu.kanade.tachiyomi.extension.en.mangamaniacs�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangamaniacs-v1.4.50.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangamaniacs.png"1.4(221.4.508B6������׮LMangaManiacsen"https://mangamaniacs.org
�
Manga Mirai+eu.kanade.tachiyomi.extension.en.mangamirai�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangamirai-v1.4.1.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangamirai.png"1.4(21.4.1B3��䳁���/Manga Miraien"https://mangamirai.com
�
Mangamo(eu.kanade.tachiyomi.extension.en.mangamo�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangamo-v1.4.7.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangamo.png"1.4(21.4.7B0���ğ��YMangamoen"https://www.mangamo.com
�
Comivex)eu.kanade.tachiyomi.extension.en.mangamob�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangamob-v1.4.3.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangamob.png"1.4(21.4.3B,��������Comivexen"https://comivex.com
�
	MangaMonk*eu.kanade.tachiyomi.extension.en.mangamonk�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangamonk-v1.4.23.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangamonk.png"1.4(21.4.238B0��ߝզ�{	MangaMonken"https://mangamonk.com
�
MangaNel)eu.kanade.tachiyomi.extension.en.manganel�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manganel-v1.4.35.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manganel.png"1.4(#21.4.358B-�㽢����	MangaNelen"https://manganel.me
�
	Manganato*eu.kanade.tachiyomi.extension.en.manganelo�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manganelo-v1.4.18.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manganelo.png"1.4(21.4.188B4��������	Manganatoen"https://www.natomanga.com
�
MangaNow)eu.kanade.tachiyomi.extension.en.manganow�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manganow-v1.4.4.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manganow.png"1.4(21.4.48B-��������MangaNowen"https://manganow.to
�
MangaOnline.fun/eu.kanade.tachiyomi.extension.en.mangaonlinefun�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangaonlinefun-v1.4.35.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangaonlinefun.png"1.4(#21.4.358B8�������IMangaOnline.funen"https://mangaonline.fun
�
MangaOwl.io (unoriginal)+eu.kanade.tachiyomi.extension.en.mangaowlio�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangaowlio-v1.4.51.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangaowlio.png"1.4(321.4.518B=�ʅ�՘MangaOwl.io (unoriginal)en"https://mangaowl.io
�
MangaPanda.onl.eu.kanade.tachiyomi.extension.en.mangapandaonl�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangapandaonl-v1.4.35.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangapandaonl.png"1.4(#21.4.35B6����ڴ�jMangaPanda.onlen"https://mangapanda.onl
�
	MangaPill*eu.kanade.tachiyomi.extension.en.mangapill�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangapill-v1.4.9.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangapill.png"1.4(	21.4.98B0��ҧҩ��u	MangaPillen"https://mangapill.com
�
	MangaPlex*eu.kanade.tachiyomi.extension.en.mangaplex�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangaplex-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangaplex.png"1.4(21.4.1B0������n	MangaPlexen"https://mangaplex.com
�
	MangaPuma*eu.kanade.tachiyomi.extension.en.mangapuma�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangapuma-v1.4.25.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangapuma.png"1.4(21.4.258B0�Ƒ©���m	MangaPumaen"https://mangapuma.com
�
	MangaGeko-eu.kanade.tachiyomi.extension.en.mangarawclub�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangarawclub-v1.4.32.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangarawclub.png"1.4( 21.4.328B/���ۊ���
	MangaGekoen"https://www.mgeko.cc
�

Manga Read*eu.kanade.tachiyomi.extension.en.mangaread�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangaread-v1.4.51.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangaread.png"1.4(321.4.518B0����֘��z
Manga Readen"https://mangaread.co
�
MangaReader.in.eu.kanade.tachiyomi.extension.en.mangareadercc�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangareadercc-v1.4.6.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangareadercc.png"1.4(21.4.68B6ٺ������fMangaReader.inen"https://mangareader.in
�
MangaReader.site0eu.kanade.tachiyomi.extension.en.mangareadersite�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangareadersite-v1.4.35.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangareadersite.png"1.4(#21.4.35B:���ԘŚ�#MangaReader.siteen"https://mangareader.site
�
MangaRead.org-eu.kanade.tachiyomi.extension.en.mangareadorg�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangareadorg-v1.4.52.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangareadorg.png"1.4(421.4.528B8�۷���ț%MangaRead.orgen"https://www.mangaread.org
�
	MangaSaga*eu.kanade.tachiyomi.extension.en.mangasaga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangasaga-v1.4.23.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangasaga.png"1.4(21.4.238B0���ͤ؄�T	MangaSagaen"https://mangasaga.com
�
	Mangasail*eu.kanade.tachiyomi.extension.en.mangasail�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangasail-v1.4.6.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangasail.png"1.4(21.4.6B1�������	Mangasailen"https://www.sailmg.com
�

Manga Sect*eu.kanade.tachiyomi.extension.en.mangasect�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangasect-v1.4.3.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangasect.png"1.4(21.4.3B1��������
Manga Secten"https://mangasect.net
�
	MangaSpin*eu.kanade.tachiyomi.extension.en.mangaspin�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangaspin-v1.4.23.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangaspin.png"1.4(21.4.238B0���˝���	MangaSpinen"https://mangaspin.com
�

Mangasushi+eu.kanade.tachiyomi.extension.en.mangasushi�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangasushi-v1.4.53.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangasushi.png"1.4(521.4.53B2�۸����2
Mangasushien"https://mangasushi.org
�
Mangatellers-eu.kanade.tachiyomi.extension.en.mangatellers�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangatellers-v1.4.5.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangatellers.png"1.4(21.4.5B<��Ϻ��ӣ0Mangatellersen"https://reader.mangatellers.gr
�

MangaToday+eu.kanade.tachiyomi.extension.en.mangatoday�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangatoday-v1.4.35.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangatoday.png"1.4(#21.4.358B2�������
MangaTodayen"https://mangatoday.fun
�
	MangaTone*eu.kanade.tachiyomi.extension.en.mangatone�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangatone-v1.4.45.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangatone.png"1.4(-21.4.45B0��������8	MangaToneen"https://mangatone.com
�
	Mangatown*eu.kanade.tachiyomi.extension.en.mangatown�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangatown-v1.4.10.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangatown.png"1.4(
21.4.108B4���Ԩ���%	Mangatownen"https://www.mangatown.com
�
Manga Trend+eu.kanade.tachiyomi.extension.en.mangatrend�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangatrend-v1.4.32.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangatrend.png"1.4( 21.4.32B3�������Manga Trenden"https://mangatrend.org
�
MangaTX(eu.kanade.tachiyomi.extension.en.mangatx�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangatx-v1.4.33.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangatx.png"1.4(!21.4.338B+������-MangaTXen"https://mangatx.cc
�
MangaTyrant,eu.kanade.tachiyomi.extension.en.mangatyrant�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangatyrant-v1.4.45.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangatyrant.png"1.4(-21.4.45B4ҫ��ҵ�&MangaTyranten"https://mangatyrant.com
�
MangaXYZ)eu.kanade.tachiyomi.extension.en.mangaxyz�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangaxyz-v1.4.23.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangaxyz.png"1.4(21.4.238B.��䬬���<MangaXYZen"https://mangaxyz.com
�
MangaYY(eu.kanade.tachiyomi.extension.en.mangayy�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mangayy-v1.4.45.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangayy.png"1.4(-21.4.458B,ѥ̆��ωPMangaYYen"https://mangayy.org
�
	Manhua AZ)eu.kanade.tachiyomi.extension.en.manhuaaz�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuaaz-v1.4.45.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuaaz.png"1.4(-21.4.45B/����ރ��L	Manhua AZen"https://manhuaaz.com
�
	Manhua ES)eu.kanade.tachiyomi.extension.en.manhuaes�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuaes-v1.4.51.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuaes.png"1.4(321.4.51B/��͆���*	Manhua ESen"https://manhuaes.com
�

ManhuaFast+eu.kanade.tachiyomi.extension.en.manhuafast�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuafast-v1.4.54.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuafast.png"1.4(621.4.548B2̗�Ӓ��K
ManhuaFasten"https://manhuafast.com
�
ManhuaFast.net (unoriginal).eu.kanade.tachiyomi.extension.en.manhuafastnet�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuafastnet-v1.4.50.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuafastnet.png"1.4(221.4.50BC٘�����6ManhuaFast.net (unoriginal)en"https://manhuafast.net
�
	ManhuaHot*eu.kanade.tachiyomi.extension.en.manhuahot�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuahot-v1.4.50.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuahot.png"1.4(221.4.50B0�����Հj	ManhuaHoten"https://manhuahot.com
�

Manhuanext+eu.kanade.tachiyomi.extension.en.manhuanext�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuanext-v1.4.50.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuanext.png"1.4(221.4.50B2��ʂ΄��1
Manhuanexten"https://manhuanext.com
�
	ManhuaNow*eu.kanade.tachiyomi.extension.en.manhuanow�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuanow-v1.4.23.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuanow.png"1.4(21.4.238B0����뢥�^	ManhuaNowen"https://manhuanow.com
�
Manhua Plus+eu.kanade.tachiyomi.extension.en.manhuaplus�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuaplus-v1.4.57.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuaplus.png"1.4(921.4.57B3�������}Manhua Plusen"https://manhuaplus.com
�
ManhuaPlus (unoriginal).eu.kanade.tachiyomi.extension.en.manhuaplusorg�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuaplusorg-v1.4.5.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuaplusorg.png"1.4(21.4.5B?�����ޕ�FManhuaPlus (Unoriginal)en"https://manhuaplus.org
�
Manhua Rush+eu.kanade.tachiyomi.extension.en.manhuarush�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuarush-v1.4.2.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuarush.png"1.4(21.4.2B:ҟƔ����NManhua Rushen"https://manhuarush.vercel.app
�
Manhuascan.us-eu.kanade.tachiyomi.extension.en.manhuascanus�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuascanus-v1.4.32.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuascanus.png"1.4( 21.4.328B4��������ZManhuascan.usen"https://manhuascan.us
�

ManhuaSite+eu.kanade.tachiyomi.extension.en.manhuasite�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuasite-v1.4.23.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuasite.png"1.4(21.4.238B2������+
ManhuaSiteen"https://manhuasite.com
�
	ManhuaTop*eu.kanade.tachiyomi.extension.en.manhuatop�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuatop-v1.4.51.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuatop.png"1.4(321.4.518B0ܪ�聾�	ManhuaTopen"https://manhuatop.org
�
ManhuaUS)eu.kanade.tachiyomi.extension.en.manhuaus�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuaus-v1.4.55.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuaus.png"1.4(721.4.55B.��֞��7ManhuaUSen"https://manhuaus.com
�
Manhua Zonghe-eu.kanade.tachiyomi.extension.en.manhuazonghe�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhuazonghe-v1.4.51.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuazonghe.png"1.4(321.4.518B;�����TManhua Zongheen"https://www.manhuazonghe.com
�
Manhwa18)eu.kanade.tachiyomi.extension.en.manhwa18�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwa18-v1.4.13.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwa18.png"1.4(21.4.138B-�ڐ��̋2Manhwa18en"https://manhwa18.com
�
Manhwa18.org,eu.kanade.tachiyomi.extension.en.manhwa18org�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwa18org-v1.4.52.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwa18org.png"1.4(421.4.528B2��橽��|Manhwa18.orgen"https://manhwa18.org
�
Manhwa68)eu.kanade.tachiyomi.extension.en.manhwa68�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwa68-v1.4.53.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwa68.png"1.4(521.4.538B.��߇܋�%Manhwa68en"https://manhwa68.com
�
ManhwaBuddy,eu.kanade.tachiyomi.extension.en.manhwabuddy�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwabuddy-v1.4.3.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwabuddy.png"1.4(21.4.38B4������ManhwaBuddyen"https://manhwabuddy.com
�

ManhwaClan+eu.kanade.tachiyomi.extension.en.manhwaclan�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwaclan-v1.4.52.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwaclan.png"1.4(421.4.528B2������-
ManhwaClanen"https://manhwaclan.com
�
Manhwa Comics-eu.kanade.tachiyomi.extension.en.manhwacomics�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwacomics-v1.4.50.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwacomics.png"1.4(221.4.508B7爵֢���.Manhwa Comicsen"https://manhwacomics.com
�
	ManhwaDen*eu.kanade.tachiyomi.extension.en.manhwaden�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwaden-v1.4.50.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwaden.png"1.4(221.4.508B4�̤�����j	ManhwaDenen"https://www.manhwaden.com
�
Manhwa Freake-eu.kanade.tachiyomi.extension.en.manhwafreake�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwafreake-v1.4.30.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwafreake.png"1.4(21.4.308B7���ԌݑMManhwa Freakeen"https://manhwafreake.com
�
	ManhwaGet*eu.kanade.tachiyomi.extension.en.manhwaget�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwaget-v1.4.50.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwaget.png"1.4(221.4.50B0ͨ��ʾ�)	ManhwaGeten"https://manhwaget.com
�
Manhwa Hentai-eu.kanade.tachiyomi.extension.en.manhwahentai�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwahentai-v1.4.45.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwahentai.png"1.4(-21.4.458B6�����֎�OManhwa Hentaien"https://manhwahentai.to
�
Manhwahentai.me/eu.kanade.tachiyomi.extension.en.manhwahentaime�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwahentaime-v1.4.52.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwahentaime.png"1.4(421.4.528B7�������GManhwahentai.meen"https://manhwahentai.me
�
	ManhwaHub*eu.kanade.tachiyomi.extension.en.manhwahub�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwahub-v1.4.5.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwahub.png"1.4(21.4.58B0ن�ڕ���	ManhwaHuben"https://manhwahub.net
�
	Manhwajoy*eu.kanade.tachiyomi.extension.en.manhwajoy�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwajoy-v1.4.50.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwajoy.png"1.4(221.4.508B0��������	Manhwajoyen"https://manhwajoy.com
�

Manhwalike+eu.kanade.tachiyomi.extension.en.manhwalike�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwalike-v1.4.3.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwalike.png"1.4(21.4.38B2��������0
Manhwalikeen"https://manhwalike.com
�
Manhwalover,eu.kanade.tachiyomi.extension.en.manhwalover�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwalover-v1.4.32.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwalover.png"1.4( 21.4.328B8�ڮ٦đ�QManhwaloveren"https://www.manhwalover.org
�
ManhwaManhua-eu.kanade.tachiyomi.extension.en.manhwamanhua�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwamanhua-v1.4.50.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwamanhua.png"1.4(221.4.508B6Բ�����|ManhwaManhuaen"https://manhwamanhua.com
�
	ManhwaNex*eu.kanade.tachiyomi.extension.en.manhwanex�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwanex-v1.4.50.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwanex.png"1.4(221.4.50B0�ۆ����2	ManhwaNexen"https://manhwanex.com
�

ManhwaRead+eu.kanade.tachiyomi.extension.en.manhwaread�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwaread-v1.4.1.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwaread.png"1.4(21.4.18BKӋ��Ƀ�
ManhwaReaden"/https://manhwaread.com#, https://manhwaread.org
�
Manhwa Reads,eu.kanade.tachiyomi.extension.en.manhwareads�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwareads-v1.4.50.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwareads.png"1.4(221.4.508B5��������.Manhwa Readsen"https://manhwareads.com
�
Manhwas Men+eu.kanade.tachiyomi.extension.en.manhwasmen�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwasmen-v1.4.46.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwasmen.png"1.4(.21.4.468B0������4Manhwas Menen"https://manhwas.men
�
Manhwa Toon+eu.kanade.tachiyomi.extension.en.manhwatoon�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwatoon-v1.4.51.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwatoon.png"1.4(321.4.518B6���춂��1Manhwa Toonen"https://www.manhwatoon.me
�
	Manhwatop*eu.kanade.tachiyomi.extension.en.manhwatop�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwatop-v1.4.52.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwatop.png"1.4(421.4.528B0�������G	Manhwatopen"https://manhwatop.com
�
Manhwax(eu.kanade.tachiyomi.extension.en.manhwax�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwax-v1.4.32.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwax.png"1.4( 21.4.328B,�����Ԫ�eManhwaxen"https://manhwax.top
�

Manhwa XXL*eu.kanade.tachiyomi.extension.en.manhwaxxl�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwaxxl-v1.4.6.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwaxxl.png"1.4(21.4.68B1��ӯ����
Manhwa XXLen"https://hentaitnt.net
�
ManhwaZ(eu.kanade.tachiyomi.extension.en.manhwaz�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwaz-v1.4.42.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwaz.png"1.4(*21.4.428B,ْ���	ManhwaZen"https://manhwaz.com
�

ManhwaZone+eu.kanade.tachiyomi.extension.en.manhwazone�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manhwazone-v1.4.1.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwazone.png"1.4(21.4.18B2�Ύ��֡�
ManhwaZoneen"https://manhwazone.com
�
Manta Comics&eu.kanade.tachiyomi.extension.en.manta�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manta-v1.4.6.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manta.png"1.4(21.4.68B(·˞��ϼyMantaen"https://manta.net
�
	ManyComic*eu.kanade.tachiyomi.extension.en.manycomic�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manycomic-v1.4.47.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manycomic.png"1.4(/21.4.478B0я�����"	ManyComicen"https://manycomic.com
�
ManyToon)eu.kanade.tachiyomi.extension.en.manytoon�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manytoon-v1.4.55.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manytoon.png"1.4(721.4.558B.�ў����vManyToonen"https://manytoon.com
�
ManyToon.me+eu.kanade.tachiyomi.extension.en.manytoonme�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.manytoonme-v1.4.50.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manytoonme.png"1.4(221.4.508B0��������0ManyToon.meen"https://manytoon.me
�
MayoTune)eu.kanade.tachiyomi.extension.en.mayotune�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mayotune-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mayotune.png"1.4(21.4.2B.��Ҝ����MayoTuneen"https://mayotune.xyz
�
	Megatokyo*eu.kanade.tachiyomi.extension.en.megatokyo�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.megatokyo-v1.4.4.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.megatokyo.png"1.4(21.4.4B0��������$	Megatokyoen"https://megatokyo.com
�
	Mehgazone*eu.kanade.tachiyomi.extension.en.mehgazone�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mehgazone-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mehgazone.png"1.4(21.4.28B0�뎄뻊�%	Mehgazoneen"https://mehgazone.com
�
MeiToon(eu.kanade.tachiyomi.extension.en.meitoon�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.meitoon-v1.4.20.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.meitoon.png"1.4(21.4.20B,�ʅ����-MeiToonen"https://meitoon.org
�
MGJinx'eu.kanade.tachiyomi.extension.en.mgjinx�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mgjinx-v1.4.23.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mgjinx.png"1.4(21.4.238B*����Ǧ��OMGJinxen"https://mgjinx.com
�
	Mgread.io)eu.kanade.tachiyomi.extension.en.mgreadio�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mgreadio-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mgreadio.png"1.4(21.4.18B+������	Mgread.ioen"https://mgread.io
�
Milftoon)eu.kanade.tachiyomi.extension.en.milftoon�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.milftoon-v1.4.52.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.milftoon.png"1.4(421.4.528B.��ϜȖ��7Milftoonen"https://milftoon.xxx
�

Mist Scans*eu.kanade.tachiyomi.extension.en.mistscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mistscans-v1.4.21.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mistscans.png"1.4(21.4.21B1ݤ쓯˞�
Mist Scansen"https://mistscans.com
�
	MLBB Lore)eu.kanade.tachiyomi.extension.en.mlbblore�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.mlbblore-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mlbblore.png"1.4(21.4.1B@�����MLBB Lore Comicsen"https://play.mobilelegends.com
�
Monochrome Custom1eu.kanade.tachiyomi.extension.en.monochromecustom�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.monochromecustom-v1.4.6.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.monochromecustom.png"1.4(21.4.6BD�������Monochrome Customen"!https://monochromecms.netlify.app
�
Monochrome Scans0eu.kanade.tachiyomi.extension.en.monochromescans�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.monochromescans-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.monochromescans.png"1.4(21.4.5B8�Ǟ�Ɣ��^Monochrome Scansen"https://manga.d34d.one
�
MSYToon(eu.kanade.tachiyomi.extension.en.msytoon�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.msytoon-v1.4.18.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.msytoon.png"1.4(21.4.18B,׬�յ���@MSYToonen"https://msytoon.com
�
Multporn)eu.kanade.tachiyomi.extension.en.multporn�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.multporn-v1.4.6.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.multporn.png"1.4(21.4.68B.�����Multpornen"https://multporn.net
�
	MurimScan*eu.kanade.tachiyomi.extension.en.murimscan�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.murimscan-v1.4.49.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.murimscan.png"1.4(121.4.498B6�������L	MurimScanen"https://www.murimscans.site
�
MyAdultComics.eu.kanade.tachiyomi.extension.en.myadultcomics�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.myadultcomics-v1.4.1.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.myadultcomics.png"1.4(21.4.18B8������9MyAdultComicsen"https://myadultcomics.com
�
MyHentaiComics/eu.kanade.tachiyomi.extension.en.myhentaicomics�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.myhentaicomics-v1.4.4.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.myhentaicomics.png"1.4(21.4.48B:�����ǌ�DMyHentaiComicsen"https://myhentaicomics.com
�
MyHentaiGallery0eu.kanade.tachiyomi.extension.en.myhentaigallery�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.myhentaigallery-v1.4.9.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.myhentaigallery.png"1.4(	21.4.98B<���ر��eMyHentaiGalleryen"https://myhentaigallery.com
�
Necro Scans+eu.kanade.tachiyomi.extension.en.necroscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.necroscans-v1.4.20.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.necroscans.png"1.4(21.4.20B3�����BNecro Scansen"https://necroscans.com
�

New Manhwa*eu.kanade.tachiyomi.extension.en.newmanhwa�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.newmanhwa-v1.4.34.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.newmanhwa.png"1.4("21.4.348B1�ϣԀ��2
New Manhwaen"https://newmanhwa.com
�
NexComic)eu.kanade.tachiyomi.extension.en.nexcomic�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.nexcomic-v1.4.32.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.nexcomic.png"1.4( 21.4.328B.ε������)NexComicen"https://nexcomic.com
�

Nika Toons*eu.kanade.tachiyomi.extension.en.nikatoons�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.nikatoons-v1.4.32.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.nikatoons.png"1.4( 21.4.32B1�����̓�
Nika Toonsen"https://nikatoons.com
�
	NineAnime*eu.kanade.tachiyomi.extension.en.nineanime�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.nineanime-v1.4.6.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.nineanime.png"1.4(21.4.68B4����ԯ*	NineAnimeen"https://www.nineanime.com
�

NineHentai+eu.kanade.tachiyomi.extension.en.ninehentai�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.ninehentai-v1.4.6.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ninehentai.png"1.4(21.4.68B.�Ҙ��ݣ�j
NineHentaien"https://9hentai.so
�
Ninekon(eu.kanade.tachiyomi.extension.en.ninekon�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.ninekon-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ninekon.png"1.4(21.4.18B0�ء�٬��=Ninekonen"https://app.ninekon.com
�
Nitro Scans+eu.kanade.tachiyomi.extension.en.nitroscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.nitroscans-v1.4.47.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.nitroscans.png"1.4(/21.4.47B3������ӗNitro Scansen"https://nitroscans.net
�
NixManga)eu.kanade.tachiyomi.extension.en.nixmanga�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.nixmanga-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.nixmanga.png"1.4(21.4.28B.�������0NixMangaen"https://nixmanga.com
�
24HNovel)eu.kanade.tachiyomi.extension.en.novel24h�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.novel24h-v1.4.51.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.novel24h.png"1.4(321.4.518B.��������t24HNovelen"https://24hnovel.com
�
	NovelCrow*eu.kanade.tachiyomi.extension.en.novelcrow�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.novelcrow-v1.4.51.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.novelcrow.png"1.4(321.4.518B0ڭ����<	NovelCrowen"https://novelcrow.com
�
Noxen Scans+eu.kanade.tachiyomi.extension.en.noxenscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.noxenscans-v1.4.32.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.noxenscans.png"1.4( 21.4.32B2Ζ�˙���+Noxen Scansen"https://noxenscan.com
�
	Nux Scans)eu.kanade.tachiyomi.extension.en.nuxscans�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.nuxscans-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.nuxscans.png"1.4(21.4.2B?�輊��ŠQ	Nux Scansen"$https://nuxscans-comics.blogspot.com
�

Nyanu Kafe*eu.kanade.tachiyomi.extension.en.nyanukafe�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.nyanukafe-v1.4.21.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.nyanukafe.png"1.4(21.4.21B1������)
Nyanu Kafeen"https://nyanukafe.com
�

Nyra Scans*eu.kanade.tachiyomi.extension.en.nyrascans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.nyrascans-v1.4.20.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.nyrascans.png"1.4(21.4.208B1�צ����
Nyra Scansen"https://nyrascans.com
�
	Nyx Scans)eu.kanade.tachiyomi.extension.en.nyxscans�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.nyxscans-v1.4.26.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.nyxscans.png"1.4(21.4.26B/�������	Nyx Scansen"https://nyxscans.com
�
OctopusManga-eu.kanade.tachiyomi.extension.en.octopusmanga�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.octopusmanga-v1.4.50.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.octopusmanga.png"1.4(221.4.508B6��������#OctopusMangaen"https://octopusmanga.com
�
Oglaf&eu.kanade.tachiyomi.extension.en.oglaf�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.oglaf-v1.4.4.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.oglaf.png"1.4(21.4.48B,������Oglafen"https://www.oglaf.com
�
Oh Joy Sex Toy,eu.kanade.tachiyomi.extension.en.ohjoysextoy�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.ohjoysextoy-v1.4.3.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ohjoysextoy.png"1.4(21.4.38B;��蟈�>Oh Joy Sex Toyen"https://www.ohjoysextoy.com
�
Omega Scans+eu.kanade.tachiyomi.extension.en.omegascans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.omegascans-v1.4.49.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.omegascans.png"1.4(121.4.498B3�֢���ݥOmega Scansen"https://omegascans.org
�
	1Manga.co+eu.kanade.tachiyomi.extension.en.onemangaco�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.onemangaco-v1.4.35.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.onemangaco.png"1.4(#21.4.358B,�陾���W	1Manga.coen"https://1manga.co
�
OneManga.info-eu.kanade.tachiyomi.extension.en.onemangainfo�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.onemangainfo-v1.4.35.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.onemangainfo.png"1.4(#21.4.358B4���η�OneManga.infoen"https://onemanga.info
�
One Punch Man Online2eu.kanade.tachiyomi.extension.en.onepunchmanonline�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.onepunchmanonline-v1.4.2.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.onepunchmanonline.png"1.4(21.4.2B?�΂�ݨȹOne Punch Man Onlineen"https://w11.1punchman.com
�
Only The Best Hentai2eu.kanade.tachiyomi.extension.en.onlythebesthentai�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.onlythebesthentai-v1.4.1.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.onlythebesthentai.png"1.4(21.4.18BC�����Ҵ�QOnly The Best Hentaien"https://onlythebesthentai.com
�
oots%eu.kanade.tachiyomi.extension.en.oots�
ghttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.oots-v1.4.3.apkuhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.oots.png"1.4(21.4.3BG����酗�`The Order Of The Stick (OOTS)en"https://www.giantitp.com
�
Oppai Stream,eu.kanade.tachiyomi.extension.en.oppaistream�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.oppaistream-v1.4.5.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.oppaistream.png"1.4(21.4.58B7��������Oppai Streamen"https://read.oppai.stream
�

Orchisasia+eu.kanade.tachiyomi.extension.en.orchisasia�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.orchisasia-v1.4.50.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.orchisasia.png"1.4(221.4.508B6�����=
Orchisasiaen"https://www.orchisasia.org
�
Orion Scans+eu.kanade.tachiyomi.extension.en.orionscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.orionscans-v1.4.23.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.orionscans.png"1.4(21.4.23B4���๟��kOrion Scansen"https://orion-scans.com
�
Paradise Scans.eu.kanade.tachiyomi.extension.en.paradisescans�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.paradisescans-v1.4.20.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.paradisescans.png"1.4(21.4.208B8�������RParadiseScansen"https://paradisescans.com
�
Paragon Scans-eu.kanade.tachiyomi.extension.en.paragonscans�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.paragonscans-v1.4.50.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.paragonscans.png"1.4(221.4.508B7��ġ���fParagon Scansen"https://paragonscans.com
�
Paritehaber,eu.kanade.tachiyomi.extension.en.paritehaber�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.paritehaber-v1.4.51.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.paritehaber.png"1.4(321.4.518B8���¢��3Paritehaberen"https://www.paritehaber.com
�
Patch Friday,eu.kanade.tachiyomi.extension.en.patchfriday�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.patchfriday-v1.4.2.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.patchfriday.png"1.4(21.4.2B5��׏�Ɖ�PPatch Fridayen"https://patchfriday.com
�
	Paw Manga)eu.kanade.tachiyomi.extension.en.pawmanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.pawmanga-v1.4.50.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.pawmanga.png"1.4(221.4.508B/ѿ�ߧ���>	Paw Mangaen"https://pawmanga.com
�
Petrotechsociety1eu.kanade.tachiyomi.extension.en.petrotechsociety�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.petrotechsociety-v1.4.50.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.petrotechsociety.png"1.4(221.4.508BA�񄂆��#Petrotechsocietyen" https://www.petrotechsociety.org
�
Philia Scans,eu.kanade.tachiyomi.extension.en.philiascans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.philiascans-v1.4.55.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.philiascans.png"1.4(721.4.55B5�������KPhilia Scansen"https://philiascans.org
�
Platinum Crown.eu.kanade.tachiyomi.extension.en.platinumcrown�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.platinumcrown-v1.4.46.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.platinumcrown.png"1.4(.21.4.46B9�͂�꒭�)Platinum Crownen"https://platinumscans.com
�
FlameScans.lol+eu.kanade.tachiyomi.extension.en.plutoscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.plutoscans-v1.4.51.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.plutoscans.png"1.4(321.4.51B6�������FlameScans.lolen"https://flamescans.lol
�
Rackus(eu.kanade.tachiyomi.extension.en.pmscans�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.pmscans-v1.4.39.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.pmscans.png"1.4('21.4.39B/����л��Rackusen"https://rackusreads.com
�
	PornComix*eu.kanade.tachiyomi.extension.en.porncomix�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.porncomix-v1.4.49.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.porncomix.png"1.4(121.4.498B4����ؙ��[	PornComixen"https://bestporncomix.com
�
Qi Scans(eu.kanade.tachiyomi.extension.en.qiscans�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.qiscans-v1.4.25.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.qiscans.png"1.4(21.4.25B-��Җ���PQiScansen"https://qimanhwa.com
�
Questionable Content4eu.kanade.tachiyomi.extension.en.questionablecontent�
whttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.questionablecontent-v1.4.10.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.questionablecontent.png"1.4(
21.4.10BI�ۈ�����MQuestionable Contenten"#https://www.questionablecontent.net
�

Rage Scans*eu.kanade.tachiyomi.extension.en.ragescans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.ragescans-v1.4.33.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ragescans.png"1.4(!21.4.33B1��������x
Rage Scansen"https://ragescans.com
�
Rain Of Snow+eu.kanade.tachiyomi.extension.en.rainofsnow�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.rainofsnow-v1.4.8.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.rainofsnow.png"1.4(21.4.8B4˶������{Rain Of Snowen"https://rainofsnow.com
�
Randowiz)eu.kanade.tachiyomi.extension.en.randowiz�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.randowiz-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.randowiz.png"1.4(21.4.2B.݇�ײ���Randowizen"https://randowis.com
�
Raven Scans+eu.kanade.tachiyomi.extension.en.ravenscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.ravenscans-v1.4.34.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ravenscans.png"1.4("21.4.348B3�����ˀ�GRaven Scansen"https://ravenscans.org
�
Razure'eu.kanade.tachiyomi.extension.en.razure�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.razure-v1.4.32.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.razure.png"1.4( 21.4.32B*׌������)Razureen"https://razure.org
�
RD Scans(eu.kanade.tachiyomi.extension.en.rdscans�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.rdscans-v1.4.50.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.rdscans.png"1.4(221.4.50B-��������"RD Scansen"https://rdscans.com
�
ReadAllComics1eu.kanade.tachiyomi.extension.en.readallcomicscom�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readallcomicscom-v1.4.8.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readallcomicscom.png"1.4(21.4.8B7�݊ʨ�gReadAllComicsen"https://readallcomics.com
�
-Read Attack on Titan Shingeki no Kyojin MangaGeu.kanade.tachiyomi.extension.en.readattackontitanshingekinokyojinmanga�
�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readattackontitanshingekinokyojinmanga-v1.4.13.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readattackontitanshingekinokyojinmanga.png"1.4(21.4.13BW촀�ꏥ�{-Read Attack on Titan Shingeki no Kyojin Mangaen"https://ww11.readsnk.com
�
Read Berserk Manga1eu.kanade.tachiyomi.extension.en.readberserkmanga�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readberserkmanga-v1.4.8.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readberserkmanga.png"1.4(21.4.8B;�����ۯ�DRead Berserk Mangaen"https://readberserk.com
�
Read Black Clover Manga Online;eu.kanade.tachiyomi.extension.en.readblackclovermangaonline�
}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readblackclovermangaonline-v1.4.8.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readblackclovermangaonline.png"1.4(21.4.8BP��ף�̫�ZRead Black Clover Manga Onlineen" https://ww10.readblackclover.com
�
1Read Boku no Hero Academia My Hero Academia MangaJeu.kanade.tachiyomi.extension.en.readbokunoheroacademiamyheroacademiamanga�
�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readbokunoheroacademiamyheroacademiamanga-v1.4.10.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readbokunoheroacademiamyheroacademiamanga.png"1.4(
21.4.10B[��ܢ���D1Read Boku no Hero Academia My Hero Academia Mangaen"https://ww10.readmha.com
�
Read Chainsaw Man Manga Online;eu.kanade.tachiyomi.extension.en.readchainsawmanmangaonline�
}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readchainsawmanmangaonline-v1.4.9.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readchainsawmanmangaonline.png"1.4(	21.4.98BO�ӆ��ʢ�VRead Chainsaw Man Manga Onlineen"https://ww5.readchainsawman.com
�
ReadComicOnline0eu.kanade.tachiyomi.extension.en.readcomiconline�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readcomiconline-v1.4.43.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readcomiconline.png"1.4(+21.4.43B7��������oReadComicOnlineen"https://rcostation.xyz
�
Read Comics Online1eu.kanade.tachiyomi.extension.en.readcomicsonline�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readcomicsonline-v1.4.13.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readcomicsonline.png"1.4(21.4.13B?�����ɘ�cRead Comics Onlineen"https://readcomicsonline.ru
�
(Read Dragon Ball Super Chou Manga OnlineCeu.kanade.tachiyomi.extension.en.readdragonballsuperchoumangaonline�
�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readdragonballsuperchoumangaonline-v1.4.7.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readdragonballsuperchoumangaonline.png"1.4(21.4.7BS���ظ��(Read Dragon Ball Super Chou Manga Onlineen"https://ww10.dbsmanga.com
�
Read Dr. Stone Manga Online7eu.kanade.tachiyomi.extension.en.readdrstonemangaonline�
yhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readdrstonemangaonline-v1.4.6.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readdrstonemangaonline.png"1.4(21.4.6BH��������BRead Dr. Stone Manga Onlineen"https://ww7.readdrstone.com
�
)Read Fairy Tail & Edens Zero Manga OnlineBeu.kanade.tachiyomi.extension.en.readfairytailedenszeromangaonline�
�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readfairytailedenszeromangaonline-v1.4.9.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readfairytailedenszeromangaonline.png"1.4(	21.4.9BX������)Read Fairy Tail & Edens Zero Manga Onlineen"https://ww8.readfairytail.com
�
ReadFreeComics/eu.kanade.tachiyomi.extension.en.readfreecomics�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readfreecomics-v1.4.45.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readfreecomics.png"1.4(-21.4.458B:�����ִ�-ReadFreeComicsen"https://readfreecomics.com
�
Read Haikyuu!! Manga Online7eu.kanade.tachiyomi.extension.en.readhaikyuumangaonline�
yhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readhaikyuumangaonline-v1.4.7.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readhaikyuumangaonline.png"1.4(21.4.7BH������ݞ@Read Haikyuu!! Manga Onlineen"https://ww9.readhaikyuu.com
�
!Read Hunter x Hunter Manga Online=eu.kanade.tachiyomi.extension.en.readhunterxhuntermangaonline�
https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readhunterxhuntermangaonline-v1.4.7.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readhunterxhuntermangaonline.png"1.4(21.4.7BJ��������!Read Hunter x Hunter Manga Onlineen"https://ww6.readhxh.com
�
 Read Jujutsu Kaisen Manga Online=eu.kanade.tachiyomi.extension.en.readjujutsukaisenmangaonline�
https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readjujutsukaisenmangaonline-v1.4.9.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readjujutsukaisenmangaonline.png"1.4(	21.4.9BS������� Read Jujutsu Kaisen Manga Onlineen"!https://ww5.readjujutsukaisen.com
�
Read Kaguya-sama Manga Online:eu.kanade.tachiyomi.extension.en.readkaguyasamamangaonline�
|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readkaguyasamamangaonline-v1.4.7.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readkaguyasamamangaonline.png"1.4(21.4.7BM������kRead Kaguya-sama Manga Onlineen"https://ww4.readkaguyasama.com
�
Read Kingdom Manga Online7eu.kanade.tachiyomi.extension.en.readkingdommangaonline�
yhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readkingdommangaonline-v1.4.8.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readkingdommangaonline.png"1.4(21.4.8BF��������nRead Kingdom Manga Onlineen"https://ww5.readkingdom.com
�
ReadMangaFree.eu.kanade.tachiyomi.extension.en.readmangafree�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readmangafree-v1.4.45.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readmangafree.png"1.4(-21.4.458B8�찍�붡ReadMangaFreeen"https://readmangafree.net
�
1Read Nanatsu no Taizai 7 Deadly Sins Manga OnlineJeu.kanade.tachiyomi.extension.en.readnanatsunotaizai7deadlysinsmangaonline�
�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readnanatsunotaizai7deadlysinsmangaonline-v1.4.10.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readnanatsunotaizai7deadlysinsmangaonline.png"1.4(
21.4.10Bb��������61Read Nanatsu no Taizai 7 Deadly Sins Manga Onlineen"https://ww7.read7deadlysins.com
�
)Read Naruto Boruto Samurai 8 Manga OnlineDeu.kanade.tachiyomi.extension.en.readnarutoborutosamurai8mangaonline�
�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readnarutoborutosamurai8mangaonline-v1.4.9.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readnarutoborutosamurai8mangaonline.png"1.4(	21.4.9BVȼ���΅�9)Read Naruto Boruto Samurai 8 Manga Onlineen"https://ww11.readnaruto.com
�
Read One Piece Manga Online8eu.kanade.tachiyomi.extension.en.readonepiecemangaonline�
zhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readonepiecemangaonline-v1.4.8.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readonepiecemangaonline.png"1.4(21.4.8BJ�ͅ�Ӫ��Read One Piece Manga Onlineen"https://ww12.readonepiece.com
�
Read One-Punch Man Manga Online>eu.kanade.tachiyomi.extension.en.readonepunchmanmangaonlinetwo�
�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readonepunchmanmangaonlinetwo-v1.4.8.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readonepunchmanmangaonlinetwo.png"1.4(21.4.8BH��欆��rRead One-Punch Man Manga Onlineen"https://ww6.readopm.com
�
&Read Solo Leveling Manga Manhwa OnlineBeu.kanade.tachiyomi.extension.en.readsololevelingmangamanhwaonline�
�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readsololevelingmangamanhwaonline-v1.4.10.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readsololevelingmangamanhwaonline.png"1.4(
21.4.10BX�����讉&Read Solo Leveling Manga Manhwa Onlineen" https://ww3.readsololeveling.org
�
(Read The Promised Neverland Manga OnlineDeu.kanade.tachiyomi.extension.en.readthepromisedneverlandmangaonline�
�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readthepromisedneverlandmangaonline-v1.4.7.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readthepromisedneverlandmangaonline.png"1.4(21.4.7BW���ӆӱ}(Read The Promised Neverland Manga Onlineen"https://ww7.readneverland.com
�
.Read Tokyo Ghoul Re & Tokyo Ghoul Manga OnlineFeu.kanade.tachiyomi.extension.en.readtokyoghoulretokyoghoulmangaonline�
�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readtokyoghoulretokyoghoulmangaonline-v1.4.11.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readtokyoghoulretokyoghoulmangaonline.png"1.4(21.4.11B]˖������Y.Read Tokyo Ghoul Re & Tokyo Ghoul Manga Onlineen"https://ww11.tokyoghoulre.com
�
Read Vagabond Manga2eu.kanade.tachiyomi.extension.en.readvagabondmanga�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readvagabondmanga-v1.4.1.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readvagabondmanga.png"1.4(21.4.1B>��������IRead Vagabond Mangaen"https://readbagabondo.com
�
Read Vinland Saga Manga Online;eu.kanade.tachiyomi.extension.en.readvinlandsagamangaonline�
}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.readvinlandsagamangaonline-v1.4.6.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readvinlandsagamangaonline.png"1.4(21.4.6BO�򀱂�˾vRead Vinland Saga Manga Onlineen"https://ww5.readvinlandsaga.com
�
Real Life Comics/eu.kanade.tachiyomi.extension.en.reallifecomics�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.reallifecomics-v1.4.3.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.reallifecomics.png"1.4(21.4.3B<�������CReal Life Comicsen"https://reallifecomics.com
�
ReiManga)eu.kanade.tachiyomi.extension.en.reimanga�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.reimanga-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.reimanga.png"1.4(21.4.18B.��������NReiMangaen"https://reimanga.com
�
	Renascans*eu.kanade.tachiyomi.extension.en.renascans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.renascans-v1.4.23.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.renascans.png"1.4(21.4.23B0��ۗ����/	Renascansen"https://renascans.net
�
Reset Scans+eu.kanade.tachiyomi.extension.en.resetscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.resetscans-v1.4.62.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.resetscans.png"1.4(>21.4.62B4��ݛ���sReset Scansen"https://reset-scans.org
�

Rest Scans*eu.kanade.tachiyomi.extension.en.restscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.restscans-v1.4.32.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.restscans.png"1.4( 21.4.328B1ϑ������7
Rest Scansen"https://restscans.com
�
Retsu&eu.kanade.tachiyomi.extension.en.retsu�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.retsu-v1.4.51.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.retsu.png"1.4(321.4.518B(���ͩ��'Retsuen"https://retsu.org
�
Revival Scans-eu.kanade.tachiyomi.extension.en.revivalscans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.revivalscans-v1.4.1.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.revivalscans.png"1.4(21.4.18B;���Ż´_Revival Scansen"https://www.revivalscans.com
�
Rinko Comics,eu.kanade.tachiyomi.extension.en.rinkocomics�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.rinkocomics-v1.4.2.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.rinkocomics.png"1.4(21.4.2B5���΂��DRinko Comicsen"https://rinkocomics.com
�
RitharScans,eu.kanade.tachiyomi.extension.en.ritharscans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.ritharscans-v1.4.23.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ritharscans.png"1.4(21.4.23B4�؃�����rRitharScansen"https://ritharscans.com
�

Rizz Comic*eu.kanade.tachiyomi.extension.en.rizzcomic�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.rizzcomic-v1.4.45.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.rizzcomic.png"1.4(-21.4.45B2�����*
Rizz Comicen"https://rizzfables.com
�
Rizz Comic (unoriginal)4eu.kanade.tachiyomi.extension.en.rizzcomicunoriginal�
whttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.rizzcomicunoriginal-v1.4.32.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.rizzcomicunoriginal.png"1.4( 21.4.32B>�㖌߁��|Rizz Comic (unoriginal)en"https://rizzcomic.com
�
RokariComics-eu.kanade.tachiyomi.extension.en.rokaricomics�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.rokaricomics-v1.4.34.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.rokaricomics.png"1.4("21.4.34B6䂴��RokariComicsen"https://rokaricomics.com
�

Rolia Scan*eu.kanade.tachiyomi.extension.en.roliascan�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.roliascan-v1.4.8.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.roliascan.png"1.4(21.4.8B1�����/
Rolia Scanen"https://roliascan.com
�
Rose Squad Scans/eu.kanade.tachiyomi.extension.en.rosesquadscans�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.rosesquadscans-v1.4.51.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.rosesquadscans.png"1.4(321.4.518BF�����ޛ�KRose Squad Scansen"$https://rosesquadscans.aishiteru.org
�
Ryumanga)eu.kanade.tachiyomi.extension.en.ryumanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.ryumanga-v1.4.20.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ryumanga.png"1.4(21.4.20B.݃�����@Ryumangaen"https://ryumanga.org
�
S2Manga(eu.kanade.tachiyomi.extension.en.s2manga�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.s2manga-v1.4.54.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.s2manga.png"1.4(621.4.548B+����ϼ��CS2Mangaen"https://s2read.com
�

Sana Scans*eu.kanade.tachiyomi.extension.en.sanascans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.sanascans-v1.4.23.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.sanascans.png"1.4(21.4.23B1����ꔆ�
Sana Scansen"https://sanascans.com
�
!Saturday Morning Breakfast Comics?eu.kanade.tachiyomi.extension.en.saturdaymorningbreakfastcomics�
�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.saturdaymorningbreakfastcomics-v1.4.2.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.saturdaymorningbreakfastcomics.png"1.4(21.4.2BJɴ����Ԑ*!Saturday Morning Breakfast Comicsen"https://smbc-comics.com
�
ScansGG(eu.kanade.tachiyomi.extension.en.scansgg�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.scansgg-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.scansgg.png"1.4(21.4.18B)��ҧ���SScansGGen"https://scans.gg
�
Schlock Mercenary1eu.kanade.tachiyomi.extension.en.schlockmercenary�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.schlockmercenary-v1.4.2.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.schlockmercenary.png"1.4(21.4.2BC鞙�����ASchlock Mercenaryen" https://www.schlockmercenary.com
�
Scylla Comics,eu.kanade.tachiyomi.extension.en.scyllascans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.scyllascans-v1.4.12.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.scyllascans.png"1.4(21.4.12B7��ߋ����}Scylla Comicsen"https://scyllacomics.xyz
�
	SectScans*eu.kanade.tachiyomi.extension.en.sectscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.sectscans-v1.4.45.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.sectscans.png"1.4(-21.4.45B0�ߵ���$	SectScansen"https://sectscans.com
�
Setsu Scans+eu.kanade.tachiyomi.extension.en.setsuscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.setsuscans-v1.4.53.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.setsuscans.png"1.4(521.4.53B3���ޟ��vSetsu Scansen"https://setsuscans.com
�
Shiba Manga+eu.kanade.tachiyomi.extension.en.shibamanga�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.shibamanga-v1.4.50.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.shibamanga.png"1.4(221.4.508B3�����"Shiba Mangaen"https://shibamanga.com
�
Violet Scans+eu.kanade.tachiyomi.extension.en.shojoscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.shojoscans-v1.4.35.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.shojoscans.png"1.4(#21.4.35B5���Μ���}Violet Scansen"https://violetscans.org
�
Shooting Star Scans2eu.kanade.tachiyomi.extension.en.shootingstarscans�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.shootingstarscans-v1.4.45.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.shootingstarscans.png"1.4(-21.4.45BB�����桒gShooting Star Scansen"https://shootingstarscans.com
�
Siren Scans+eu.kanade.tachiyomi.extension.en.sirenscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.sirenscans-v1.4.20.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.sirenscans.png"1.4(21.4.20B3���񲡞�PSiren Scansen"https://sirenscans.com
�

Site Manga*eu.kanade.tachiyomi.extension.en.sitemanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.sitemanga-v1.4.46.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.sitemanga.png"1.4(.21.4.468B1ļ��ұ��l
Site Mangaen"https://sitemanga.com
�
	Sky Manga)eu.kanade.tachiyomi.extension.en.skymanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.skymanga-v1.4.33.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.skymanga.png"1.4(!21.4.338B0��������-	Sky Mangaen"https://skymanga.work
�
Sleepy Translations3eu.kanade.tachiyomi.extension.en.sleepytranslations�
vhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.sleepytranslations-v1.4.51.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.sleepytranslations.png"1.4(321.4.51BC�����OSleepy Translationsen"https://sleepytranslations.com
�
Solar and Sundry/eu.kanade.tachiyomi.extension.en.solarandsundry�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.solarandsundry-v1.4.2.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.solarandsundry.png"1.4(21.4.2B9�欮�ٹ�dSolar and Sundryen"https://sas-api.fly.dev
�
Spider Scans,eu.kanade.tachiyomi.extension.en.spiderscans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.spiderscans-v1.4.46.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.spiderscans.png"1.4(.21.4.468B5��᫥�ʌSpider Scansen"https://spiderscans.xyz
�
Spmanhwa)eu.kanade.tachiyomi.extension.en.spmanhwa�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.spmanhwa-v1.4.50.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.spmanhwa.png"1.4(221.4.50B1�ᦼ���ASpmanhwaen"https://spmanhwa.online
�
SpyFakku)eu.kanade.tachiyomi.extension.en.spyfakku�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.spyfakku-v1.4.15.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.spyfakku.png"1.4(21.4.158B,��ܰ��ŉVSpyFakkuen"https://hentalk.pw
�

StoneScape+eu.kanade.tachiyomi.extension.en.stonescape�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.stonescape-v1.4.49.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.stonescape.png"1.4(121.4.49B2����탐�R
StoneScapeen"https://stonescape.xyz
�
Sunshine Butterfly Scans7eu.kanade.tachiyomi.extension.en.sunshinebutterflyscans�
zhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.sunshinebutterflyscans-v1.4.39.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.sunshinebutterflyscans.png"1.4('21.4.398B;�䟰����Sunshine Butterfly Scansen"https://wings.sbs
�

SUPER MEGA*eu.kanade.tachiyomi.extension.en.supermega�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.supermega-v1.4.4.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.supermega.png"1.4(21.4.4B;��Ρݽ��m
SUPER MEGAen"https://www.supermegacomics.com
�

Genz Toons+eu.kanade.tachiyomi.extension.en.suryascans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.suryascans-v1.4.53.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.suryascans.png"1.4(521.4.53B1��ǹ����
Genz Toonsen"https://genztoons.org
�
Swords Comic,eu.kanade.tachiyomi.extension.en.swordscomic�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.swordscomic-v1.4.5.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.swordscomic.png"1.4(21.4.5B5����ײ��8Swords Comicen"https://swordscomic.com
�
Taadd&eu.kanade.tachiyomi.extension.en.taadd�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.taadd-v1.4.1.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.taadd.png"1.4(21.4.18B,�������$Taadden"https://www.taadd.com
�
Tapas)eu.kanade.tachiyomi.extension.en.tapastic�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.tapastic-v1.4.24.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.tapastic.png"1.4(21.4.248B'��ͣ�ӛ�MTapasen"https://tapas.io
�
TappyToon.Net-eu.kanade.tachiyomi.extension.en.tappytoonnet�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.tappytoonnet-v1.4.45.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.tappytoonnet.png"1.4(-21.4.45B4Շ�櫍��^TappyToon.Neten"https://tappytoon.net
�
	TCB Scans)eu.kanade.tachiyomi.extension.en.tcbscans�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.tcbscans-v1.4.12.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.tcbscans.png"1.4(21.4.12B:�������	TCB Scansen"https://tcbonepiecechapters.com
�
TCB Scans (Unoriginal)3eu.kanade.tachiyomi.extension.en.tcbscansunoriginal�
vhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.tcbscansunoriginal-v1.4.32.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.tcbscansunoriginal.png"1.4( 21.4.32BKΓц����*TCB Scans (Unoriginal)en"#https://tcbscanonepiecechapters.com
�
Team Shadowi,eu.kanade.tachiyomi.extension.en.teamshadowi�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.teamshadowi-v1.4.1.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.teamshadowi.png"1.4(21.4.18B:������´Team Shadowien"https://www.team-shadowi.com
�
Temple Scan+eu.kanade.tachiyomi.extension.en.templescan�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.templescan-v1.4.49.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.templescan.png"1.4(121.4.498B4������:Temple Scanen"https://templetoons.com
�
	The Blank)eu.kanade.tachiyomi.extension.en.theblank�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.theblank-v1.4.56.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.theblank.png"1.4(821.4.568B/ϳ����פh	The Blanken"https://theblank.net
�
The Duck Webcomics1eu.kanade.tachiyomi.extension.en.theduckwebcomics�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.theduckwebcomics-v1.4.3.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.theduckwebcomics.png"1.4(21.4.38BD�����JThe Duck Webcomicsen" https://www.theduckwebcomics.com
�
The Property of Hate2eu.kanade.tachiyomi.extension.en.thepropertyofhate�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.thepropertyofhate-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.thepropertyofhate.png"1.4(21.4.5B>����͞�eThe Property of Hateen"https://jolleycomics.com
�
TimelessToons.eu.kanade.tachiyomi.extension.en.timelesstoons�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.timelesstoons-v1.4.20.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.timelesstoons.png"1.4(21.4.20B8�����׫�}TimelessToonsen"https://timelesstoons.org
�

TodayManga+eu.kanade.tachiyomi.extension.en.todaymanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.todaymanga-v1.4.3.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.todaymanga.png"1.4(21.4.38B2���ˋ���
TodayMangaen"https://todaymanga.com
�
Toon18'eu.kanade.tachiyomi.extension.en.toon18�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.toon18-v1.4.50.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.toon18.png"1.4(221.4.508B)��������uToon18en"https://toon18.to
�
	ToonChill*eu.kanade.tachiyomi.extension.en.toonchill�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.toonchill-v1.4.46.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.toonchill.png"1.4(.21.4.46B0�����̩�	ToonChillen"https://toonchill.com
�
ToonGod(eu.kanade.tachiyomi.extension.en.toongod�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.toongod-v1.4.55.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.toongod.png"1.4(721.4.558B0����ʚ��ToonGoden"https://www.toongod.org
�
Toonily(eu.kanade.tachiyomi.extension.en.toonily�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.toonily-v1.4.64.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.toonily.png"1.4(@21.4.648B,��˾��HToonilyen"https://toonily.com
�

Toonily.me*eu.kanade.tachiyomi.extension.en.toonilyme�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.toonilyme-v1.4.24.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.toonilyme.png"1.4(21.4.248B.Ȣ������
Toonily.meen"https://toonily.me
�
	TooniTube*eu.kanade.tachiyomi.extension.en.toonitube�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.toonitube-v1.4.24.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.toonitube.png"1.4(21.4.248B0���ú�q	TooniTubeen"https://toonitube.com
�
Toonizy(eu.kanade.tachiyomi.extension.en.toonizy�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.toonizy-v1.4.50.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.toonizy.png"1.4(221.4.508B,�݂۫�KToonizyen"https://toonizy.com
�

Top Manhua*eu.kanade.tachiyomi.extension.en.topmanhua�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.topmanhua-v1.4.57.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.topmanhua.png"1.4(921.4.578B0��������
Top Manhuaen"https://mangatop.org
�
TopManhua.fan-eu.kanade.tachiyomi.extension.en.topmanhuafan�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.topmanhuafan-v1.4.50.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.topmanhuafan.png"1.4(221.4.508B8��������WTopManhua.fanen"https://www.topmanhua.fan
�
TopManhua.net-eu.kanade.tachiyomi.extension.en.topmanhuanet�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.topmanhuanet-v1.4.50.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.topmanhuanet.png"1.4(221.4.508B4Ѧ䬒׍�YTopManhua.neten"https://topmanhua.net
�
TopReadManhwa.eu.kanade.tachiyomi.extension.en.topreadmanhwa�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.topreadmanhwa-v1.4.45.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.topreadmanhwa.png"1.4(-21.4.458B8�Ƕ�����TopReadManhwaen"https://topreadmanhwa.com
�
TritiniaScans.eu.kanade.tachiyomi.extension.en.tritiniascans�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.tritiniascans-v1.4.54.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.tritiniascans.png"1.4(621.4.54B3��砫���STritiniaScansen"https://tritinia.org
�
Tsumino(eu.kanade.tachiyomi.extension.en.tsumino�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.tsumino-v1.4.8.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.tsumino.png"1.4(21.4.88B0������Њ]Tsuminoen"https://www.tsumino.com
�
Utoon&eu.kanade.tachiyomi.extension.en.utoon�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.utoon-v1.4.54.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.utoon.png"1.4(621.4.54B(��ʑ����2Utoonen"https://utoon.net
�
Valir Scans+eu.kanade.tachiyomi.extension.en.valirscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.valirscans-v1.4.21.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.valirscans.png"1.4(21.4.21B3�������uValir Scansen"https://valirscans.org
�
Vanilla Scans-eu.kanade.tachiyomi.extension.en.vanillascans�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.vanillascans-v1.4.23.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.vanillascans.png"1.4(21.4.23B7���Ɵî�Vanilla Scansen"https://vanillascans.org
�
vgperson)eu.kanade.tachiyomi.extension.en.vgperson�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.vgperson-v1.4.7.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.vgperson.png"1.4(21.4.7BD���Ǿ�yvgpersonen"*https://vgperson.com/other/mangaviewer.php
�
VIZ.eu.kanade.tachiyomi.extension.en.vizshonenjump�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.vizshonenjump-v1.4.25.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.vizshonenjump.png"1.4(21.4.25B4ô������%VIZ Shonen Jumpen"https://www.viz.comB.�´��)	VIZ Mangaen"https://www.viz.com
�
Voyce.Me(eu.kanade.tachiyomi.extension.en.voyceme�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.voyceme-v1.4.6.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.voyceme.png"1.4(21.4.6B-�Ԉ�����BVoyceMeen"https://www.voyce.me
�
	VyvyManga*eu.kanade.tachiyomi.extension.en.vyvymanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.vyvymanga-v1.4.40.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.vyvymanga.png"1.4((21.4.408B.٣֐Ӕ��`	VyvyMangaen"https://vymanga.net
�
VyvyManga.org-eu.kanade.tachiyomi.extension.en.vyvymangaorg�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.vyvymangaorg-v1.4.50.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.vyvymangaorg.png"1.4(221.4.508B4㹕�����!VyvyManga.orgen"https://vyvymanga.org
�
War For Rayuba-eu.kanade.tachiyomi.extension.en.warforrayuba�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.warforrayuba-v1.4.3.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.warforrayuba.png"1.4(21.4.3BE��볱��War For Rayubaen"%https://xrabohrok.github.io/WarMap/#/
�

KokoMangas,eu.kanade.tachiyomi.extension.en.wearehunger�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.wearehunger-v1.4.52.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.wearehunger.png"1.4(421.4.528B1���磷�h
KokoMangasen"https://kokomangas.com
�
	Webcomics*eu.kanade.tachiyomi.extension.en.webcomics�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.webcomics-v1.4.10.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.webcomics.png"1.4(
21.4.10B3��������h	Webcomicsen"https://webcomicsapp.com
�
Webdex Scans,eu.kanade.tachiyomi.extension.en.webdexscans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.webdexscans-v1.4.51.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.webdexscans.png"1.4(321.4.51B5��㉜���eWebdex Scansen"https://webdexscans.com
�
Web Niichan+eu.kanade.tachiyomi.extension.en.webniichan�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.webniichan-v1.4.45.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.webniichan.png"1.4(-21.4.45B6��������yWeb Niichanen"https://webniichan.online
�
WebNovel)eu.kanade.tachiyomi.extension.en.webnovel�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.webnovel-v1.4.13.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.webnovel.png"1.4(21.4.13B2�������8WebNovelen"https://www.webnovel.com
�
WebtoonScan,eu.kanade.tachiyomi.extension.en.webtoonscan�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.webtoonscan-v1.4.50.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.webtoonscan.png"1.4(221.4.508B4я������*WebtoonScanen"https://webtoonscan.com
�

WebtoonXYZ+eu.kanade.tachiyomi.extension.en.webtoonxyz�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.webtoonxyz-v1.4.54.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.webtoonxyz.png"1.4(621.4.548B3�������]
WebtoonXYZen"https://www.webtoon.xyz
�
Weeb Central,eu.kanade.tachiyomi.extension.en.weebcentral�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.weebcentral-v1.4.22.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.weebcentral.png"1.4(21.4.228B5ú�̬ӹ�Weeb Centralen"https://weebcentral.com
�
Whale Manga+eu.kanade.tachiyomi.extension.en.whalemanga�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.whalemanga-v1.4.50.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.whalemanga.png"1.4(221.4.508B2ᰎ�ՠ��N
WhaleMangaen"https://whalemanga.com
�

WitchScans+eu.kanade.tachiyomi.extension.en.witchscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.witchscans-v1.4.32.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.witchscans.png"1.4( 21.4.32B2֥��뤟�v
WitchScansen"https://witchscans.com
�
WoopRead)eu.kanade.tachiyomi.extension.en.woopread�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.woopread-v1.4.51.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.woopread.png"1.4(321.4.51B.��㡓���{WoopReaden"https://woopread.com
�
Writer Scans,eu.kanade.tachiyomi.extension.en.writerscans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.writerscans-v1.4.20.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.writerscans.png"1.4(21.4.20B5��ҳ����Writer Scansen"https://writerscans.com
�

WuxiaWorld+eu.kanade.tachiyomi.extension.en.wuxiaworld�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.wuxiaworld-v1.4.51.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.wuxiaworld.png"1.4(321.4.51B3���۠���Z
WuxiaWorlden"https://wuxiaworld.site
�
xCaliBR Scans-eu.kanade.tachiyomi.extension.en.xcalibrscans�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.xcalibrscans-v1.4.35.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.xcalibrscans.png"1.4(#21.4.35B7ѩ��ѭڈNxCaliBR Scansen"https://xcalibrscans.com
�
XlecX&eu.kanade.tachiyomi.extension.en.xlecx�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.xlecx-v1.4.1.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.xlecx.png"1.4(21.4.18B(ǆ�����3XlecXen"https://xlecx.one
�
XoManga(eu.kanade.tachiyomi.extension.en.xomanga�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.xomanga-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.xomanga.png"1.4(21.4.18B1��ﳽ�ؙEXoMangaen"https://www.xomanga.site
�
XOXO Comics+eu.kanade.tachiyomi.extension.en.xoxocomics�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.xoxocomics-v1.4.13.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.xoxocomics.png"1.4(21.4.13B2�����Χ�!XOXO Comicsen"https://xoxocomic.com
�
Xscans'eu.kanade.tachiyomi.extension.en.xscans�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.xscans-v1.4.1.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.xscans.png"1.4(21.4.1B+�҃���eXscansen"https://xscans.site
�
YakshaComics-eu.kanade.tachiyomi.extension.en.yakshacomics�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.yakshacomics-v1.4.52.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.yakshacomics.png"1.4(421.4.52B6��������CYakshaComicsen"https://yakshacomics.com
�
YakshaScans,eu.kanade.tachiyomi.extension.en.yakshascans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.yakshascans-v1.4.47.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.yakshascans.png"1.4(/21.4.478B4���ԯ���%YakshaScansen"https://yakshascans.com
�
YaoiHot(eu.kanade.tachiyomi.extension.en.yaoihot�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.yaoihot-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.yaoihot.png"1.4(21.4.18B,��������&YaoiHoten"https://yaoihot.com
�
Yaoihub(eu.kanade.tachiyomi.extension.en.yaoihub�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.yaoihub-v1.4.52.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.yaoihub.png"1.4(421.4.528B,��ʸ��]Yaoihuben"https://yaoihub.net
�
YaoiScan)eu.kanade.tachiyomi.extension.en.yaoiscan�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.yaoiscan-v1.4.50.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.yaoiscan.png"1.4(221.4.508B.��Ӹ����=YaoiScanen"https://yaoiscan.com
�
YaoiToon)eu.kanade.tachiyomi.extension.en.yaoitoon�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.yaoitoon-v1.4.48.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.yaoitoon.png"1.4(021.4.488B.謈�����QYaoiToonen"https://yaoitoon.net
�
Yorai&eu.kanade.tachiyomi.extension.en.yorai�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.yorai-v1.4.2.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.yorai.png"1.4(21.4.2B'����Ϩ�"Yoraien"https://yorai.io
�
	Zazamanga*eu.kanade.tachiyomi.extension.en.zazamanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.zazamanga-v1.4.51.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.zazamanga.png"1.4(321.4.518B4���ּװ�	Zazamangaen"https://www.zazamanga.com
�

Zero Scans*eu.kanade.tachiyomi.extension.en.zeroscans�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.zeroscans-v1.4.7.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.zeroscans.png"1.4(21.4.7B.�����ȯ�]
Zero Scansen"https://zscans.com
�
ZinChanManga-eu.kanade.tachiyomi.extension.en.zinchanmanga�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.zinchanmanga-v1.4.53.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.zinchanmanga.png"1.4(521.4.538B7�ɿ�����ZinChanMangaen"https://zinchangmanga.net
�
ZinChanManga.com0eu.kanade.tachiyomi.extension.en.zinchanmangacom�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.zinchanmangacom-v1.4.53.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.zinchanmangacom.png"1.4(521.4.538B;՝������uZinChanManga.comen"https://zinchangmanga.net
�
Zinmanga)eu.kanade.tachiyomi.extension.en.zinmanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.zinmanga-v1.4.53.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.zinmanga.png"1.4(521.4.538B.�����ʐSZinmangaen"https://mangazin.org
�
Zinmanga.net,eu.kanade.tachiyomi.extension.en.zinmanganet�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-en.zinmanganet-v1.4.50.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.zinmanganet.png"1.4(221.4.50B2���⢸��Zinmanga.neten"https://zinmanga.net
�
AKAYA&eu.kanade.tachiyomi.extension.es.akaya�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.akaya-v1.4.3.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.akaya.png"1.4(21.4.38B'���Ջ�ϧ	AKAYAes"https://akaya.io
�
Alpha Centauri.eu.kanade.tachiyomi.extension.es.alphacentauri�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.alphacentauri-v1.4.5.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.alphacentauri.png"1.4(21.4.5BK��������'Alpha Centauries"+https://capibaratraductor.com/alphacentauri
�

Ame Fansub*eu.kanade.tachiyomi.extension.es.amefansub�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.amefansub-v1.4.5.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.amefansub.png"1.4(21.4.5B=��������
Ame Fansubes"!https://capibaratraductor.com/ame
�
Animu No Mansebia0eu.kanade.tachiyomi.extension.es.animunomansebia�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.animunomansebia-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.animunomansebia.png"1.4(21.4.5BH��������#Animu No Mansebiaes"%https://capibaratraductor.com/animunm
�
AntiPatreon Scan0eu.kanade.tachiyomi.extension.es.antipatreonscan�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.antipatreonscan-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.antipatreonscan.png"1.4(21.4.58BK���㢢��TAntiPatreon Scanes")https://capibaratraductor.com/antipatreon
�
AnzManga)eu.kanade.tachiyomi.extension.es.anzmanga�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.anzmanga-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.anzmanga.png"1.4(21.4.1B4������ޫfAnzMangaes"https://www.anzmanga25.com
�
ApollComics,eu.kanade.tachiyomi.extension.es.apollcomics�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.apollcomics-v1.4.53.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.apollcomics.png"1.4(521.4.538B3��������*ApollComicses"https://apollcomics.es
�
Arigato S.A*eu.kanade.tachiyomi.extension.es.arigatosa�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.arigatosa-v1.4.5.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.arigatosa.png"1.4(21.4.5BD�������Arigato S.Aes"'https://capibaratraductor.com/arigatosa
�

Asia Lotus*eu.kanade.tachiyomi.extension.es.asialotus�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.asialotus-v1.4.33.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.asialotus.png"1.4(!21.4.338B2��������2
Asia Lotuses"https://asialotuss.com
�
Asperuas Tradus/eu.kanade.tachiyomi.extension.es.asperuastradus�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.asperuastradus-v1.4.5.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.asperuastradus.png"1.4(21.4.5BM��׶����UAsperuas Traduses",https://capibaratraductor.com/asperuastradus
�
Asuka Langley Translations9eu.kanade.tachiyomi.extension.es.asukalangleytranslations�
{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.asukalangleytranslations-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.asukalangleytranslations.png"1.4(21.4.58B[�����祎}Asuka Langley Translationses"/https://capibaratraductor.com/asukatranslations
�
Azure Bloom+eu.kanade.tachiyomi.extension.es.azurebloom�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.azurebloom-v1.4.5.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.azurebloom.png"1.4(21.4.5BE��������vAzure Bloomes"(https://capibaratraductor.com/azurebloom
�
Bakaguya Scanlation3eu.kanade.tachiyomi.extension.es.bakaguyascanlation�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.bakaguyascanlation-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.bakaguyascanlation.png"1.4(21.4.5BK��������%Bakaguya Scanlationes"&https://capibaratraductor.com/bakaguya
�
BarManga)eu.kanade.tachiyomi.extension.es.barmanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.barmanga-v1.4.61.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.barmanga.png"1.4(=21.4.618B2��������BarMangaes"https://archiviumbar.com
�
	Beeg Gimp)eu.kanade.tachiyomi.extension.es.beeggimp�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.beeggimp-v1.4.5.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.beeggimp.png"1.4(21.4.5BA��余��q	Beeg Gimpes"&https://capibaratraductor.com/beeggimp
�
Bega Translation0eu.kanade.tachiyomi.extension.es.begatranslation�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.begatranslation-v1.4.52.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.begatranslation.png"1.4(421.4.528B=��۰р��]Bega Translationes"https://begatranslation.com
�
Beyond Birthday Subs3eu.kanade.tachiyomi.extension.es.beyondbirthdaysubs�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.beyondbirthdaysubs-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.beyondbirthdaysubs.png"1.4(21.4.5BV�ʽ�����~Beyond Birthday Subses"0https://capibaratraductor.com/beyondbirthdaysubs
�
Biblio Panda,eu.kanade.tachiyomi.extension.es.bibliopanda�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.bibliopanda-v1.4.53.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.bibliopanda.png"1.4(521.4.53B5�ґ��rBiblio Pandaes"https://bibliopanda.com
�
Bloom Scans+eu.kanade.tachiyomi.extension.es.bloomscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.bloomscans-v1.4.34.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.bloomscans.png"1.4("21.4.348B3�����ա�$Bloom Scanses"https://bloomscans.com
�
BokugenTranslation3eu.kanade.tachiyomi.extension.es.bokugentranslation�
vhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.bokugentranslation-v1.4.50.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.bokugentranslation.png"1.4(221.4.50B9Ѵ�Ø���BokugenTranslationes"https://bokugents.com
�
Bonbon Scanlation1eu.kanade.tachiyomi.extension.es.bonbonscanlation�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.bonbonscanlation-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.bonbonscanlation.png"1.4(21.4.58BQ�������+Bonbon Scanlationes".https://capibaratraductor.com/bonbonscanlation
�
Bored Slayer Scan0eu.kanade.tachiyomi.extension.es.boredslayerscan�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.boredslayerscan-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.boredslayerscan.png"1.4(21.4.58BP��������}Bored Slayer Scanes"-https://capibaratraductor.com/boredslayerscan
�
Brakeout)eu.kanade.tachiyomi.extension.es.brakeout�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.brakeout-v1.4.3.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.brakeout.png"1.4(21.4.3B.���ҥ���bBrakeoutes"https://brakeout.xyz
�

Break Scan*eu.kanade.tachiyomi.extension.es.breakscan�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.breakscan-v1.4.5.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.breakscan.png"1.4(21.4.58BCι��ͼ��#
Break Scanes"'https://capibaratraductor.com/breakscan
�
Bymichi Scan,eu.kanade.tachiyomi.extension.es.bymichiscan�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.bymichiscan-v1.4.33.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.bymichiscan.png"1.4(!21.4.338B3����­��=Bymichi Scanes"https://bymichiby.com
�
CathalTraducciones3eu.kanade.tachiyomi.extension.es.cathaltraducciones�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.cathaltraducciones-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.cathaltraducciones.png"1.4(21.4.58BJ�����ʛ{CathalTraduccioneses"&https://capibaratraductor.com/cathaltl
�
Catharsis Fantasy1eu.kanade.tachiyomi.extension.es.catharsisfantasy�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.catharsisfantasy-v1.4.30.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.catharsisfantasy.png"1.4(21.4.308B?��������?Catharsis Fantasyes"https://catharsisfantasy.com
�
Catharsis World/eu.kanade.tachiyomi.extension.es.catharsisworld�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.catharsisworld-v1.4.64.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.catharsisworld.png"1.4(@21.4.648BC��������'Catharsis Worldes""https://catharsisworld.dig-it.info
�
Catoons+eu.kanade.tachiyomi.extension.es.catmanhwas�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.catmanhwas-v1.4.53.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.catmanhwas.png"1.4(521.4.538B,���Ċ��Catoonses"https://newcat1.xyz
�
Celestial Moon.eu.kanade.tachiyomi.extension.es.celestialmoon�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.celestialmoon-v1.4.33.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.celestialmoon.png"1.4(!21.4.338B<��������kCelestial Moones"https://celestialmoonscan.es
�
Cerberus Series/eu.kanade.tachiyomi.extension.es.cerberusseries�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.cerberusseries-v1.4.33.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.cerberusseries.png"1.4(!21.4.33B;��������Cerberus Serieses"https://legionscans.com/wp
�
Chibis Scan+eu.kanade.tachiyomi.extension.es.chibisscan�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.chibisscan-v1.4.5.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.chibisscan.png"1.4(21.4.58BA���̎���\Chibis Scanes"$https://capibaratraductor.com/chibis
�
ChoChoX(eu.kanade.tachiyomi.extension.es.chochox�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.chochox-v1.4.3.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.chochox.png"1.4(21.4.38B,�������ChoChoXes"https://chochox.com
�
Chunchunmaru Translations9eu.kanade.tachiyomi.extension.es.chunchunmarutranslations�
{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.chunchunmarutranslations-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.chunchunmarutranslations.png"1.4(21.4.5BW���ʋ�݆,Chunchunmaru Translationses",https://capibaratraductor.com/chunchunmarutl
�
Code Arc Mangas(eu.kanade.tachiyomi.extension.es.codearc�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.codearc-v1.4.2.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.codearc.png"1.4(21.4.28BG��������LCode Arc Mangases"&https://mangas.codearctraducciones.com
�

Codex Zero*eu.kanade.tachiyomi.extension.es.codexzero�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.codexzero-v1.4.52.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.codexzero.png"1.4(421.4.52B6��圁ɕK
Codex Zeroes"https://codex.readkisho.me
�
Colorcito Scan.eu.kanade.tachiyomi.extension.es.colorcitoscan�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.colorcitoscan-v1.4.3.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.colorcitoscan.png"1.4(21.4.38B9�ׂɎ���Colorcito Scanes"https://colorcitoscan.com
�
Crimson Scan,eu.kanade.tachiyomi.extension.es.crimsonscan�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.crimsonscan-v1.4.5.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.crimsonscan.png"1.4(21.4.58BG�秗ˆ��VCrimson Scanes")https://capibaratraductor.com/crimsonscan
�
Culto a Slanesh.eu.kanade.tachiyomi.extension.es.cultoaslanesh�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.cultoaslanesh-v1.4.5.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.cultoaslanesh.png"1.4(21.4.58BL���د��Culto a Slaneshes"+https://capibaratraductor.com/cultoaslanesh
�
Daisuki na Fansub0eu.kanade.tachiyomi.extension.es.daisukinafansub�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.daisukinafansub-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.daisukinafansub.png"1.4(21.4.5BI�������Daisuki na Fansubes"&https://capibaratraductor.com/dnfansub
�
Daleth Project.eu.kanade.tachiyomi.extension.es.dalethproject�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.dalethproject-v1.4.5.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.dalethproject.png"1.4(21.4.58BF��뉏��!Daleth Projectes"&https://capibaratraductor.com/nameless
�
DapRob'eu.kanade.tachiyomi.extension.es.daprob�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.daprob-v1.4.50.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.daprob.png"1.4(221.4.50B*��������HDapRobes"https://daprob.com
�
Dark Room Fansub/eu.kanade.tachiyomi.extension.es.darkroomfansub�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.darkroomfansub-v1.4.15.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.darkroomfansub.png"1.4(21.4.158BL��������&Dark Room Fansubes"*https://lector-darkroomfansub.blogspot.com
�
Dat-Gar Scan1eu.kanade.tachiyomi.extension.es.datgarscanlation�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.datgarscanlation-v1.4.14.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.datgarscanlation.png"1.4(21.4.14BC잜�����Dat-Gar Scanes"%https://datgarscanlation.blogspot.com
�
Dokjasheart scanlation6eu.kanade.tachiyomi.extension.es.dokjasheartscanlation�
xhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.dokjasheartscanlation-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.dokjasheartscanlation.png"1.4(21.4.58BQ�Œ�����Dokjasheart scanlationes")https://capibaratraductor.com/dokjasheart
�
DORAGON NO TENSEI0eu.kanade.tachiyomi.extension.es.doragonnotensei�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.doragonnotensei-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.doragonnotensei.png"1.4(21.4.5BD�������PDORAGON NO TENSEIes"!https://capibaratraductor.com/dnt
�

Doujinclub+eu.kanade.tachiyomi.extension.es.doujinclub�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.doujinclub-v1.4.5.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.doujinclub.png"1.4(21.4.58BD��ȧ�݀k
Doujinclubes"(https://capibaratraductor.com/doujinclub
�
DoujinHentai-eu.kanade.tachiyomi.extension.es.doujinhentai�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.doujinhentai-v1.4.50.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.doujinhentai.png"1.4(221.4.508B6����ɵ��6DoujinHentaies"https://doujinhentai.net
�
DoujinsHell,eu.kanade.tachiyomi.extension.es.doujinshell�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.doujinshell-v1.4.51.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.doujinshell.png"1.4(321.4.518B4����Մ��aDoujinsHelles"https://doujinshell.net
�
DragonTranslation.org5eu.kanade.tachiyomi.extension.es.dragontranslationorg�
xhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.dragontranslationorg-v1.4.51.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.dragontranslationorg.png"1.4(321.4.518BD��Ћ���@DragonTranslation.orges"https://dragontranslation.org
�
De Todo Un Poco Scan)eu.kanade.tachiyomi.extension.es.dtupscan�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.dtupscan-v1.4.30.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.dtupscan.png"1.4(21.4.30B:��������-De Todo Un Poco Scanes"https://dtupscan.com
�
Dynasty(eu.kanade.tachiyomi.extension.es.dynasty�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.dynasty-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.dynasty.png"1.4(21.4.18B-��䓐���Dynastyes"https://manhuako.net
�

Eljeksreal+eu.kanade.tachiyomi.extension.es.eljeksreal�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.eljeksreal-v1.4.5.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.eljeksreal.png"1.4(21.4.5BD�歉����
Eljeksreales"(https://capibaratraductor.com/eljeksreal
�
El Scan Semanal.eu.kanade.tachiyomi.extension.es.elscansemanal�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.elscansemanal-v1.4.5.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.elscansemanal.png"1.4(21.4.5BL���Ĺʍ�TEl Scan Semanales"+https://capibaratraductor.com/elscansemanal
�
Emperor Scan,eu.kanade.tachiyomi.extension.es.emperorscan�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.emperorscan-v1.4.62.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.emperorscan.png"1.4(>21.4.62B7���󅝊�?Emperor Scanes"https://imperiomanhua.com
�
EnchiladaScan.eu.kanade.tachiyomi.extension.es.enchiladascan�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.enchiladascan-v1.4.1.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.enchiladascan.png"1.4(21.4.1BK���߸���{EnchiladaScanes",https://enchiladascan.github.io/enchiladaweb
�
Eris Greyrat Translations8eu.kanade.tachiyomi.extension.es.erisgreyrattranslations�
zhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.erisgreyrattranslations-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.erisgreyrattranslations.png"1.4(21.4.58B`��ױ�뜨eEris Greyrat Translationses"5https://capibaratraductor.com/erisgreyrattranslations
�
Escaneo de Leyendas2eu.kanade.tachiyomi.extension.es.escaneodeleyendas�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.escaneodeleyendas-v1.4.50.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.escaneodeleyendas.png"1.4(221.4.50BB▥�Ѹ��dEscaneo de Leyendases"https://escaneodeleyendas.com
�
Es.Mi2Manga+eu.kanade.tachiyomi.extension.es.esmi2manga�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.esmi2manga-v1.4.51.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.esmi2manga.png"1.4(321.4.518B4��������Es.Mi2Mangaes"https://es.mi2manga.com
�
EternalMangas.eu.kanade.tachiyomi.extension.es.eternalmangas�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.eternalmangas-v1.4.25.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.eternalmangas.png"1.4(21.4.258B8�몬���EternalMangases"https://eternalmangas.org
�
Fafa%eu.kanade.tachiyomi.extension.es.fafa�
ghttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.fafa-v1.4.5.apkuhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.fafa.png"1.4(21.4.58B8��ǌ����Fafaes""https://capibaratraductor.com/fafa
�
FaxxTraduce,eu.kanade.tachiyomi.extension.es.faxxtraduce�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.faxxtraduce-v1.4.5.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.faxxtraduce.png"1.4(21.4.58BF覗���۹{FaxxTraducees")https://capibaratraductor.com/faxxtraduce
�
Foy Scan(eu.kanade.tachiyomi.extension.es.foyscan�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.foyscan-v1.4.5.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.foyscan.png"1.4(21.4.5B-��Ö����%Foy Scanes"https://foyscan.xyz
�
Fstake Sukyan-eu.kanade.tachiyomi.extension.es.fstakesukyan�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.fstakesukyan-v1.4.5.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.fstakesukyan.png"1.4(21.4.5BI��������kFstake Sukyanes"*https://capibaratraductor.com/fstakesukyan
�
Gistamis House.eu.kanade.tachiyomi.extension.es.gistamishouse�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.gistamishouse-v1.4.15.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.gistamishouse.png"1.4(21.4.158BH��ꦡ��Gistamis Housees"(https://gistamishousefansub.blogspot.com
�
Glowi&eu.kanade.tachiyomi.extension.es.glowi�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.glowi-v1.4.5.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.glowi.png"1.4(21.4.58B:̪�����HGlowies"#https://capibaratraductor.com/glowi
�
Gremory Mangas.eu.kanade.tachiyomi.extension.es.gremorymangas�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.gremorymangas-v1.4.51.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.gremorymangas.png"1.4(321.4.51B<�މա���_Gremory Mangases"https://gremoryhistorias.org
�
Hachimitsu Tsuki0eu.kanade.tachiyomi.extension.es.hachimitsutsuki�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.hachimitsutsuki-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.hachimitsutsuki.png"1.4(21.4.5BK��������<Hachimitsu Tsukies")https://capibaratraductor.com/shojopapers
�
Hades no Fansub.eu.kanade.tachiyomi.extension.es.hadesnofansub�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.hadesnofansub-v1.4.55.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.hadesnofansub.png"1.4(721.4.558BB��ˇ߼��sHades no Fansubes"!https://lectorhades.latamtoon.com
�
Hangyaku no Scanlation5eu.kanade.tachiyomi.extension.es.hangyakunoscanlation�
whttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.hangyakunoscanlation-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.hangyakunoscanlation.png"1.4(21.4.58BZ��������tHangyaku no Scanlationes"2https://capibaratraductor.com/hangyakunoscanlation
�
Harem de Kira,eu.kanade.tachiyomi.extension.es.haremdekira�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.haremdekira-v1.4.53.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.haremdekira.png"1.4(521.4.538B6�ợ����Harem de Kiraes"https://kiraproject.lat
�
	Haru Scan)eu.kanade.tachiyomi.extension.es.haruscan�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.haruscan-v1.4.5.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.haruscan.png"1.4(21.4.5BA�����6	Haru Scanes"&https://capibaratraductor.com/haruscan
�
HeavenManga,eu.kanade.tachiyomi.extension.es.heavenmanga�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.heavenmanga-v1.4.9.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.heavenmanga.png"1.4(	21.4.98B4�䥸����HeavenMangaes"https://heavenmanga.com
�

HentaiHall+eu.kanade.tachiyomi.extension.es.hentaihall�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.hentaihall-v1.4.1.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.hentaihall.png"1.4(21.4.18B2߄���ӝ�u
HentaiHalles"https://hentaihall.com
�

HentaiMode+eu.kanade.tachiyomi.extension.es.hentaimode�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.hentaimode-v1.4.7.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.hentaimode.png"1.4(21.4.78B2ڽ����ΤH
HentaiModees"https://hentaimode.com
�
Hmangakyomi,eu.kanade.tachiyomi.extension.es.hmangakyomi�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.hmangakyomi-v1.4.32.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.hmangakyomi.png"1.4( 21.4.328B7�ʊ�����MHmangakyomies"https://hmangakyomi.online
�
HOMOcdrs)eu.kanade.tachiyomi.extension.es.homocdrs�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.homocdrs-v1.4.5.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.homocdrs.png"1.4(21.4.58BA��̡��ȂHOMOcdrses"'https://capibaratraductor.com/hmcdrscan
�
House Of Otakus.eu.kanade.tachiyomi.extension.es.houseofotakus�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.houseofotakus-v1.4.50.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.houseofotakus.png"1.4(221.4.508B<������House Of Otakuses"https://houseofotakusv2.xyz
�
Ikigai Mangas-eu.kanade.tachiyomi.extension.es.ikigaimangas�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.ikigaimangas-v1.4.32.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.ikigaimangas.png"1.4( 21.4.328B@����̜݊1Ikigai Mangases"!https://zonaikigai.gamesview.shop
�
	Ikuhentai*eu.kanade.tachiyomi.extension.es.ikuhentai�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.ikuhentai-v1.4.4.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.ikuhentai.png"1.4(21.4.48B0������ہi	Ikuhentaies"https://ikuhentai.net
�
InfraFandub,eu.kanade.tachiyomi.extension.es.infrafandub�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.infrafandub-v1.4.53.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.infrafandub.png"1.4(521.4.53B4�����ߖ�MInfraFandubes"https://infrafandub.com
�
InManga(eu.kanade.tachiyomi.extension.es.inmanga�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.inmanga-v1.4.4.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.inmanga.png"1.4(21.4.4B,�Ό����`InMangaes"https://inmanga.com
�
Inmortal Scan-eu.kanade.tachiyomi.extension.es.inmortalscan�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.inmortalscan-v1.4.53.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.inmortalscan.png"1.4(521.4.53B7���Ѳ��{Inmortal Scanes"https://scanimnortal.com
�
InsanosScan,eu.kanade.tachiyomi.extension.es.insanosscan�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.insanosscan-v1.4.31.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.insanosscan.png"1.4(21.4.31B7��������IInsanosScanes"https://insanoslibrary.com
�
Inventario Oculto1eu.kanade.tachiyomi.extension.es.inventariooculto�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.inventariooculto-v1.4.50.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.inventariooculto.png"1.4(221.4.50B?���թ�ӺInventario Ocultoes"https://inventariooculto.com
�

Jeaz Scans*eu.kanade.tachiyomi.extension.es.jeazscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.jeazscans-v1.4.67.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.jeazscans.png"1.4(C21.4.67B5������źp
Jeaz Scanses"https://lectorhub.j5z.xyz
�
JoshScan)eu.kanade.tachiyomi.extension.es.joshscan�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.joshscan-v1.4.5.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.joshscan.png"1.4(21.4.5B@������]JoshScanes"&https://capibaratraductor.com/joshscan
�
KaiserZ Scanlation2eu.kanade.tachiyomi.extension.es.kaiserzscanlation�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.kaiserzscanlation-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.kaiserzscanlation.png"1.4(21.4.5BJ����KaiserZ Scanlationes"&https://capibaratraductor.com/kaizscan
�
Kaizen Translations3eu.kanade.tachiyomi.extension.es.kaizentranslations�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.kaizentranslations-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.kaizentranslations.png"1.4(21.4.58BI������JKaizen Translationses"$https://capibaratraductor.com/kaizen
�
KatsudonManga.eu.kanade.tachiyomi.extension.es.katsudonmanga�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.katsudonmanga-v1.4.5.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.katsudonmanga.png"1.4(21.4.58BJ�ÿ����KatsudonMangaes"+https://capibaratraductor.com/katsudonmanga
�
Kawaragi No Fansub1eu.kanade.tachiyomi.extension.es.kawaraginofansub�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.kawaraginofansub-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.kawaraginofansub.png"1.4(21.4.5BR������Ζ$Kawaragi No Fansubes".https://capibaratraductor.com/kawaraginofansub
�

Kazoku Den*eu.kanade.tachiyomi.extension.es.kazokuden�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.kazokuden-v1.4.50.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.kazokuden.png"1.4(221.4.50B5�ʹ����
Kazoku Denes"https://www.kazokuden.com
�
Kingdom Dark Scan0eu.kanade.tachiyomi.extension.es.kingdomdarkscan�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.kingdomdarkscan-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.kingdomdarkscan.png"1.4(21.4.5BP���̇ീWKingdom Dark Scanes"-https://capibaratraductor.com/kingdomdarkscan
�
Kirishima Fansub0eu.kanade.tachiyomi.extension.es.kirishimafansub�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.kirishimafansub-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.kirishimafansub.png"1.4(21.4.5BO���խǓ�SKirishima Fansubes"-https://capibaratraductor.com/kirishimafansub
�
Knight No Scanlation3eu.kanade.tachiyomi.extension.es.knightnoscanlation�
vhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.knightnoscanlation-v1.4.58.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.knightnoscanlation.png"1.4(:21.4.588B>��������YKnight No Scanlationes"https://lectorknight.com
�
Koinobori Scan.eu.kanade.tachiyomi.extension.es.koinoboriscan�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.koinoboriscan-v1.4.40.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.koinoboriscan.png"1.4((21.4.408B4��������QKoinobori Scanes"https://visorkoi.com
�

Koronesuki+eu.kanade.tachiyomi.extension.es.koronesuki�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.koronesuki-v1.4.5.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.koronesuki.png"1.4(21.4.58BD���媝�
Koronesukies"(https://capibaratraductor.com/koronesuki
�
	KRazytoon*eu.kanade.tachiyomi.extension.es.krazytoon�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.krazytoon-v1.4.5.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.krazytoon.png"1.4(21.4.58BB������+	KRazytoones"'https://capibaratraductor.com/krazytoon
�
Kurenai Project/eu.kanade.tachiyomi.extension.es.kurenaiproject�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.kurenaiproject-v1.4.5.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.kurenaiproject.png"1.4(21.4.5BMق���ǖ�`Kurenai Projectes",https://capibaratraductor.com/kurenaiproject
�
KuroTranslations1eu.kanade.tachiyomi.extension.es.kurotranslations�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.kurotranslations-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.kurotranslations.png"1.4(21.4.58BP���ަ���pKuroTranslationses".https://capibaratraductor.com/kurotranslations
�
La Biblioteca de Odin3eu.kanade.tachiyomi.extension.es.labibliotecadeodin�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.labibliotecadeodin-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.labibliotecadeodin.png"1.4(21.4.58BWݔ������YLa Biblioteca de Odines"0https://capibaratraductor.com/labibliotecadeodin
�
Las Profanadas Scan2eu.kanade.tachiyomi.extension.es.lasprofanadasscan�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.lasprofanadasscan-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.lasprofanadasscan.png"1.4(21.4.58BQѡ�ϳ���Las Profanadas Scanes",https://capibaratraductor.com/profanadasscan
�
Last Exile Scan.eu.kanade.tachiyomi.extension.es.lastexilescan�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.lastexilescan-v1.4.5.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.lastexilescan.png"1.4(21.4.5BL�Ժ�����eLast Exile Scanes"+https://capibaratraductor.com/lastexilescan
�
La Zona del Lirio/eu.kanade.tachiyomi.extension.es.lazonadellirio�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.lazonadellirio-v1.4.30.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.lazonadellirio.png"1.4(21.4.30B=ఉ��Ě�ELa Zona del Lirioes"https://lazonadellirio.com
�
Lector Asteria.eu.kanade.tachiyomi.extension.es.lectorasteria�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.lectorasteria-v1.4.3.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.lectorasteria.png"1.4(21.4.38B9ױ�廀��	Lector Asteriaes"https://lectorasteria.com
�
	LectorJPG*eu.kanade.tachiyomi.extension.es.lectorjpg�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.lectorjpg-v1.4.50.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.lectorjpg.png"1.4(221.4.508B/����Ľ��=	LectorJPGes"https://visorjpg.lat
�
LectorManga.lat/eu.kanade.tachiyomi.extension.es.lectormangalat�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.lectormangalat-v1.4.54.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.lectormangalat.png"1.4(621.4.548B:߱�మȯ3LectorManga.lates"https://lectormangass.com
�
MangoLibreria.eu.kanade.tachiyomi.extension.es.lectormonline�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.lectormonline-v1.4.2.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.lectormonline.png"1.4(21.4.28B8�ћ碚��:MangoLibreriaes"https://mangolibreria.com
�
TuMangaOnline*eu.kanade.tachiyomi.extension.es.lectortmo�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.lectortmo-v1.4.9.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.lectortmo.png"1.4(	21.4.98B2���թñ�9TuMangaOnlinees"https://zonatmo.com
�
LeerCapitulo-eu.kanade.tachiyomi.extension.es.leercapitulo�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.leercapitulo-v1.4.17.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.leercapitulo.png"1.4(21.4.17B9�ǧ�����NLeerCapituloes"https://www.leercapitulo.co
�
Leer Comics Online1eu.kanade.tachiyomi.extension.es.leercomicsonline�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.leercomicsonline-v1.4.1.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.leercomicsonline.png"1.4(21.4.1B@������}Leer Comics Onlinees"https://leercomicsonline.com
�
	LeerManga*eu.kanade.tachiyomi.extension.es.leermanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.leermanga-v1.4.51.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.leermanga.png"1.4(321.4.518B0±������.	LeerMangaes"https://leermanga.net
�
LeerMangaEsp-eu.kanade.tachiyomi.extension.es.leermangaesp�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.leermangaesp-v1.4.1.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.leermangaesp.png"1.4(21.4.18B6�׿��ّ�qLeerMangaEspes"https://leermangaesp.net
�
Limbo Scanlation0eu.kanade.tachiyomi.extension.es.limboscanlation�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.limboscanlation-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.limboscanlation.png"1.4(21.4.5BE�����ꭣcLimbo Scanlationes"#https://capibaratraductor.com/limbo
�
Lmtos+eu.kanade.tachiyomi.extension.es.lmtoonline�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.lmtoonline-v1.4.54.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.lmtoonline.png"1.4(621.4.548B(�����匨kLmtoses"https://lmtos.net
�
Loliet Azura Translations,eu.kanade.tachiyomi.extension.es.lolietazura�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.lolietazura-v1.4.5.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.lolietazura.png"1.4(21.4.58BT��獨��/Loliet Azura Translationses")https://capibaratraductor.com/lolietazura
�
	Lolivault*eu.kanade.tachiyomi.extension.es.lolivault�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.lolivault-v1.4.5.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.lolivault.png"1.4(21.4.58B7�˒���	Lolivaultes"https://lector.lolivault.net
�
Luna Pieces+eu.kanade.tachiyomi.extension.es.lunapieces�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.lunapieces-v1.4.32.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.lunapieces.png"1.4( 21.4.328B9������	Luna Pieceses"https://lunapiecesfansub.com
�

Manga Crab*eu.kanade.tachiyomi.extension.es.mangacrab�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.mangacrab-v1.4.73.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.mangacrab.png"1.4(I21.4.73B1�̙Û��U
Manga Crabes"https://mangacrab.org
�
MangaEsp)eu.kanade.tachiyomi.extension.es.mangaesp�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.mangaesp-v1.4.33.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.mangaesp.png"1.4(!21.4.33B9Ĉ�����MangaEspes"https://mangaesp.topmanhuas.org
�
MangaLector,eu.kanade.tachiyomi.extension.es.mangalector�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.mangalector-v1.4.50.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.mangalector.png"1.4(221.4.508B4�����˗�>MangaLectores"https://mangalector.com
�
MangaOni(eu.kanade.tachiyomi.extension.es.mangamx�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.mangamx-v1.4.19.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.mangamx.png"1.4(21.4.198B/��͊����MangaOnies"https://manga-oni.com
�
Manga Romance-eu.kanade.tachiyomi.extension.es.mangaromance�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.mangaromance-v1.4.50.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.mangaromance.png"1.4(221.4.508B9���ң���5Manga Romancees"https://mangaromance19.com
�
Manga Mukai,eu.kanade.tachiyomi.extension.es.mangashiina�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.mangashiina-v1.4.33.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.mangashiina.png"1.4(!21.4.338B3��������	Manga Mukaies"https://mangamukai.com
�
	Mangas.in)eu.kanade.tachiyomi.extension.es.mangasin�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.mangasin-v1.4.21.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.mangasin.png"1.4(21.4.218B*ɰ�ӳ��.	Mangas.ines"https://m440.in
�
Mangas No Sekai.eu.kanade.tachiyomi.extension.es.mangasnosekai�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.mangasnosekai-v1.4.69.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.mangasnosekai.png"1.4(E21.4.69B:�Ր�����Mangas No Sekaies"https://mangasnosekai.com
�
Manga TV(eu.kanade.tachiyomi.extension.es.mangatv�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.mangatv-v1.4.35.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.mangatv.png"1.4(#21.4.358B.ܥ����ڎd	Manga  TVes"https://mangatv.net
�
SamuraiScan-eu.kanade.tachiyomi.extension.es.manhuaonline�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.manhuaonline-v1.4.67.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.manhuaonline.png"1.4(C21.4.67B4��������OSamuraiScanes"https://samurai.j5z.xyz
�
Manhwa-Latino-eu.kanade.tachiyomi.extension.es.manhwalatino�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.manhwalatino-v1.4.61.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.manhwalatino.png"1.4(=21.4.618B8Ӭ����ʟ1Manhwa-Latinoes"https://manhwa-latino.com
�
ManhwaOnline-eu.kanade.tachiyomi.extension.es.manhwaonline�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.manhwaonline-v1.4.51.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.manhwaonline.png"1.4(321.4.518B7���繊��KManhwaOnlinees"https://manhwa-online.com
�
	ManhwaWeb*eu.kanade.tachiyomi.extension.es.manhwaweb�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.manhwaweb-v1.4.12.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.manhwaweb.png"1.4(21.4.128B0��������R	ManhwaWebes"https://manhwaweb.com
�
Manhwa Scan,eu.kanade.tachiyomi.extension.es.mantrazscan�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.mantrazscan-v1.4.56.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.mantrazscan.png"1.4(821.4.568B4žʋ����cManhwa Scanes"https://manhwascanx.lat
�
Marmota(eu.kanade.tachiyomi.extension.es.marmota�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.marmota-v1.4.50.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.marmota.png"1.4(221.4.50B+̆����RMarmotaes"https://marmota.me
�
Menudo-Fansub-eu.kanade.tachiyomi.extension.es.menudofansub�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.menudofansub-v1.4.6.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.menudofansub.png"1.4(21.4.6B<����ƪ��0Menudo-Fansubes"https://www.menudo-fansub.com
�
MHScans(eu.kanade.tachiyomi.extension.es.mhscans�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.mhscans-v1.4.64.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.mhscans.png"1.4(@21.4.64B,񬬮�냓-MHScanses"https://mhscans.com
�

Michu Scan*eu.kanade.tachiyomi.extension.es.michuscan�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.michuscan-v1.4.5.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.michuscan.png"1.4(21.4.58BC��������r
Michu Scanes"'https://capibaratraductor.com/michuscan
�
Monopoly Scan-eu.kanade.tachiyomi.extension.es.monopolyscan�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.monopolyscan-v1.4.50.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.monopolyscan.png"1.4(221.4.50B9�������QMonopoly Scanes"https://monopolymanhua.com
�
Mundo Manhwa,eu.kanade.tachiyomi.extension.es.mundomanhwa�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.mundomanhwa-v1.4.50.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.mundomanhwa.png"1.4(221.4.508B5��֯����bMundo Manhwaes"https://mundomanhwa.com
�
Traducciones Amistosas'eu.kanade.tachiyomi.extension.es.nartag�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.nartag-v1.4.56.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.nartag.png"1.4(821.4.568B:��������Traducciones Amistosases"https://nartag.com
�
	NekoScans*eu.kanade.tachiyomi.extension.es.nekoscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.nekoscans-v1.4.40.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.nekoscans.png"1.4((21.4.408B2�������t	NekoScanses"https://nekoproject.org
�
NeoManga)eu.kanade.tachiyomi.extension.es.neomanga�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.neomanga-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.neomanga.png"1.4(21.4.1B5��������DNeoMangaes"https://www.neomanga.online
�
NeroTranslations1eu.kanade.tachiyomi.extension.es.nerotranslations�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.nerotranslations-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.nerotranslations.png"1.4(21.4.5BM�׼�����CNeroTranslationses"+https://capibaratraductor.com/nerotranslate
�
NexusScanlation0eu.kanade.tachiyomi.extension.es.nexusscanlation�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.nexusscanlation-v1.4.4.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.nexusscanlation.png"1.4(21.4.48B<�Ղ�����8NexusScanlationes"https://nexusscanlation.com
�
Noblesse Translations5eu.kanade.tachiyomi.extension.es.noblessetranslations�
xhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.noblessetranslations-v1.4.57.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.noblessetranslations.png"1.4(921.4.57BD���ۘ��GNoblesse Translationses"https://nobledicion.yoveo.xyz
�
Nova Manhwas+eu.kanade.tachiyomi.extension.es.novamanhwa�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.novamanhwa-v1.4.32.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.novamanhwa.png"1.4( 21.4.32B3���פ��%Nova Manhwases"https://novamanhwa.cc
�
Novato Scans,eu.kanade.tachiyomi.extension.es.novatoscans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.novatoscans-v1.4.14.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.novatoscans.png"1.4(21.4.14B9����˿�Novato Scanses"https://www.novatoscans.top
�

Okami.Scan*eu.kanade.tachiyomi.extension.es.okamiscan�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.okamiscan-v1.4.5.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.okamiscan.png"1.4(21.4.5B?����ҫ��L
Okami.Scanes"#https://capibaratraductor.com/okami
�
Olympus Scanlation2eu.kanade.tachiyomi.extension.es.olympusscanlation�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.olympusscanlation-v1.4.19.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.olympusscanlation.png"1.4(21.4.19B:��긜��Olympus Scanlationes"https://olympusxyz.com
�
Omega Scanlation0eu.kanade.tachiyomi.extension.es.omegascanlation�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.omegascanlation-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.omegascanlation.png"1.4(21.4.58BO�������rOmega Scanlationes"-https://capibaratraductor.com/omegascanlation
�

ONF MANGAS*eu.kanade.tachiyomi.extension.es.onfmangas�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.onfmangas-v1.4.5.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.onfmangas.png"1.4(21.4.58B1ȏ�ˠ���
ONF MANGASes"https://onfmangas.com
�
OrckuMangas,eu.kanade.tachiyomi.extension.es.orckumangas�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.orckumangas-v1.4.2.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.orckumangas.png"1.4(21.4.28B5��Ҫ��ϾOrcku Mangases"https://orckumangas.com
�
Phantom No Fansub0eu.kanade.tachiyomi.extension.es.phantomnofansub�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.phantomnofansub-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.phantomnofansub.png"1.4(21.4.5BP������ۜ8Phantom No Fansubes"-https://capibaratraductor.com/phantomnofansub
�
PinkGarden Translation6eu.kanade.tachiyomi.extension.es.pinkgardentranslation�
xhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.pinkgardentranslation-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.pinkgardentranslation.png"1.4(21.4.5B[��񃀛̫$PinkGarden Translationes"3https://capibaratraductor.com/pinkgardentranslation
�
Platinum Lily Scan1eu.kanade.tachiyomi.extension.es.platinumlilyscan�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.platinumlilyscan-v1.4.1.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.platinumlilyscan.png"1.4(21.4.18B@��������RPlatinum Lily Scanes"https://platinumlilyscan.com
�
Plot Twist No Fansub2eu.kanade.tachiyomi.extension.es.plottwistnofansub�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.plottwistnofansub-v1.4.14.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.plottwistnofansub.png"1.4(21.4.148B>�Ȼ�����`Plot Twist No Fansubes"https://plotnofansub.com
�
	PuchiScan*eu.kanade.tachiyomi.extension.es.puchiscan�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.puchiscan-v1.4.5.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.puchiscan.png"1.4(21.4.5B>�������	PuchiScanes"#https://capibaratraductor.com/puchi
�
Ragnarok Scanlation3eu.kanade.tachiyomi.extension.es.ragnarokscanlation�
vhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.ragnarokscanlation-v1.4.53.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.ragnarokscanlation.png"1.4(521.4.53BC�э�����Ragnarok Scanlationes"https://ragnarokscanlation.org
�
Ragna Scans+eu.kanade.tachiyomi.extension.es.ragnascans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.ragnascans-v1.4.2.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.ragnascans.png"1.4(21.4.2B9���ک���SRagna Scanses"https://lector.ragnascan.xyz
�

Raiki Scan*eu.kanade.tachiyomi.extension.es.raikiscan�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.raikiscan-v1.4.32.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.raikiscan.png"1.4( 21.4.32B1�������m
Raiki Scanes"https://raikiscan.com
�
Rakuen Translations3eu.kanade.tachiyomi.extension.es.rakuentranslations�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.rakuentranslations-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.rakuentranslations.png"1.4(21.4.5BI��ۜ���iRakuen Translationses"$https://capibaratraductor.com/rakuen
�

RavenManga+eu.kanade.tachiyomi.extension.es.ravenmanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.ravenmanga-v1.4.7.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.ravenmanga.png"1.4(21.4.7B1�������	
RavenMangaes"https://raventard.xyz
�

RichtoScan+eu.kanade.tachiyomi.extension.es.richtoscan�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.richtoscan-v1.4.55.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.richtoscan.png"1.4(721.4.55B3��ߨ��ף
RichtoScanes"https://r1.richtoon.top
�

SACACHISPA+eu.kanade.tachiyomi.extension.es.sacachispa�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.sacachispa-v1.4.5.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.sacachispa.png"1.4(21.4.58BD�Ͱ��ܹ�B
SACACHISPAes"(https://capibaratraductor.com/sacachispa
�
Saitou Translations3eu.kanade.tachiyomi.extension.es.saitoutranslations�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.saitoutranslations-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.saitoutranslations.png"1.4(21.4.5BU����Ù�!Saitou Translationses"0https://capibaratraductor.com/saitoutranslations
�
SapphireScan-eu.kanade.tachiyomi.extension.es.sapphirescan�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.sapphirescan-v1.4.53.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.sapphirescan.png"1.4(521.4.53B:����|SapphireScanes"https://www.sapphirescan.com
�
Scan Review+eu.kanade.tachiyomi.extension.es.scanreview�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.scanreview-v1.4.5.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.scanreview.png"1.4(21.4.58BE��ʁ����EScan Reviewes"(https://capibaratraductor.com/scanreview
�
ScansHub)eu.kanade.tachiyomi.extension.es.scanshub�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.scanshub-v1.4.5.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.scanshub.png"1.4(21.4.58B@��������EScansHubes"&https://capibaratraductor.com/scanshub
�
Scan Starts+eu.kanade.tachiyomi.extension.es.scanstarts�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.scanstarts-v1.4.5.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.scanstarts.png"1.4(21.4.58BE�ၐ���EScan Startses"(https://capibaratraductor.com/scanstarts
�
ScanZ&eu.kanade.tachiyomi.extension.es.scanz�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.scanz-v1.4.5.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.scanz.png"1.4(21.4.5B:ԏ�����.ScanZes"#https://capibaratraductor.com/scanz
�
Secta BL Scan,eu.kanade.tachiyomi.extension.es.sectablscan�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.sectablscan-v1.4.5.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.sectablscan.png"1.4(21.4.58BH��Ӳ����RSecta BL Scanes")https://capibaratraductor.com/sectablscan
�

Seinen Den*eu.kanade.tachiyomi.extension.es.seinenden�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.seinenden-v1.4.5.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.seinenden.png"1.4(21.4.5BD宥ݒ���"
Seinen Denes"(https://capibaratraductor.com/seinen-den
�
Señor Chofli,eu.kanade.tachiyomi.extension.es.senorchofli�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.senorchofli-v1.4.5.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.senorchofli.png"1.4(21.4.58BF��������ESeñor Choflies"'https://capibaratraductor.com/sirchofli
�
Senshi Manga,eu.kanade.tachiyomi.extension.es.senshimanga�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.senshimanga-v1.4.11.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.senshimanga.png"1.4(21.4.11BG��Ӫ���PSenshi Mangaes")https://capibaratraductor.com/senshimanga
�
Shadow Manga,eu.kanade.tachiyomi.extension.es.shadowmanga�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.shadowmanga-v1.4.3.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.shadowmanga.png"1.4(21.4.38B4����΋��NShadow Mangaes"https://shademanga.com
�
Shadow Mangas-eu.kanade.tachiyomi.extension.es.shadowmangas�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.shadowmangas-v1.4.31.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.shadowmangas.png"1.4(21.4.318B7����ՈԷ$Shadow Mangases"https://shadowmangas.com
�
ShoShinSha Scans0eu.kanade.tachiyomi.extension.es.shoshinshascans�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.shoshinshascans-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.shoshinshascans.png"1.4(21.4.5BO�Ԙ���ʚLShoShinSha Scanses"-https://capibaratraductor.com/shoshinshascans
�

6ianfranc9-eu.kanade.tachiyomi.extension.es.sixianfranc9�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.sixianfranc9-v1.4.5.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.sixianfranc9.png"1.4(21.4.5BD�ū�����
6ianfranc9es"(https://capibaratraductor.com/6ianfranc9
�
	SkyMangas*eu.kanade.tachiyomi.extension.es.skymangas�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.skymangas-v1.4.33.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.skymangas.png"1.4(!21.4.33B0���䅿��x	SkyMangases"https://skymangas.com
�
Soul Craft Fansub0eu.kanade.tachiyomi.extension.es.soulcraftfansub�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.soulcraftfansub-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.soulcraftfansub.png"1.4(21.4.5BJ����Ő�Soul Craft Fansubes"'https://capibaratraductor.com/soulcraft
�
Space Fansub,eu.kanade.tachiyomi.extension.es.spacefansub�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.spacefansub-v1.4.5.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.spacefansub.png"1.4(21.4.5BG�ގ�����ZSpace Fansubes")https://capibaratraductor.com/spacefansub
�

Spicy Scan*eu.kanade.tachiyomi.extension.es.spicyscan�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.spicyscan-v1.4.3.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.spicyscan.png"1.4(21.4.38B3��������$
Spicy Scanes"https://spicyseries.com
�
Stick Horse+eu.kanade.tachiyomi.extension.es.stickhorse�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.stickhorse-v1.4.50.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.stickhorse.png"1.4(221.4.508B2��܃����rStick Horsees"https://stickhorse.cl
�
StrayDog608,eu.kanade.tachiyomi.extension.es.straydog608�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.straydog608-v1.4.5.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.straydog608.png"1.4(21.4.58BF��ܵ˵��@StrayDog608es")https://capibaratraductor.com/straydog608
�
	Submanhwa*eu.kanade.tachiyomi.extension.es.submanhwa�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.submanhwa-v1.4.8.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.submanhwa.png"1.4(21.4.88B0�͋��˛�	Submanhwaes"https://submanhwa.com
�
Sweet Ice Cream.eu.kanade.tachiyomi.extension.es.sweeticecream�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.sweeticecream-v1.4.5.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.sweeticecream.png"1.4(21.4.58BL礫Ş��	Sweet Ice Creames"+https://capibaratraductor.com/sweeticecream
�
Sword Of Oblivion0eu.kanade.tachiyomi.extension.es.swordofoblivion�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.swordofoblivion-v1.4.50.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.swordofoblivion.png"1.4(221.4.50B>��������TSword Of Obliviones"https://swordofoblivion.com
�
Taurus Fansub-eu.kanade.tachiyomi.extension.es.taurusfansub�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.taurusfansub-v1.4.59.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.taurusfansub.png"1.4(;21.4.59B7���ؒ���GTaurus Fansubes"https://lectortaurus.com
�
TecnoProjects.eu.kanade.tachiyomi.extension.es.tecnoprojects�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.tecnoprojects-v1.4.43.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.tecnoprojects.png"1.4(+21.4.43B8۰����TecnoProjectses"https://tecnoprojects.xyz
�
Temple Scan.eu.kanade.tachiyomi.extension.es.templescanesp�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.templescanesp-v1.4.61.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.templescanesp.png"1.4(=21.4.618B8��̻���/Temple Scanes"https://aedexnox.akan01.com
�
Templo de Jeny-eu.kanade.tachiyomi.extension.es.templodejeny�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.templodejeny-v1.4.5.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.templodejeny.png"1.4(21.4.58BJ��������
Templo de Jenyes"*https://capibaratraductor.com/templodejeny
�
Templo de Scarlet0eu.kanade.tachiyomi.extension.es.templodescarlet�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.templodescarlet-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.templodescarlet.png"1.4(21.4.58BP��������zTemplo de Scarletes"-https://capibaratraductor.com/templodescarlet
�

Falco Scan+eu.kanade.tachiyomi.extension.es.tenkaiscan�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.tenkaiscan-v1.4.39.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.tenkaiscan.png"1.4('21.4.398B1��������S
Falco Scanes"https://falcoscan.net
�
Terra Scans+eu.kanade.tachiyomi.extension.es.terrascans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.terrascans-v1.4.5.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.terrascans.png"1.4(21.4.5BE�Ҥ��޶�(Terra Scanses"(https://capibaratraductor.com/terrascans
�
Territorio Lealtad2eu.kanade.tachiyomi.extension.es.territoriolealtad�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.territoriolealtad-v1.4.45.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.territoriolealtad.png"1.4(-21.4.458B>��������kTerritorio Lealtades"https://territorioleal.com
�

TheBlueBox+eu.kanade.tachiyomi.extension.es.thebluebox�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.thebluebox-v1.4.5.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.thebluebox.png"1.4(21.4.58BD˅������z
TheBlueBoxes"(https://capibaratraductor.com/thebluebox
�
The grimorio de la witch5eu.kanade.tachiyomi.extension.es.thegrimoriodelawitch�
whttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.thegrimoriodelawitch-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.thegrimoriodelawitch.png"1.4(21.4.58BM�������-The grimorio de la witches"#https://capibaratraductor.com/tgdlw
�
TMAT%eu.kanade.tachiyomi.extension.es.tmat�
ghttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.tmat-v1.4.5.apkuhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.tmat.png"1.4(21.4.5B8�����Ӆ�aTMATes""https://capibaratraductor.com/tamt
�
	TMOHentai*eu.kanade.tachiyomi.extension.es.tmohentai�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.tmohentai-v1.4.10.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.tmohentai.png"1.4(
21.4.108B0����뷰t	TMOHentaies"https://tmohentai.com
�
	TMO Manga)eu.kanade.tachiyomi.extension.es.tmomanga�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.tmomanga-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.tmomanga.png"1.4(21.4.18B/�������	TMO Mangaes"https://tmomanga.com
�

Tojimangas+eu.kanade.tachiyomi.extension.es.tojimangas�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.tojimangas-v1.4.5.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.tojimangas.png"1.4(21.4.58B0㉰�忇�`
Tojimangases"https://manhwass.com
�
Toon-es'eu.kanade.tachiyomi.extension.es.toones�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.toones-v1.4.50.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.toones.png"1.4(221.4.508B,�����EToon-eses"https://toon-es.com
�
TopComicPorno.eu.kanade.tachiyomi.extension.es.topcomicporno�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.topcomicporno-v1.4.50.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.topcomicporno.png"1.4(221.4.508B8��؄��Ț]TopComicPornoes"https://topcomicporno.com
�
TopComicPorno.net1eu.kanade.tachiyomi.extension.es.topcomicpornonet�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.topcomicpornonet-v1.4.50.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.topcomicpornonet.png"1.4(221.4.508B<��������^TopComicPorno.netes"https://topcomicporno.net
�
Traducciones Moonlight6eu.kanade.tachiyomi.extension.es.traduccionesmoonlight�
yhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.traduccionesmoonlight-v1.4.47.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.traduccionesmoonlight.png"1.4(/21.4.478BI��ڡ݆��<Traducciones Moonlightes"!https://traduccionesmoonlight.com
�
Traducciones Muy Lentas6eu.kanade.tachiyomi.extension.es.traduccionesmuylentas�
xhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.traduccionesmuylentas-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.traduccionesmuylentas.png"1.4(21.4.5BO��������Traducciones Muy Lentases"&https://capibaratraductor.com/tmlentas
�
Traducciones PaltaNobu6eu.kanade.tachiyomi.extension.es.traduccionespaltanobu�
xhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.traduccionespaltanobu-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.traduccionespaltanobu.png"1.4(21.4.5BO��������+Traducciones PaltaNobues"'https://capibaratraductor.com/paltanobu
�
Tres Daos Scan-eu.kanade.tachiyomi.extension.es.tresdaosscan�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.tresdaosscan-v1.4.41.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.tresdaosscan.png"1.4()21.4.41B:������ߏTres Daos Scanes"https://threedaos.zdrz.xyz
�
Tsuki No Musume Scan2eu.kanade.tachiyomi.extension.es.tsukinomusumescan�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.tsukinomusumescan-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.tsukinomusumescan.png"1.4(21.4.58BU��������9Tsuki No Musume Scanes"/https://capibaratraductor.com/tsukinomusumescan
�
Tu Erizo Traducciones4eu.kanade.tachiyomi.extension.es.tuerizotraducciones�
vhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.tuerizotraducciones-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.tuerizotraducciones.png"1.4(21.4.5BX�������VTu Erizo Traduccioneses"1https://capibaratraductor.com/tuerizotraducciones
�
	ManhwasMe.eu.kanade.tachiyomi.extension.es.tumanhwasclub�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.tumanhwasclub-v1.4.3.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.tumanhwasclub.png"1.4(21.4.38B-������ߊo	ManhwasMees"https://manhwas.me
�
Uchuujin Projects1eu.kanade.tachiyomi.extension.es.uchuujinprojects�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.uchuujinprojects-v1.4.34.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.uchuujinprojects.png"1.4("21.4.348B=�����ѐ�6Uchuujin Projectses"https://uchuujinmangas.com
�
"Virreinato de Unknown Realm Fansub3eu.kanade.tachiyomi.extension.es.unknownrealmfansub�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.unknownrealmfansub-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.unknownrealmfansub.png"1.4(21.4.5Bf��������a"Virreinato de Unknown Realm Fansubes"2https://capibaratraductor.com/unknown-realm-fansub
�
VCPVMP'eu.kanade.tachiyomi.extension.es.vcpvmp�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.vcpvmp-v1.4.12.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.vcpvmp.png"1.4(21.4.128B/���ժ���uVCPes"https://vercomicsporno.comB/������DVMPes"https://vermangasporno.com
�
Ver Manhwas+eu.kanade.tachiyomi.extension.es.vermanhwas�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.vermanhwas-v1.4.52.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.vermanhwas.png"1.4(421.4.528B2�Ì�����9Ver Manhwases"https://vermanhwa.com
�
WaifusWithSalsa Scan4eu.kanade.tachiyomi.extension.es.waifuswithsalsascan�
vhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.waifuswithsalsascan-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.waifuswithsalsascan.png"1.4(21.4.58BG�����ߖ�WaifusWithSalsa Scanes"!https://capibaratraductor.com/wws
�
Weeping Angel-eu.kanade.tachiyomi.extension.es.weepingangel�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.weepingangel-v1.4.5.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.weepingangel.png"1.4(21.4.58BI�����ȌRWeeping Angeles"*https://capibaratraductor.com/weepingangel
�
White Pearl Translations7eu.kanade.tachiyomi.extension.es.whitepearltranslations�
yhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.whitepearltranslations-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.whitepearltranslations.png"1.4(21.4.5BR��׃ۿ��?White Pearl Translationses"(https://capibaratraductor.com/whitepearl
�
Yupmanga)eu.kanade.tachiyomi.extension.es.yupmanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.yupmanga-v1.4.14.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.yupmanga.png"1.4(21.4.148B2ĳ߇�ݐ�=Yupmangaes"https://www.yupmanga.com
�
Yuri-Online+eu.kanade.tachiyomi.extension.es.yurionline�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.yurionline-v1.4.50.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.yurionline.png"1.4(221.4.508B4��������/Yuri-Onlinees"https://yuri-online.com
�
Zevep&eu.kanade.tachiyomi.extension.es.zevep�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.zevep-v1.4.45.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.zevep.png"1.4(-21.4.458B(��������wZevepes"https://zevep.com
�
Zonatmo.to (unoriginal)*eu.kanade.tachiyomi.extension.es.zonatmoto�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-es.zonatmoto-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.zonatmoto.png"1.4(21.4.28B;��Ɖ���Zonatmo.to (unoriginal)es"https://zonatmo.to
�
	AnimeSama*eu.kanade.tachiyomi.extension.fr.animesama�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.animesama-v1.4.16.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.animesama.png"1.4(21.4.16B0�����͚�F	AnimeSamafr"https://anime-sama.to
�
AralosBD)eu.kanade.tachiyomi.extension.fr.aralosbd�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.aralosbd-v1.4.6.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.aralosbd.png"1.4(21.4.6B-��Ɩ����bAralosBDfr"https://aralosbd.fr
�
Astral-Manga,eu.kanade.tachiyomi.extension.fr.astralmanga�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.astralmanga-v1.4.48.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.astralmanga.png"1.4(021.4.48B4����ɚߪzAstralMangafr"https://astral-manga.fr
�
Harmony-Scan+eu.kanade.tachiyomi.extension.fr.bananascan�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.bananascan-v1.4.51.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.bananascan.png"1.4(321.4.518B5�ƻ�ӓ��+Harmony-Scanfr"https://harmony-scan.fr
�
BigSolo(eu.kanade.tachiyomi.extension.fr.bigsolo�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.bigsolo-v1.4.5.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.bigsolo.png"1.4(21.4.5B,����֚=BigSolofr"https://bigsolo.org
�
	Blue Solo)eu.kanade.tachiyomi.extension.fr.bluesolo�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.bluesolo-v1.4.4.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.bluesolo.png"1.4(21.4.4B/�筜�ݓ�	Blue Solofr"https://bluesolo.org
�
	ChaosTrad*eu.kanade.tachiyomi.extension.fr.chaostrad�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.chaostrad-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.chaostrad.png"1.4(21.4.1B/̤寕���d	ChaosTradfr"https://chaostrad.fr
�
Dassou Scan+eu.kanade.tachiyomi.extension.fr.dassouscan�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.dassouscan-v1.4.50.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.dassouscan.png"1.4(221.4.50B3��������:Dassou Scanfr"https://dassouscan.com
�
Epsilon Scan,eu.kanade.tachiyomi.extension.fr.epsilonscan�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.epsilonscan-v1.4.54.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.epsilonscan.png"1.4(621.4.548B4��������#Epsilon Scanfr"https://epsilonscan.to
�
Legacy Scans-eu.kanade.tachiyomi.extension.fr.flamescansfr�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.flamescansfr-v1.4.31.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.flamescansfr.png"1.4(21.4.31B6�ш���ZLegacy Scansfr"https://legacy-scans.com
�
FMTEAM'eu.kanade.tachiyomi.extension.fr.fmteam�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.fmteam-v1.4.7.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.fmteam.png"1.4(21.4.7B)��֫�ߥ�jFMTEAMfr"https://fmteam.fr
�
FR Manga(eu.kanade.tachiyomi.extension.fr.frmanga�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.frmanga-v1.4.7.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.frmanga.png"1.4(21.4.7B1������VFR Mangafr"https://www.frmanga.com
�

FuryoSquad+eu.kanade.tachiyomi.extension.fr.furyosquad�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.furyosquad-v1.4.5.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.furyosquad.png"1.4(21.4.5B8��ׄ����
FuryoSquadfr"https://www.furyosociety.com
�
Hentai Origines/eu.kanade.tachiyomi.extension.fr.hentaiorigines�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.hentaiorigines-v1.4.50.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.hentaiorigines.png"1.4(221.4.508B;������5Hentai Originesfr"https://hentai-origines.fr
�
Hentai Scan Reader1eu.kanade.tachiyomi.extension.fr.hentaiscanreader�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.hentaiscanreader-v1.4.1.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.hentaiscanreader.png"1.4(21.4.18BA�ΰ�ޟtHentai Scan Readerfr"https://hentai.scanreader.net
�
Hentai-Scantrad/eu.kanade.tachiyomi.extension.fr.hentaiscantrad�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.hentaiscantrad-v1.4.51.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.hentaiscantrad.png"1.4(321.4.518B>�����̹�]Hentai-Scantradfr"https://hentai.scantrad-vf.cc
�

HentaiZone+eu.kanade.tachiyomi.extension.fr.hentaizone�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.hentaizone-v1.4.51.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.hentaizone.png"1.4(321.4.518B2�򁛰���C
HentaiZonefr"https://hentaizone.xyz
�
HistoireDHentai0eu.kanade.tachiyomi.extension.fr.histoiredhentai�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.histoiredhentai-v1.4.50.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.histoiredhentai.png"1.4(221.4.508B3���螈��_HistoireDHentaifr"https://hhentai.fr
�
Japscan(eu.kanade.tachiyomi.extension.fr.japscan�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.japscan-v1.4.70.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.japscan.png"1.4(F21.4.70BAJapscanfr"0https://www.japscan.foo/mangas/?sort=popular&p=1
�
Kiwiya Scans,eu.kanade.tachiyomi.extension.fr.kiwiyascans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.kiwiyascans-v1.4.32.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.kiwiyascans.png"1.4( 21.4.32B5�����و�xKiwiya Scansfr"https://kiwiyascans.com
�
	LanorTrad*eu.kanade.tachiyomi.extension.fr.lanortrad�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.lanortrad-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.lanortrad.png"1.4(21.4.1B8��񡯅��[	LanorTradfr"https://lanortrad.netlify.app
�
Lelmanga)eu.kanade.tachiyomi.extension.fr.lelmanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.lelmanga-v1.4.33.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.lelmanga.png"1.4(!21.4.33B2���ܯ��xLelmangafr"https://www.lelmanga.com
�
Lelscan(eu.kanade.tachiyomi.extension.fr.lelscan�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.lelscan-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.lelscan.png"1.4(21.4.1B-ք���wLelscanfr"https://lelscans.net
�

Lelscan-VF*eu.kanade.tachiyomi.extension.fr.lelscanvf�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.lelscanvf-v1.4.15.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.lelscanvf.png"1.4(21.4.15B1�������C
Lelscan-VFfr"https://lelscanfr.com
�
Les Poroiniens.eu.kanade.tachiyomi.extension.fr.lesporoiniens�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.lesporoiniens-v1.4.2.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.lesporoiniens.png"1.4(21.4.28B9������lLes Poroiniensfr"https://lesporoiniens.org
�
Pornhwa Scans1eu.kanade.tachiyomi.extension.fr.lunarscanshentai�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.lunarscanshentai-v1.4.32.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.lunarscanshentai.png"1.4( 21.4.328B6������MPornhwa Scansfr"https://pornhwascans.fr
�
Manga-Corporation1eu.kanade.tachiyomi.extension.fr.mangacorporation�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.mangacorporation-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.mangacorporation.png"1.4(21.4.5B@�����˚Manga-Corporationfr"https://manga-corporation.com
�
MangaHub.fr+eu.kanade.tachiyomi.extension.fr.mangahubfr�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.mangahubfr-v1.4.52.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.mangahubfr.png"1.4(421.4.528B0�筓����-MangaHub.frfr"https://mangahub.fr
�
Mangakawaii,eu.kanade.tachiyomi.extension.fr.mangakawaii�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.mangakawaii-v1.4.38.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.mangakawaii.png"1.4(&21.4.38B7ù�Ҳ�˛Mangakawaiifr"https://www.mangakawaii.io
�

MangaMoins+eu.kanade.tachiyomi.extension.fr.mangamoins�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.mangamoins-v1.4.10.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.mangamoins.png"1.4(
21.4.10B2ן�Ձ�שZ
MangaMoinsfr"https://mangamoins.com
�
	MangaNova*eu.kanade.tachiyomi.extension.fr.manganova�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.manganova-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.manganova.png"1.4(21.4.2B5������	MangaNovafr"https://www.manga-nova.com
�
Manga-Scantrad.eu.kanade.tachiyomi.extension.fr.mangascantrad�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.mangascantrad-v1.4.53.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.mangascantrad.png"1.4(521.4.538B9��Ⴞ�׿Manga-Scantradfr"https://manga-scantrad.io
�
Mangas-Origines.fr1eu.kanade.tachiyomi.extension.fr.mangasoriginesfr�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.mangasoriginesfr-v1.4.53.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.mangasoriginesfr.png"1.4(521.4.53B>£������BMangas-Origines.frfr"https://mangas-origines.fr
�
Mangas Scans,eu.kanade.tachiyomi.extension.fr.mangasscans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.mangasscans-v1.4.33.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.mangasscans.png"1.4(!21.4.33B6��ݳ����rMangas Scansfr"https://mangas-scans.com
�
Ono$eu.kanade.tachiyomi.extension.fr.ono�
fhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.ono-v1.4.1.apkthttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.ono.png"1.4(21.4.18B)��������DOnofr"https://www.ono.live
�
Ortega Scans,eu.kanade.tachiyomi.extension.fr.ortegascans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.ortegascans-v1.4.1.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.ortegascans.png"1.4(21.4.18B4�əإ��wOrtega Scansfr"https://ortegascans.fr
�
Pantheon Scan-eu.kanade.tachiyomi.extension.fr.pantheonscan�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.pantheonscan-v1.4.51.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.pantheonscan.png"1.4(321.4.518B8��덎��Pantheon Scanfr"https://pantheon-scan.com
�
	Perf Scan)eu.kanade.tachiyomi.extension.fr.perfscan�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.perfscan-v1.4.31.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.perfscan.png"1.4(21.4.318B0�����՞�>	Perf Scanfr"https://perf-scan.xyz
�
PhenixScans,eu.kanade.tachiyomi.extension.fr.phenixscans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.phenixscans-v1.4.35.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.phenixscans.png"1.4(#21.4.35B6�Տ��ܓ�5Phenix Scansfr"https://phenix-scans.com
�

Pornhwa.fr*eu.kanade.tachiyomi.extension.fr.pornhwafr�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.pornhwafr-v1.4.32.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.pornhwafr.png"1.4( 21.4.328B.��������<
Pornwha.frfr"https://pornhwa.fr
�

Pornhwa.io*eu.kanade.tachiyomi.extension.fr.pornhwaio�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.pornhwaio-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.pornhwaio.png"1.4(21.4.18B.�����ߋ 
Pornhwa.iofr"https://pornhwa.io
�
Poseidon Scans.eu.kanade.tachiyomi.extension.fr.poseidonscans�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.poseidonscans-v1.4.51.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.poseidonscans.png"1.4(321.4.51B:��߱����|Poseidon Scansfr"https://poseidon-scans.net
�
Raijin Scans,eu.kanade.tachiyomi.extension.fr.raijinscans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.raijinscans-v1.4.65.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.raijinscans.png"1.4(A21.4.65B5��������tRaijin Scansfr"https://raijin-scans.fr
�
Reaper Scans,eu.kanade.tachiyomi.extension.fr.reaperscans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.reaperscans-v1.4.22.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.reaperscans.png"1.4(21.4.22B5��قݩoReaper Scansfr"https://reaper-scans.fr
�

Rimu Scans*eu.kanade.tachiyomi.extension.fr.rimuscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.rimuscans-v1.4.35.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.rimuscans.png"1.4(#21.4.35B/���Ħά�
Rimu Scansfr"https://rimuscan.fr
�
Royal Manga+eu.kanade.tachiyomi.extension.fr.royalmanga�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.royalmanga-v1.4.11.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.royalmanga.png"1.4(21.4.11B7��������dRoyal Mangafr"https://www.royalmanga.com
�
X-Manga/eu.kanade.tachiyomi.extension.fr.scanhentaimenu�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.scanhentaimenu-v1.4.54.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.scanhentaimenu.png"1.4(621.4.548B,�Ⱥ�����9X-Mangafr"https://x-manga.org
�

Scan-Manga*eu.kanade.tachiyomi.extension.fr.scanmanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.scanmanga-v1.4.23.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.scanmanga.png"1.4(21.4.238B4���😅�
Scan-Mangafr"https://m.scan-manga.com
�
ScanR&eu.kanade.tachiyomi.extension.fr.scanr�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.scanr-v1.4.3.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.scanr.png"1.4(21.4.38B+ޱ������OScanRfr"https://teamscanr.fr
�
Scan Reader+eu.kanade.tachiyomi.extension.fr.scanreader�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.scanreader-v1.4.1.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.scanreader.png"1.4(21.4.1B3ϙ�����YScan Readerfr"https://scanreader.net
�
ScansFR(eu.kanade.tachiyomi.extension.fr.scansfr�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.scansfr-v1.4.3.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.scansfr.png"1.4(21.4.38B,����ƾ�$ScansFRfr"https://scansfr.com
�
Scantrad Union.eu.kanade.tachiyomi.extension.fr.scantradunion�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.scantradunion-v1.4.3.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.scantradunion.png"1.4(21.4.3B:����ۧ��Scantrad Unionfr"https://scantrad-union.com
�
Scan VF'eu.kanade.tachiyomi.extension.fr.scanvf�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.scanvf-v1.4.15.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.scanvf.png"1.4(21.4.15B0����㞘�"Scan VFfr"https://www.scan-vf.net
�
Siren Scans FR-eu.kanade.tachiyomi.extension.fr.sirenscansfr�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.sirenscansfr-v1.4.20.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.sirenscansfr.png"1.4(21.4.20B5�������~Siren Scans FRfr"https://sirenscans.fr
�
Soft Epsilon Scan0eu.kanade.tachiyomi.extension.fr.softepsilonscan�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.softepsilonscan-v1.4.54.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.softepsilonscan.png"1.4(621.4.54B9���쩎��DSoft Epsilon Scanfr"https://epsilonsoft.to
�

Sushi-Scan*eu.kanade.tachiyomi.extension.fr.sushiscan�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.sushiscan-v1.4.49.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.sushiscan.png"1.4(121.4.498B1�����艷Z
Sushi-Scanfr"https://sushiscan.net
�
Sushiscan.fr,eu.kanade.tachiyomi.extension.fr.sushiscanfr�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.sushiscanfr-v1.4.35.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.sushiscanfr.png"1.4(#21.4.358B2����ަ�,Sushiscan.frfr"https://sushiscan.fr
�
Toon FR'eu.kanade.tachiyomi.extension.fr.toonfr�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.toonfr-v1.4.50.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.toonfr.png"1.4(221.4.508B+��������,Toon FRfr"https://toonfr.com
�
Twatt&eu.kanade.tachiyomi.extension.fr.twatt�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.twatt-v1.4.1.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.twatt.png"1.4(21.4.1B'���Đ���GTwattfr"https://twatt.fr
�
YaoiScan)eu.kanade.tachiyomi.extension.fr.yaoiscan�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-fr.yaoiscan-v1.4.33.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.fr.yaoiscan.png"1.4(!21.4.338B-�׵����eYaoiScanfr"https://yaoiscan.fr
�
Luvyaa'eu.kanade.tachiyomi.extension.id.Luvyaa�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.Luvyaa-v1.4.36.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.Luvyaa.png"1.4($21.4.368B,������ۡLuvyaaid"https://v4.luvyaa.co
�
Aarlas'eu.kanade.tachiyomi.extension.id.aarlas�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.aarlas-v1.4.16.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.aarlas.png"1.4(21.4.168B0ޏ���Ö�ZAarlasid"https://www.arlas.online
�
Ainz Scans ID,eu.kanade.tachiyomi.extension.id.ainzscansid�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.ainzscansid-v1.4.34.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.ainzscansid.png"1.4("21.4.34B9ܩ����^Ainz Scans IDid"https://v1.ainzscans01.com
�
Astral Scans,eu.kanade.tachiyomi.extension.id.astralscans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.astralscans-v1.4.39.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.astralscans.png"1.4('21.4.398B5���ĳ؅�Astral Scansid"https://astralscans.top
�
	BacaKomik*eu.kanade.tachiyomi.extension.id.bacakomik�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.bacakomik-v1.4.15.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.bacakomik.png"1.4(21.4.15B/�哥�ݴ�<	BacaKomikid"https://bacakomik.my
�
Bacami'eu.kanade.tachiyomi.extension.id.bacami�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.bacami-v1.4.2.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.bacami.png"1.4(21.4.2B*��������%Bacamiid"https://bacami.net
�
BirdToon)eu.kanade.tachiyomi.extension.id.birdtoon�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.birdtoon-v1.4.49.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.birdtoon.png"1.4(121.4.498B/�����փ�GBirdToonid"https://birdtoon.shop
�
	Comicazen*eu.kanade.tachiyomi.extension.id.comicazen�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.comicazen-v1.4.9.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.comicazen.png"1.4(	21.4.9B0��Ƈ�˰�K	Comicazenid"https://comicazen.com
�
CosmicScans.id.eu.kanade.tachiyomi.extension.id.cosmicscansid�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.cosmicscansid-v1.4.54.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.cosmicscansid.png"1.4(621.4.54B:�ڰ��[CosmicScans.idid"https://lc1.cosmicscans.to
�
	CrotPedia*eu.kanade.tachiyomi.extension.id.crotpedia�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.crotpedia-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.crotpedia.png"1.4(21.4.28B0���Ǫ���7	CrotPediaid"https://crotpedia.net
�
	DailySuka*eu.kanade.tachiyomi.extension.id.dailysuka�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.dailysuka-v1.4.33.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.dailysuka.png"1.4(!21.4.33B1���Ϣ���

DailySuka id"https://dailysuka.com
�

Dojing.net*eu.kanade.tachiyomi.extension.id.dojingnet�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.dojingnet-v1.4.33.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.dojingnet.png"1.4(!21.4.338B.济�ۭ��o
Dojing.netid"https://dojing.net
�

DoujinDesu+eu.kanade.tachiyomi.extension.id.doujindesu�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.doujindesu-v1.4.14.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.doujindesu.png"1.4(21.4.148B1޽�ֱ���j
Doujindesuid"https://doujindesu.tv
�
DoujinDesu (Unoriginal)5eu.kanade.tachiyomi.extension.id.doujindesuunoriginal�
whttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.doujindesuunoriginal-v1.4.1.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.doujindesuunoriginal.png"1.4(21.4.18BB����և|DoujinDesu (Unoriginal)id"https://v2.doujindesu.fun
�
Doujinku)eu.kanade.tachiyomi.extension.id.doujinku�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.doujinku-v1.4.35.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.doujinku.png"1.4(#21.4.358B.��ͯ�ͻ�ADoujinkuid"https://doujinku.org
�
DreamTeams Scans0eu.kanade.tachiyomi.extension.id.dreamteamsscans�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.dreamteamsscans-v1.4.33.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.dreamteamsscans.png"1.4(!21.4.338B:��������>DreamTeams Scansid"https://dreamteams.space
�

FloraScans+eu.kanade.tachiyomi.extension.id.florascans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.florascans-v1.4.30.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.florascans.png"1.4(21.4.308B2������
FloraScansid"https://florascans.net
�
Futari'eu.kanade.tachiyomi.extension.id.futari�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.futari-v1.4.30.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.futari.png"1.4(21.4.30B+��آ��Futariid"https://futari.info
�
Hentai Crot+eu.kanade.tachiyomi.extension.id.hentaicrot�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.hentaicrot-v1.4.1.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.hentaicrot.png"1.4(21.4.18B3���޼���Hentai Crotid"https://hentaicrot.com
�
Holotoon)eu.kanade.tachiyomi.extension.id.holotoon�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.holotoon-v1.4.50.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.holotoon.png"1.4(221.4.508B2����ఫ�7Holotoonid"https://01.holotoon.site
�
Hwago&eu.kanade.tachiyomi.extension.id.hwago�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.hwago-v1.4.54.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.hwago.png"1.4(621.4.548B+ࢉ���ӘLHwagoid"https://01.hwago.xyz
�
ReYume+eu.kanade.tachiyomi.extension.id.inazumanga�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.inazumanga-v1.4.41.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.inazumanga.png"1.4()21.4.41B1�©�̳�ReYumeid"https://www.re-yume.my.id
�
Izanami Scans-eu.kanade.tachiyomi.extension.id.izanamiscans�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.izanamiscans-v1.4.33.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.izanamiscans.png"1.4(!21.4.33B9���Ŕ�Izanami Scansid"https://izanamiscans.my.id
�
Kanzenin)eu.kanade.tachiyomi.extension.id.kanzenin�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.kanzenin-v1.4.33.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.kanzenin.png"1.4(!21.4.338B/�ॴ����zKanzeninid"https://kanzenin.info
�
Kiryuu'eu.kanade.tachiyomi.extension.id.kiryuu�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.kiryuu-v1.4.53.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.kiryuu.png"1.4(521.4.538B,��������2Kiryuuid"https://v6.kiryuu.to
�
	KlikManga*eu.kanade.tachiyomi.extension.id.klikmanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.klikmanga-v1.4.55.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.klikmanga.png"1.4(721.4.55B0���̦��H	KlikMangaid"https://klikmanga.org
�
KLManhua)eu.kanade.tachiyomi.extension.id.klmanhua�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.klmanhua-v1.4.12.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.klmanhua.png"1.4(21.4.128B7�����҈{KLManhuaid"https://klmanhua.blogspot.com
�
APKOMIK(eu.kanade.tachiyomi.extension.id.komikav�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.komikav-v1.4.37.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.komikav.png"1.4(%21.4.37B/��涏��mAPKOMIKid"https://01.apkomik.com
�

Komik Cast*eu.kanade.tachiyomi.extension.id.komikcast�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.komikcast-v1.4.80.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.komikcast.png"1.4(P21.4.80B4����ګ�
Komik Castid"https://v2.komikcast.fit
�
Komik Dewasa,eu.kanade.tachiyomi.extension.id.komikdewasa�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.komikdewasa-v1.4.32.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.komikdewasa.png"1.4( 21.4.328B6��������yKomik Dewasakid"https://komikdewasa.mom
�
Komik Dewasa Art/eu.kanade.tachiyomi.extension.id.komikdewasaart�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.komikdewasaart-v1.4.32.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.komikdewasaart.png"1.4( 21.4.328B9�������TKomik Dewasa Artid"https://komikdewasa.art
�
KomikGO(eu.kanade.tachiyomi.extension.id.komikgo�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.komikgo-v1.4.30.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.komikgo.png"1.4(21.4.308B,�퉞ᢠ�KomikGOid"https://komikgo.xyz
�
Komikhwa)eu.kanade.tachiyomi.extension.id.komikhwa�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.komikhwa-v1.4.32.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.komikhwa.png"1.4( 21.4.32B.��ሌ��KKomikhwaid"https://komikhwa.com
�
	Komikindo*eu.kanade.tachiyomi.extension.id.komikindo�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.komikindo-v1.4.38.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.komikindo.png"1.4(&21.4.388B0��������	Komikindoid"https://komikindo.bid
�
KomikIndo.co,eu.kanade.tachiyomi.extension.id.komikindoco�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.komikindoco-v1.4.38.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.komikindoco.png"1.4(&21.4.388B2ڣ������
KomikIndo.coid"https://komiksin.net
�
KomikIndoID,eu.kanade.tachiyomi.extension.id.komikindoid�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.komikindoid-v1.4.19.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.komikindoid.png"1.4(21.4.198B1����ڊ��JKomikIndoIDid"https://komikindo.ch
�

KomikNesia+eu.kanade.tachiyomi.extension.id.komiknesia�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.komiknesia-v1.4.1.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.komiknesia.png"1.4(21.4.18B6����Ʉ��{
KomikNesiaid"https://02.komiknesia.asia
�
Komik Next G Online1eu.kanade.tachiyomi.extension.id.komiknextgonline�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.komiknextgonline-v1.4.2.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.komiknextgonline.png"1.4(21.4.2BA�߹�󱱘QKomik Next G Onlineid"https://komiknextgonline.com
�
Komik Station-eu.kanade.tachiyomi.extension.id.komikstation�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.komikstation-v1.4.39.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.komikstation.png"1.4('21.4.39B7���΍���UKomik Stationid"https://komikstation.org
�
Komiktap)eu.kanade.tachiyomi.extension.id.komiktap�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.komiktap-v1.4.36.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.komiktap.png"1.4($21.4.368B/����Ǎ��qKomiktapid"https://komiktap.info
�
Komiku'eu.kanade.tachiyomi.extension.id.komiku�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.komiku-v1.4.20.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.komiku.png"1.4(21.4.20B*����ߧ�CKomikuid"https://komiku.org
�
	Komiku.cc)eu.kanade.tachiyomi.extension.id.komikucc�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.komikucc-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.komikucc.png"1.4(21.4.1B,��ח����n	Komiku.ccid"https://komiku.cc
�

Komiku.com*eu.kanade.tachiyomi.extension.id.komikucom�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.komikucom-v1.4.34.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.komikucom.png"1.4("21.4.34B2�����ٞ�u
Komiku.comid"https://01.komiku.asia
�
	Komikzoid*eu.kanade.tachiyomi.extension.id.komikzoid�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.komikzoid-v1.4.3.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.komikzoid.png"1.4(21.4.3B/ҳ�����#	Komikzoidid"https://komikzoid.id
�
KumaPoi(eu.kanade.tachiyomi.extension.id.kumapoi�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.kumapoi-v1.4.36.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.kumapoi.png"1.4($21.4.368B-����߀¸FKumaPoiid"https://kumapoi.info
�
KumoPoi(eu.kanade.tachiyomi.extension.id.kumopoi�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.kumopoi-v1.4.32.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.kumopoi.png"1.4( 21.4.328B,��Ԃ���MKumoPoiid"https://kumopoi.org
�

Kuro Manga*eu.kanade.tachiyomi.extension.id.kuromanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.kuromanga-v1.4.32.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.kuromanga.png"1.4( 21.4.32B0��������1
Kuro Mangaid"https://kuromanga.me
�
LepoyTL(eu.kanade.tachiyomi.extension.id.lepoytl�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.lepoytl-v1.4.15.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.lepoytl.png"1.4(21.4.15B2��Ń����LepoyTLid"https://www.lepoytl.my.id
�
	LianScans*eu.kanade.tachiyomi.extension.id.lianscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.lianscans-v1.4.34.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.lianscans.png"1.4("21.4.348B4��������{	LianScansid"https://www.lianscans.com
�
LumireVerse,eu.kanade.tachiyomi.extension.id.lumireverse�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.lumireverse-v1.4.47.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.lumireverse.png"1.4(/21.4.47B0����γ��FLumireVerseid"https://lumire.asia
�

LumosKomik+eu.kanade.tachiyomi.extension.id.lumoskomik�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.lumoskomik-v1.4.54.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.lumoskomik.png"1.4(621.4.54B2������Ҏ#
LumosKomikid"https://02.lumosgg.com
�
Maid - Manga*eu.kanade.tachiyomi.extension.id.maidmanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.maidmanga-v1.4.12.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.maidmanga.png"1.4(21.4.128B4��д�ߪOMaid - Mangaid"https://www.maid.my.id
�
	Manga Can)eu.kanade.tachiyomi.extension.id.mangacan�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.mangacan-v1.4.33.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.mangacan.png"1.4(!21.4.338B3���ϲ�Ă=	Manga Canid"https://mangacanblog.com
�
	MangaKita*eu.kanade.tachiyomi.extension.id.mangakita�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.mangakita-v1.4.34.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.mangakita.png"1.4("21.4.34B/��ك����#	MangaKitaid"https://mangakita.me
�
	Mangakuri*eu.kanade.tachiyomi.extension.id.mangakuri�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.mangakuri-v1.4.32.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.mangakuri.png"1.4( 21.4.328B7£��Ǹ��w	Mangakuriid"https://lc1.mangakuri.online
�
Mangalay)eu.kanade.tachiyomi.extension.id.mangalay�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.mangalay-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.mangalay.png"1.4(21.4.2B6�ݷؿ���mMangalayid"http://mangalay.blogspot.com
�
	Mangasusu*eu.kanade.tachiyomi.extension.id.mangasusu�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.mangasusu-v1.4.37.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.mangasusu.png"1.4(%21.4.378B2����ҟ��q	Mangasusuid"https://mangasusuku.com
�
Ikiru*eu.kanade.tachiyomi.extension.id.mangatale�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.mangatale-v1.4.49.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.mangatale.png"1.4(121.4.49B+��������Ikiruid"https://05.ikiru.wtf
�
Siren Komik*eu.kanade.tachiyomi.extension.id.mangkomik�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.mangkomik-v1.4.40.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.mangkomik.png"1.4((21.4.40B3�ʕ�����uSiren Komikid"https://sirenkomik.xyz
�

ManhwaDesu+eu.kanade.tachiyomi.extension.id.manhwadesu�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.manhwadesu-v1.4.43.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.manhwadesu.png"1.4(+21.4.438B4��������r
ManhwaDesuid"https://manhwadesu.store
�

Manhwahana+eu.kanade.tachiyomi.extension.id.manhwahana�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.manhwahana-v1.4.50.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.manhwahana.png"1.4(221.4.508B2Ԫ���ν�
Manhwahanaid"https://manhwahana.com
�
Manhwa Indo+eu.kanade.tachiyomi.extension.id.manhwaindo�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.manhwaindo-v1.4.43.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.manhwaindo.png"1.4(+21.4.438B6��������Manhwa Indoid"https://www.manhwaindo.my
�
ManhwaLand.mom.eu.kanade.tachiyomi.extension.id.manhwalandmom�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.manhwalandmom-v1.4.42.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.manhwalandmom.png"1.4(*21.4.428B:�����յ;ManhwaLand.momid"https://02.manhwaland.land
�
Manhwa List-eu.kanade.tachiyomi.extension.id.manhwalistid�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.manhwalistid-v1.4.39.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.manhwalistid.png"1.4('21.4.39B6���߾ꪖ+Manhwa Listid"https://manhwalist02.asia
�
Manhwalist.org.eu.kanade.tachiyomi.extension.id.manhwalistorg�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.manhwalistorg-v1.4.33.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.manhwalistorg.png"1.4(!21.4.33B7�������Manhwalist.orgid"https://isekaikomik.com
�
Medusascans,eu.kanade.tachiyomi.extension.id.medusascans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.medusascans-v1.4.9.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.medusascans.png"1.4(	21.4.98B4��Ɉ���wMedusascansid"https://medusascans.pro
�
MG Komik(eu.kanade.tachiyomi.extension.id.mgkomik�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.mgkomik-v1.4.72.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.mgkomik.png"1.4(H21.4.72B/�͉ç��QMG Komikid"https://id.mgkomik.cc
�
Mihentai)eu.kanade.tachiyomi.extension.id.mihentai�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.mihentai-v1.4.35.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.mihentai.png"1.4(#21.4.358B.�眾凐�+Mihentaiid"https://mihentai.net
�
MikoRoku)eu.kanade.tachiyomi.extension.id.mikoroku�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.mikoroku-v1.4.19.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.mikoroku.png"1.4(21.4.198B2����ݤ��wMikoRokuid"https://www.mikoroku.com
�
Monzee Komik,eu.kanade.tachiyomi.extension.id.monzeekomik�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.monzeekomik-v1.4.31.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.monzeekomik.png"1.4(21.4.318B4����Å��YMonzee Komikid"https://monzee01.my.id
�
Narasi Ninja,eu.kanade.tachiyomi.extension.id.narasininja�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.narasininja-v1.4.2.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.narasininja.png"1.4(21.4.2B4޲Ҕ�Ö�ANarasiNinjaid"https://narasininja.net
�
Natsu&eu.kanade.tachiyomi.extension.id.natsu�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.natsu-v1.4.34.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.natsu.png"1.4("21.4.34B'����ݴ��
Natsuid"https://natsu.tv
�
Neumanga)eu.kanade.tachiyomi.extension.id.neumanga�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.neumanga-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.neumanga.png"1.4(21.4.2B.��󗨾��Neumangaid"https://neumanga.xyz
�
NgamenKomik,eu.kanade.tachiyomi.extension.id.ngamenkomik�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.ngamenkomik-v1.4.14.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.ngamenkomik.png"1.4(21.4.14B?���➅�?NgamenKomikid""https://ngamenkomik05.blogspot.com
�
Ngomik (unoriginal)'eu.kanade.tachiyomi.extension.id.ngomik�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.ngomik-v1.4.38.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.ngomik.png"1.4(&21.4.38B9���ڞ��JNgomik (unoriginal)id"https://02.ngomik.cc
�
Nimemob(eu.kanade.tachiyomi.extension.id.nimemob�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.nimemob-v1.4.11.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.nimemob.png"1.4(21.4.118B2��������KNimemobid"https://www.nimemob.my.id
�
Noromax(eu.kanade.tachiyomi.extension.id.noromax�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.noromax-v1.4.37.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.noromax.png"1.4(%21.4.37B0�򝻙���$Noromaxid"https://noromax02.my.id
�
	OkyyKomik*eu.kanade.tachiyomi.extension.id.okyykomik�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.okyykomik-v1.4.13.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.okyykomik.png"1.4(21.4.13B6¨������t	OkyyKomikid"https://www.okyykomik.my.id
�
Omicaso(eu.kanade.tachiyomi.extension.id.omicaso�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.omicaso-v1.4.35.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.omicaso.png"1.4(#21.4.358B,ʸ��∔�eOmicasoid"https://omicaso.org
�
One Piece Berwarna1eu.kanade.tachiyomi.extension.id.onepieceberwarna�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.onepieceberwarna-v1.4.1.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.onepieceberwarna.png"1.4(21.4.1B@�������WOne Piece Berwarnaid"https://onepieceberwarna.com
�
	Ota Scans)eu.kanade.tachiyomi.extension.id.otascans�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.otascans-v1.4.53.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.otascans.png"1.4(521.4.538B1���Ǵ��	Ota Scansid"https://yurilabs.my.id
�

Pix Hentai*eu.kanade.tachiyomi.extension.id.pixhentai�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.pixhentai-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.pixhentai.png"1.4(21.4.18B1�������g
Pix Hentaiid"https://pixhentai.com
�
	Pornhwa18*eu.kanade.tachiyomi.extension.id.pornhwa18�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.pornhwa18-v1.4.50.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.pornhwa18.png"1.4(221.4.508B0�Ԧ�����u	Pornhwa18id"https://pornhwa18.com
�
Pramramadhan-eu.kanade.tachiyomi.extension.id.pramramadhan�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.pramramadhan-v1.4.2.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.pramramadhan.png"1.4(21.4.28B;��������Pramramadhanid"https://01.pramramadhan.my.id
�
Riztranslation/eu.kanade.tachiyomi.extension.id.riztranslation�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.riztranslation-v1.4.2.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.riztranslation.png"1.4(21.4.2B@���淹��dRiztranslationid" https://riztranslation.pages.dev
�
Roseveil)eu.kanade.tachiyomi.extension.id.roseveil�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.roseveil-v1.4.47.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.roseveil.png"1.4(/21.4.478B.��������IRoseveilid"https://roseveil.org
�

Sasangeyou+eu.kanade.tachiyomi.extension.id.sasangeyou�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.sasangeyou-v1.4.32.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.sasangeyou.png"1.4( 21.4.328B2�ʗ�����
Sasangeyouid"https://sasangeyou.net
�
Sekte Doujin,eu.kanade.tachiyomi.extension.id.sektedoujin�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.sektedoujin-v1.4.38.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.sektedoujin.png"1.4(&21.4.388B4��М���nSekte Doujinid"https://sektedoujin.cc
�
Sekte Komik+eu.kanade.tachiyomi.extension.id.sektekomik�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.sektekomik-v1.4.29.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.sektekomik.png"1.4(21.4.29B3���͛兣bSekte Komikid"https://sektekomik.xyz
�
	Shinigami*eu.kanade.tachiyomi.extension.id.shinigami�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.shinigami-v1.4.79.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.shinigami.png"1.4(O21.4.79B3������ˬ/	Shinigamiid"https://g.shinigami.asia
�
	Shirakami*eu.kanade.tachiyomi.extension.id.shirakami�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.shirakami-v1.4.32.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.shirakami.png"1.4( 21.4.32B0��������k	Shirakamiid"https://shirakami.xyz
�
ShiroDoujin,eu.kanade.tachiyomi.extension.id.shirodoujin�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.shirodoujin-v1.4.3.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.shirodoujin.png"1.4(21.4.38B5�����ʝ�uShiro Doujinid"https://shirodoujin.com
�

ShiyuraSub+eu.kanade.tachiyomi.extension.id.shiyurasub�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.shiyurasub-v1.4.14.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.shiyurasub.png"1.4(21.4.14B;��ت����b
ShiyuraSubid"https://shiyurasub.blogspot.com
�
Siikomik)eu.kanade.tachiyomi.extension.id.siimanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.siimanga-v1.4.50.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.siimanga.png"1.4(221.4.508B.��֞���BSiikomikid"https://siikomik.net
�
	Softkomik*eu.kanade.tachiyomi.extension.id.softkomik�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.softkomik-v1.4.12.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.softkomik.png"1.4(21.4.12B/�ƫᭈ��=	Softkomikid"https://softkomik.co
�

Soul Scans*eu.kanade.tachiyomi.extension.id.soulscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.soulscans-v1.4.34.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.soulscans.png"1.4("21.4.34B3��ˁ���o
Soul Scansid"https://soulscans.my.id
�
TheManga)eu.kanade.tachiyomi.extension.id.themanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.themanga-v1.4.49.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.themanga.png"1.4(121.4.498B/�����9TheMangaid"https://themanga.site
�
	Tooncubus*eu.kanade.tachiyomi.extension.id.tooncubus�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.tooncubus-v1.4.13.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.tooncubus.png"1.4(21.4.138B4�غ�����u	Tooncubusid"https://www.tooncubus.top
�

Ulas Comic*eu.kanade.tachiyomi.extension.id.ulascomic�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.ulascomic-v1.4.13.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.ulascomic.png"1.4(21.4.13B7��������
Ulas Comicid"https://www.ulascomic01.xyz
�

West Manga*eu.kanade.tachiyomi.extension.id.westmanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.westmanga-v1.4.41.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.westmanga.png"1.4()21.4.41B0����〥{
West Mangaid"https://westmanga.co
�
Kaguya)eu.kanade.tachiyomi.extension.id.yubikiri�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-id.yubikiri-v1.4.53.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.id.yubikiri.png"1.4(521.4.538B-���텪�Kaguyaid"https://v1.kaguya.pro
�
Anime GDR Club-eu.kanade.tachiyomi.extension.it.animegdrclub�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-it.animegdrclub-v1.4.2.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.it.animegdrclub.png"1.4(21.4.2B<����ü��
Anime GDR Clubit"http://www.agcscanlation.it/
�
DDT Team(eu.kanade.tachiyomi.extension.it.ddtteam�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-it.ddtteam-v1.4.5.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.it.ddtteam.png"1.4(21.4.5B3����ꦃ�EDDT Teamit"https://ddt.hastateam.com
�
DigitalTeam,eu.kanade.tachiyomi.extension.it.digitalteam�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-it.digitalteam-v1.4.4.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.it.digitalteam.png"1.4(21.4.4B0��Ꚛ͏�=DigitalTeamit"https://dgtread.com
�
GTO The Great Site$eu.kanade.tachiyomi.extension.it.gto�
fhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-it.gto-v1.4.7.apkthttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.it.gto.png"1.4(21.4.7BF��������&GTO The Great Siteit""https://reader.gtothegreatsite.net
�

Hasta Team*eu.kanade.tachiyomi.extension.it.hastateam�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-it.hastateam-v1.4.5.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.it.hastateam.png"1.4(21.4.5B8��������-
Hasta Teamit"https://reader.hastateam.com
�
HentaiArchive.eu.kanade.tachiyomi.extension.it.hentaiarchive�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-it.hentaiarchive-v1.4.3.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.it.hentaiarchive.png"1.4(21.4.38B=ۍ�ҿTHentaiArchiveit"https://www.hentai-archive.com
�
HentaiFantasy.eu.kanade.tachiyomi.extension.it.hentaifantasy�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-it.hentaifantasy-v1.4.7.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.it.hentaifantasy.png"1.4(21.4.78B7���Ȳ���HentaiFantasyit"https://hentaifantasy.it
�
Juin Jutsu Team Reader4eu.kanade.tachiyomi.extension.it.juinjutsuteamreader�
vhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-it.juinjutsuteamreader-v1.4.5.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.it.juinjutsuteamreader.png"1.4(21.4.5BG�������Juin Jutsu Team Readerit"https://www.juinjutsureader.ovh
�
LupiTeam)eu.kanade.tachiyomi.extension.it.lupiteam�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-it.lupiteam-v1.4.7.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.it.lupiteam.png"1.4(21.4.7B.ެə�Ҋ�LupiTeamit"https://lupiteam.net
�

Mangaworld+eu.kanade.tachiyomi.extension.it.mangaworld�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-it.mangaworld-v1.4.14.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.it.mangaworld.png"1.4(21.4.14B5��������b
Mangaworldit"https://www.mangaworld.mx
�
MangaworldAdult0eu.kanade.tachiyomi.extension.it.mangaworldadult�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-it.mangaworldadult-v1.4.6.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.it.mangaworldadult.png"1.4(21.4.68B@ߕ������MangaworldAdultit"https://www.mangaworldadult.net
�
NIFTeam(eu.kanade.tachiyomi.extension.it.nifteam�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-it.nifteam-v1.4.6.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.it.nifteam.png"1.4(21.4.6B2������lNIFTeamit"https://read-nifteam.info
�
Phoenix Scans-eu.kanade.tachiyomi.extension.it.phoenixscans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-it.phoenixscans-v1.4.8.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.it.phoenixscans.png"1.4(21.4.8B;��������WPhoenix Scansit"https://www.phoenixscans.com
�
TuttoAnimeManga0eu.kanade.tachiyomi.extension.it.tuttoanimemanga�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-it.tuttoanimemanga-v1.4.9.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.it.tuttoanimemanga.png"1.4(	21.4.9B<�������TuttoAnimeMangait"https://tuttoanimemanga.net
�
Walpurgi Scan.eu.kanade.tachiyomi.extension.it.walpurgisscan�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-it.walpurgisscan-v1.4.39.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.it.walpurgisscan.png"1.4('21.4.39B:�硭����[Walpurgi Scanit"https://www.walpurgiscan.it
�

ZeurelScan+eu.kanade.tachiyomi.extension.it.zeurelscan�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-it.zeurelscan-v1.4.4.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.it.zeurelscan.png"1.4(21.4.4B6���٪��z
ZeurelScanit"https://www.zeurelscan.com
�

Alphapolis+eu.kanade.tachiyomi.extension.ja.alphapolis�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.alphapolis-v1.4.2.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.alphapolis.png"1.4(21.4.28B8����ؽ�
Alphapolisja"https://www.alphapolis.co.jp
�
Ameba Manga+eu.kanade.tachiyomi.extension.ja.amebamanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.amebamanga-v1.4.1.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.amebamanga.png"1.4(21.4.18B6çܿ����$Ameba Mangaja"https://dokusho-ojikan.jp
�

Big Comics*eu.kanade.tachiyomi.extension.ja.bigcomics�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.bigcomics-v1.4.4.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.bigcomics.png"1.4(21.4.4B0쁸����(
Big Comicsja"https://bigcomics.jp
�
	Ciao Plus)eu.kanade.tachiyomi.extension.ja.ciaoplus�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.ciaoplus-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.ciaoplus.png"1.4(21.4.1B8�����ɀ	Ciao Plusja"https://ciao.shogakukan.co.jp
�
C%eu.kanade.tachiyomi.extension.ja.cmoa�
ghttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.cmoa-v1.4.1.apkuhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.cmoa.png"1.4(21.4.18B*�ӧ�����C'moAja"https://www.cmoa.jp
�
Comic Boost+eu.kanade.tachiyomi.extension.ja.comicboost�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.comicboost-v1.4.2.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.comicboost.png"1.4(21.4.2B4��������Comic Boostja"https://comic-boost.com
�
Comic Border,eu.kanade.tachiyomi.extension.ja.comicborder�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.comicborder-v1.4.9.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.comicborder.png"1.4(	21.4.9B5��������Comic Borderja"https://comicborder.com
�

Comic Days*eu.kanade.tachiyomi.extension.ja.comicdays�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.comicdays-v1.4.9.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.comicdays.png"1.4(	21.4.9B2�����̀J
Comic Daysja"https://comic-days.com
�
Comic Earth Star/eu.kanade.tachiyomi.extension.ja.comicearthstar�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.comicearthstar-v1.4.10.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.comicearthstar.png"1.4(
21.4.10B=��䑫��1Comic Earth Starja"https://comic-earthstar.com
�
Comic Festa+eu.kanade.tachiyomi.extension.ja.comicfesta�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.comicfesta-v1.4.1.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.comicfesta.png"1.4(21.4.18B2�Ҳ����oComic Festaja"https://comic.iowl.jp
�
	COMIC FUZ)eu.kanade.tachiyomi.extension.ja.comicfuz�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.comicfuz-v1.4.3.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.comicfuz.png"1.4(21.4.38B0���ڐε�e	COMIC FUZja"https://comic-fuz.com
�
Comic Gardo+eu.kanade.tachiyomi.extension.ja.comicgardo�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.comicgardo-v1.4.10.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.comicgardo.png"1.4(
21.4.10B4���Ф���+Comic Gardoja"https://comic-gardo.com
�
Comic Grast+eu.kanade.tachiyomi.extension.ja.comicgrast�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.comicgrast-v1.4.1.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.comicgrast.png"1.4(21.4.1B.ۅ�����Comic Grastja"https://novema.jp
�

Comic MeDu*eu.kanade.tachiyomi.extension.ja.comicmedu�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.comicmedu-v1.4.3.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.comicmedu.png"1.4(21.4.3B2�Ǫ�����e
Comic MeDuja"https://comic-medu.com
�
	Kiraboshi,eu.kanade.tachiyomi.extension.ja.comicmeteor�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.comicmeteor-v1.4.3.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.comicmeteor.png"1.4(21.4.38B,�����ފ�k	Kiraboshija"https://kirapo.jp
�
Comic Nettai,eu.kanade.tachiyomi.extension.ja.comicnettai�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.comicnettai-v1.4.2.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.comicnettai.png"1.4(21.4.2B9哽�����Comic Nettaija"https://www.comicnettai.com
�
Comico'eu.kanade.tachiyomi.extension.ja.comico�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.comico-v1.4.1.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.comico.png"1.4(21.4.18B0ȳ������E	コミコja"https://www.comico.jp
�

Comic Pash*eu.kanade.tachiyomi.extension.ja.comicpash�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.comicpash-v1.4.4.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.comicpash.png"1.4(21.4.4B0Ӎݴ����[
Comic Pashja"https://comicpash.jp
�

Comic Ride*eu.kanade.tachiyomi.extension.ja.comicride�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.comicride-v1.4.3.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.comicride.png"1.4(21.4.3B0�������^
Comic Rideja"https://comicride.jp
�
	Comic Ryu)eu.kanade.tachiyomi.extension.ja.comicryu�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.comicryu-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.comicryu.png"1.4(21.4.1B3����Գ��	Comic Ryuja"https://www.comic-ryu.jp
�
Comic Y-OURs+eu.kanade.tachiyomi.extension.ja.comicyours�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.comicyours-v1.4.9.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.comicyours.png"1.4(	21.4.9B6����þ�^Comic Y-OURsja"https://comic-y-ours.com
�
Comiplex)eu.kanade.tachiyomi.extension.ja.comiplex�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.comiplex-v1.4.9.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.comiplex.png"1.4(	21.4.9B6��������Comiplexja"https://viewer.heros-web.com
�
Corocoro Online/eu.kanade.tachiyomi.extension.ja.corocoroonline�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.corocoroonline-v1.4.10.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.corocoroonline.png"1.4(
21.4.10B8���џ��jCorocoro Onlineja"https://www.corocoro.jp
�
CyComi'eu.kanade.tachiyomi.extension.ja.cycomi�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.cycomi-v1.4.1.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.cycomi.png"1.4(21.4.1B*����۞��sCyComija"https://cycomi.com
�
	DMM/FANZA$eu.kanade.tachiyomi.extension.ja.dmm�
fhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.dmm-v1.4.1.apkthttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.dmm.png"1.4(21.4.18B)ˋ�����cDMMja"https://book.dmm.comB-�����¼�YFANZAja"https://book.dmm.co.jp
�
Docomo'eu.kanade.tachiyomi.extension.ja.docomo�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.docomo-v1.4.2.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.docomo.png"1.4(21.4.2B2�����җ�'Docomoja"https://dbook.docomo.ne.jp
�
Dokiraw(eu.kanade.tachiyomi.extension.ja.dokiraw�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.dokiraw-v1.4.7.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.dokiraw.png"1.4(21.4.78B.���Š�͇7Dokirawja"https://dokiraw.cloud
�
DreComi+*eu.kanade.tachiyomi.extension.ja.drecomics�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.drecomics-v1.4.3.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.drecomics.png"1.4(21.4.38B1�����yDreComi+ja"https://drecomi-plus.jp
�

eBookJapan+eu.kanade.tachiyomi.extension.ja.ebookjapan�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.ebookjapan-v1.4.1.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.ebookjapan.png"1.4(21.4.18B:���쇧��
eBookJapanja"https://ebookjapan.yahoo.co.jp
�
	FireCross*eu.kanade.tachiyomi.extension.ja.firecross�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.firecross-v1.4.3.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.firecross.png"1.4(21.4.3B/������W	FireCrossja"https://firecross.jp
�
Flower Comics-eu.kanade.tachiyomi.extension.ja.flowercomics�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.flowercomics-v1.4.2.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.flowercomics.png"1.4(21.4.2B6󆬦����ZFlower Comicsja"https://flowercomics.jp
�
FOD(eu.kanade.tachiyomi.extension.ja.fodfuji�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.fodfuji-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.fodfuji.png"1.4(21.4.18B3�Ҭ�넪�FODja"https://manga.fod.fujitv.co.jp
�
Gangan Online-eu.kanade.tachiyomi.extension.ja.ganganonline�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.ganganonline-v1.4.2.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.ganganonline.png"1.4(21.4.2B;�Ɛ�҈ƮGangan Onlineja"https://www.ganganonline.com
�
GANMA!&eu.kanade.tachiyomi.extension.ja.ganma�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.ganma-v1.4.5.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.ganma.png"1.4(21.4.5B(�Ծ��Ż�oGANMA!ja"https://ganma.jp
�
Gaugau Monster Plus2eu.kanade.tachiyomi.extension.ja.gaugaumonsterplus�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.gaugaumonsterplus-v1.4.3.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.gaugaumonsterplus.png"1.4(21.4.3BK���ӣ���がうがうモンスター＋ja"https://gaugau.futabanet.jp
�

Goraku Web*eu.kanade.tachiyomi.extension.ja.gorakuweb�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.gorakuweb-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.gorakuweb.png"1.4(21.4.28B1��������r
Goraku Webja"https://gorakuweb.com
�
Hachiraw)eu.kanade.tachiyomi.extension.ja.hachiraw�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.hachiraw-v1.4.3.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.hachiraw.png"1.4(21.4.38B.��֋����vHachirawja"https://hachiraw.net
�
Hana To Yume+)eu.kanade.tachiyomi.extension.ja.hanayume�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.hanayume-v1.4.3.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.hanayume.png"1.4(21.4.3B3��㟼���^Hana To Yume+ja"https://hanayume.com
�
Ichicomi)eu.kanade.tachiyomi.extension.ja.ichicomi�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.ichicomi-v1.4.9.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.ichicomi.png"1.4(	21.4.9B.���̇��Ichicomija"https://ichicomi.com
�
Idol. gravureprincess .date8eu.kanade.tachiyomi.extension.ja.idolgravureprincessdate�
zhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.idolgravureprincessdate-v1.4.4.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.idolgravureprincessdate.png"1.4(21.4.48BN������KIdol. gravureprincess .dateja"!https://idol.gravureprincess.date
�
Jmanga'eu.kanade.tachiyomi.extension.ja.jmanga�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.jmanga-v1.4.3.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.jmanga.png"1.4(21.4.38B,é����ӝUJmangaja"https://jmanga.codes
�
	J-N Books(eu.kanade.tachiyomi.extension.ja.jnbooks�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.jnbooks-v1.4.3.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.jnbooks.png"1.4(21.4.3B4�������'	J-N Booksja"https://comic.j-nbooks.jp
�
Jump Rookie!+eu.kanade.tachiyomi.extension.ja.jumprookie�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.jumprookie-v1.4.1.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.jumprookie.png"1.4(21.4.1B;ͩ������:Jump Rookie!ja"https://rookie.shonenjump.com
�
KadoComi)eu.kanade.tachiyomi.extension.ja.kadocomi�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.kadocomi-v1.4.3.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.kadocomi.png"1.4(21.4.3B6����߹�tカドコミja"https://comic-walker.com
�
KimiComi)eu.kanade.tachiyomi.extension.ja.kimicomi�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.kimicomi-v1.4.4.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.kimicomi.png"1.4(21.4.4B.�������KimiComija"https://kimicomi.com
�
KissLove)eu.kanade.tachiyomi.extension.ja.kisslove�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.kisslove-v1.4.19.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.kisslove.png"1.4(21.4.198B*������˾WKissLoveja"https://klz9.com
�
KL Raw&eu.kanade.tachiyomi.extension.ja.klraw�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.klraw-v1.4.4.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.klraw.png"1.4(21.4.48B.�����Ơ�gKL Rawja"https://www.klraw.info
�
	Kmansin09*eu.kanade.tachiyomi.extension.ja.kmansin09�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.kmansin09-v1.4.50.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.kmansin09.png"1.4(221.4.50B0ե�짉��8	Kmansin09ja"https://kmansin09.top
�
Kumaraw(eu.kanade.tachiyomi.extension.ja.kumaraw�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.kumaraw-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.kumaraw.png"1.4(21.4.18B,ݎ������[Kumarawja"https://kumaraw.com
�
Kurage Bunch,eu.kanade.tachiyomi.extension.ja.kuragebunch�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.kuragebunch-v1.4.9.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.kuragebunch.png"1.4(	21.4.98B5���ގ���)Kurage Bunchja"https://kuragebunch.com
�

Line Manga*eu.kanade.tachiyomi.extension.ja.linemanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.linemanga-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.linemanga.png"1.4(21.4.18B1��餿���e
Line Mangaja"https://manga.line.me
�
Magazine Pocket/eu.kanade.tachiyomi.extension.ja.magazinepocket�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.magazinepocket-v1.4.12.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.magazinepocket.png"1.4(21.4.12BB������Magazine Pocketja"!https://pocket.shonenmagazine.com
�
MAGCOMI(eu.kanade.tachiyomi.extension.ja.magcomi�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.magcomi-v1.4.11.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.magcomi.png"1.4(21.4.11B,���˖Ҷ�wMAGCOMIja"https://magcomi.com
�
MagKan'eu.kanade.tachiyomi.extension.ja.magkan�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.magkan-v1.4.4.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.magkan.png"1.4(21.4.4B7��ڕ��zMagKanja"https://kansai.mag-garden.co.jp
�
	Manga1000*eu.kanade.tachiyomi.extension.ja.manga1000�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.manga1000-v1.4.13.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.manga1000.png"1.4(21.4.138B/������Ͽ)	Manga1000ja"https://hachiraw.win
�
MangaRaw)eu.kanade.tachiyomi.extension.ja.manga9co�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.manga9co-v1.4.8.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.manga9co.png"1.4(21.4.88Br�������?MangaRawja"Xhttps://manga1001.in#, https://mangaraw.to#, https://mangaraw.io#, https://mangarawjp.io
�
MangaBang Comics*eu.kanade.tachiyomi.extension.ja.mangabang�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.mangabang-v1.4.4.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.mangabang.png"1.4(21.4.4B?����ߥ��WMangaBang Comicsja"https://comics.manga-bang.com
�
Champion Cross+eu.kanade.tachiyomi.extension.ja.mangacross�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.mangacross-v1.4.8.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.mangacross.png"1.4(21.4.8B8�鮷���AChampion Crossja"https://championcross.jp
�
	NihonKuni)eu.kanade.tachiyomi.extension.ja.mangagun�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.mangagun-v1.4.20.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.mangagun.png"1.4(21.4.208B0��Ղ����4	NihonKunija"https://nihonkuni.com
�
Manga Kingdom-eu.kanade.tachiyomi.extension.ja.mangakingdom�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.mangakingdom-v1.4.1.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.mangakingdom.png"1.4(21.4.18B7����ŧ��4Manga Kingdomja"https://comic.k-manga.jp
�

Manga Koma*eu.kanade.tachiyomi.extension.ja.mangakoma�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.mangakoma-v1.4.4.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.mangakoma.png"1.4(21.4.48B3���΅���n
Manga Komaja"https://mangakoma01.com
�
	MangaKuro*eu.kanade.tachiyomi.extension.ja.mangakuro�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.mangakuro-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.mangakuro.png"1.4(21.4.2B0Ў������;	MangaKuroja"https://mangakuro.net
�
MangaMee)eu.kanade.tachiyomi.extension.ja.mangamee�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.mangamee-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.mangamee.png"1.4(21.4.2B.�������GMangaMeeja"https://manga-mee.jp
�

MangaMeets+eu.kanade.tachiyomi.extension.ja.mangameets�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.mangameets-v1.4.1.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.mangameets.png"1.4(21.4.1B2���Ш���#
MangaMeetsja"https://manga-meets.jp
�

Manga Mura*eu.kanade.tachiyomi.extension.ja.mangamura�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.mangamura-v1.4.5.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.mangamura.png"1.4(21.4.58B0�񟘝���
Manga Muraja"https://mangamura.me
�
MangaNo(eu.kanade.tachiyomi.extension.ja.mangano�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.mangano-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.mangano.png"1.4(21.4.1B-��Ŝ��эkMangaNoja"https://manga-no.com
�
	Manga One)eu.kanade.tachiyomi.extension.ja.mangaone�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.mangaone-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.mangaone.png"1.4(21.4.2B0���ఌ��n	Manga Oneja"https://manga-one.com
�

Manga-Park3eu.kanade.tachiyomi.extension.ja.mangaparkpublisher�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.mangaparkpublisher-v1.4.1.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.mangaparkpublisher.png"1.4(21.4.1B2�����(
Manga-Parkja"https://manga-park.com
�
Manga Saison,eu.kanade.tachiyomi.extension.ja.mangasaison�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.mangasaison-v1.4.1.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.mangasaison.png"1.4(21.4.18B2��������gManga Saisonja"https://mechacomi.jp
�
Manga Toshokan Z/eu.kanade.tachiyomi.extension.ja.mangatoshokanz�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.mangatoshokanz-v1.4.1.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.mangatoshokanz.png"1.4(21.4.1B;��ԑ����hマンガ図書館Zja"https://www.mangaz.com
�
Manga UP! (Japan)-eu.kanade.tachiyomi.extension.ja.mangaupjapan�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.mangaupjapan-v1.4.1.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.mangaupjapan.png"1.4(21.4.1B;�З�����	Manga UP! (Japan)ja"https://www.manga-up.com
�
Mokuro'eu.kanade.tachiyomi.extension.ja.mokuro�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.mokuro-v1.4.3.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.mokuro.png"1.4(21.4.38B*������3Mokuroja"https://mokuro.moe
�
MomonGA(eu.kanade.tachiyomi.extension.ja.momonga�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.momonga-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.momonga.png"1.4(21.4.18B.�����ӀJmomon:GAja"https://momon-ga.com
�
	Nicomanga*eu.kanade.tachiyomi.extension.ja.nicomanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.nicomanga-v1.4.14.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.nicomanga.png"1.4(21.4.148B0�ߚ�����N	Nicomangaja"https://nicomanga.com
�
Nicovideo Seiga/eu.kanade.tachiyomi.extension.ja.nicovideoseiga�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.nicovideoseiga-v1.4.8.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.nicovideoseiga.png"1.4(21.4.8B>�����Nicovideo Seigaja"https://sp.manga.nicovideo.jp
�
Nikkangecchan.eu.kanade.tachiyomi.extension.ja.nikkangecchan�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.nikkangecchan-v1.4.3.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.nikkangecchan.png"1.4(21.4.3B7����ɕHNikkangecchanja"https://nikkangecchan.jp
�
Ohta Web Comic-eu.kanade.tachiyomi.extension.ja.ohtawebcomic�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.ohtawebcomic-v1.4.3.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.ohtawebcomic.png"1.4(21.4.38B>���ݤ���Ohta Web Comicja"https://webcomic.ohtabooks.com
�
Pash Up!'eu.kanade.tachiyomi.extension.ja.pashup�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.pashup-v1.4.2.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.pashup.png"1.4(21.4.2B,�ʼ�׃��>Pash Up!ja"https://pash-up.jp
�
Piccoma(eu.kanade.tachiyomi.extension.ja.piccoma�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.piccoma-v1.4.2.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.piccoma.png"1.4(21.4.28B,���񉖕�cPiccomaja"https://piccoma.com
�
Pixiv Comic+eu.kanade.tachiyomi.extension.ja.pixivcomic�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.pixivcomic-v1.4.3.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.pixivcomic.png"1.4(21.4.3B:ۡ������(Pixivコミックja"https://comic.pixiv.net
�
Raw1001(eu.kanade.tachiyomi.extension.ja.raw1001�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.raw1001-v1.4.4.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.raw1001.png"1.4(21.4.48B,��������.Raw1001ja"https://raw1001.net
�
Raw18&eu.kanade.tachiyomi.extension.ja.raw18�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.raw18-v1.4.13.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.raw18.png"1.4(21.4.138B(���ŁψRaw18ja"https://raw18.tax
�
RawBaka(eu.kanade.tachiyomi.extension.ja.rawbaka�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.rawbaka-v1.4.50.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.rawbaka.png"1.4(221.4.508B,����Ȭ�SRawBakaja"https://rawbaka.com
�
Rawdevart.art-eu.kanade.tachiyomi.extension.ja.rawdevartart�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.rawdevartart-v1.4.4.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.rawdevartart.png"1.4(21.4.48B4���Ѓ�Ԛ/Rawdevart.artja"https://rawdevart.art
�
RawINU'eu.kanade.tachiyomi.extension.ja.rawinu�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.rawinu-v1.4.17.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.rawinu.png"1.4(21.4.178B*ץ������lRawINUja"https://rawinu.com
�
RawJX&eu.kanade.tachiyomi.extension.ja.rawjx�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.rawjx-v1.4.45.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.rawjx.png"1.4(-21.4.458B(��۪��SRawJXja"https://rawjx.com
�
Rawkuma(eu.kanade.tachiyomi.extension.ja.rawkuma�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.rawkuma-v1.4.37.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.rawkuma.png"1.4(%21.4.378B,�ύް��ORawkumaja"https://rawkuma.net
�
WeLoveManga&eu.kanade.tachiyomi.extension.ja.rawlh�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.rawlh-v1.4.17.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.rawlh.png"1.4(21.4.178B/��η���iWeLoveMangaja"https://weloma.art
�
	Raw Otaku)eu.kanade.tachiyomi.extension.ja.rawotaku�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.rawotaku-v1.4.4.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.rawotaku.png"1.4(21.4.48B/������ܤf	Raw Otakuja"https://rawotaku.com
�
Raw UwU'eu.kanade.tachiyomi.extension.ja.rawuwu�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.rawuwu-v1.4.1.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.rawuwu.png"1.4(21.4.18B+凬�����Raw UwUja"https://rawuwu.net
�
RawZO&eu.kanade.tachiyomi.extension.ja.rawxz�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.rawxz-v1.4.51.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.rawxz.png"1.4(321.4.518B(�ɗ�⅂�nRawZOja"https://rawzo.net
�
Reader Store,eu.kanade.tachiyomi.extension.ja.readerstore�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.readerstore-v1.4.1.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.readerstore.png"1.4(21.4.18B8���鳠�Reader Storeja"https://ebookstore.sony.jp
�
RimacomiPlus-eu.kanade.tachiyomi.extension.ja.rimacomiplus�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.rimacomiplus-v1.4.3.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.rimacomiplus.png"1.4(21.4.3B5��������yRimacomiPlusja"https://rimacomiplus.jp
�
	Sen Manga)eu.kanade.tachiyomi.extension.ja.senmanga�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.senmanga-v1.4.8.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.senmanga.png"1.4(21.4.88B3�ɇ���ǉk	Sen Mangaja"https://raw.senmanga.com
�
Shonen Jump+/eu.kanade.tachiyomi.extension.ja.shonenjumpplus�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.shonenjumpplus-v1.4.11.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.shonenjumpplus.png"1.4(21.4.11B8Ŗ�ɴ��GShonen Jump+ja"https://shonenjumpplus.com
�
Sokuyomi)eu.kanade.tachiyomi.extension.ja.sokuyomi�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.sokuyomi-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.sokuyomi.png"1.4(21.4.18B-�������+Sokuyomija"https://sokuyomi.jp
�
Sunday Web Every/eu.kanade.tachiyomi.extension.ja.sundaywebevery�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.sundaywebevery-v1.4.9.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.sundaywebevery.png"1.4(	21.4.98B>���Ǡ���pSunday Web Everyja"https://www.sunday-webry.com
�
SyoSetu(eu.kanade.tachiyomi.extension.ja.syosetu�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.syosetu-v1.4.6.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.syosetu.png"1.4(21.4.68B+�ݰߺ��SyoSetuja"https://syosetu.gs
�
	TakeComic*eu.kanade.tachiyomi.extension.ja.takecomic�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.takecomic-v1.4.4.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.takecomic.png"1.4(21.4.4B/������G	TakeComicja"https://takecomic.jp
�
Tonari no Young Jump2eu.kanade.tachiyomi.extension.ja.tonarinoyoungjump�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.tonarinoyoungjump-v1.4.9.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.tonarinoyoungjump.png"1.4(	21.4.9B;��ߍ��ļOTonari no Young Jumpja"https://tonarinoyj.jp
�
Twi4%eu.kanade.tachiyomi.extension.ja.twi4�
ghttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.twi4-v1.4.6.apkuhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.twi4.png"1.4(21.4.6B9ؿ�����Twi4ja"#https://sai-zen-sen.jp/comics/twi4/
�
U-NEXT&eu.kanade.tachiyomi.extension.ja.unext�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.unext-v1.4.3.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.unext.png"1.4(21.4.3B.��ϳԵҩU-NEXTja"https://video.unext.jp
�
Web Comic Gamma.eu.kanade.tachiyomi.extension.ja.webcomicgamma�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.webcomicgamma-v1.4.9.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.webcomicgamma.png"1.4(	21.4.9BF�������?Web Comic Gammaja"%https://webcomicgamma.takeshobo.co.jp
�
Web Comic Gamma Plus2eu.kanade.tachiyomi.extension.ja.webcomicgammaplus�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.webcomicgammaplus-v1.4.9.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.webcomicgammaplus.png"1.4(	21.4.98BG�芅����UWeb Comic Gamma Plusja"!https://gammaplus.takeshobo.co.jp
�
Love4u/eu.kanade.tachiyomi.extension.ja.welovemangaone�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.welovemangaone-v1.4.14.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.welovemangaone.png"1.4(21.4.148B*��������Love4uja"https://love4u.net
�
Weekly Young Magazine(eu.kanade.tachiyomi.extension.ja.yanmaga�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.yanmaga-v1.4.4.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.yanmaga.png"1.4(21.4.48B?���Ƅ��ヤンマガ（マンガ）ja"https://yanmaga.jpBB��������ヤンマガ（グラビア）ja"https://yanmaga.jp
�
Young Jump+%eu.kanade.tachiyomi.extension.ja.ynjn�
ghttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.ynjn-v1.4.1.apkuhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.ynjn.png"1.4(21.4.1B,������.Young Jump+ja"https://ynjn.jp
�
Yomonga(eu.kanade.tachiyomi.extension.ja.yomonga�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.yomonga-v1.4.2.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.yomonga.png"1.4(21.4.2B0��������hYomongaja"https://www.yomonga.com
�
Young Animal,eu.kanade.tachiyomi.extension.ja.younganimal�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.younganimal-v1.4.3.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.younganimal.png"1.4(21.4.3B5��Ȑ����1Young Animalja"https://younganimal.com
�
Young Champion.eu.kanade.tachiyomi.extension.ja.youngchampion�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.youngchampion-v1.4.3.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.youngchampion.png"1.4(21.4.38B8�Ц����Young Championja"https://youngchampion.jp
�
Zebrack(eu.kanade.tachiyomi.extension.ja.zebrack�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.zebrack-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.zebrack.png"1.4(21.4.18B=���ݴ�ƮAZebrackja"$https://zebrack-comic.shueisha.co.jp
�
Zenon&eu.kanade.tachiyomi.extension.ja.zenon�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.zenon-v1.4.9.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.zenon.png"1.4(	21.4.9B.�����ǋ�JZenonja"https://comic-zenon.com
�
Zerosum Online.eu.kanade.tachiyomi.extension.ja.zerosumonline�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ja.zerosumonline-v1.4.1.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ja.zerosumonline.png"1.4(21.4.1B9��������vZerosum Onlineja"https://zerosumonline.com
�
	BlackToon*eu.kanade.tachiyomi.extension.ko.blacktoon�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ko.blacktoon-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ko.blacktoon.png"1.4(21.4.18B/�Ϫ�ۃ�b	블랙툰ko"https://blacktoon.me
�
Manatoki)eu.kanade.tachiyomi.extension.ko.manatoki�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ko.manatoki-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ko.manatoki.png"1.4(21.4.28B1���Ӈչ�1Manatokiko"https://manatoki552.net
�

Manhwa Raw*eu.kanade.tachiyomi.extension.ko.manhwaraw�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ko.manhwaraw-v1.4.47.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ko.manhwaraw.png"1.4(/21.4.478B0ࡴ�֚��R	ManhwaRawko"https://manhwaraw.com
�
ManyToonClub-eu.kanade.tachiyomi.extension.ko.manytoonclub�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ko.manytoonclub-v1.4.47.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ko.manytoonclub.png"1.4(/21.4.478B3�錛���NManyToonClubko"https://manytoon.club
�
Naver Comic+eu.kanade.tachiyomi.extension.ko.navercomic�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ko.navercomic-v1.4.7.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ko.navercomic.png"1.4(21.4.7B6���ɢ�Naver Webtoonko"https://comic.naver.comBE��������7Naver Webtoon Best Challengeko"https://comic.naver.comB@����ۣ>Naver Webtoon Challengeko"https://comic.naver.com
�
NewToki / ManaToki(eu.kanade.tachiyomi.extension.ko.newtoki�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ko.newtoki-v1.4.33.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ko.newtoki.png"1.4(!21.4.338B1��Վ����#ManaTokiko"https://manatoki469.netB/ۃ�Ӏ觹NewTokiko"https://newtoki469.com
�
NTK$eu.kanade.tachiyomi.extension.ko.ntk�
fhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ko.ntk-v1.4.1.apkthttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ko.ntk.png"1.4(21.4.18B-��Ѵ�Ԝ�
NTK 웹툰ko"https://sbxh1.comB-����析�f
NTK 만화ko"https://sbxh1.comB0����Ϋ�;NTK 동인지ko"https://sbxh1.com
�
RawDEX'eu.kanade.tachiyomi.extension.ko.rawdex�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ko.rawdex-v1.4.53.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ko.rawdex.png"1.4(521.4.538B*���񐾿�nRawDEXko"https://rawdex.net
�
11toon'eu.kanade.tachiyomi.extension.ko.toon11�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ko.toon11-v1.4.2.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ko.toon11.png"1.4(21.4.28B.��������z11toonko"https://www.11toon.com
�
Toonkor(eu.kanade.tachiyomi.extension.ko.toonkor�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ko.toonkor-v1.4.6.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ko.toonkor.png"1.4(21.4.68B,��������[Toonkorko"https://tkor114.com
�
Wolf.com+eu.kanade.tachiyomi.extension.ko.wolfdotcom�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ko.wolfdotcom-v1.4.3.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ko.wolfdotcom.png"1.4(21.4.38B:��������M늑대닷컴 - 웹툰ko"https://wfwf474.comB=��Ь����b늑대닷컴 - 만화책ko"https://wfwf474.comB=�����π�:늑대닷컴 - 포토툰ko"https://wfwf474.com
�
	MangaHoNa*eu.kanade.tachiyomi.extension.pl.mangahona�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pl.mangahona-v1.4.51.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pl.mangahona.png"1.4(321.4.51B/ăի����{	MangaHoNapl"https://mangahona.pl
�
	Akimangá)eu.kanade.tachiyomi.extension.pt.akimanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.akimanga-v1.4.45.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.akimanga.png"1.4(-21.4.458B2���ނ��B	Akimangápt-BR"https://akimanga.com
�
Alone Scanlator/eu.kanade.tachiyomi.extension.pt.alonescanlator�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.alonescanlator-v1.4.45.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.alonescanlator.png"1.4(-21.4.45BA���Ι���ZAlone Scanlatorpt-BR"https://alonescanlator.com.br
�
Amuy%eu.kanade.tachiyomi.extension.pt.amuy�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.amuy-v1.4.53.apkuhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.amuy.png"1.4(521.4.538B5ϳ�ꧨ��HAmuypt-BR"https://apenasmaisumyaoi.com
�
AnimeXNovel,eu.kanade.tachiyomi.extension.pt.animexnovel�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.animexnovel-v1.4.18.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.animexnovel.png"1.4(21.4.18B;�㪝���2AnimeXNovelpt-BR"https://www.animexnovel.com
�
	Capitoons*eu.kanade.tachiyomi.extension.pt.apecomics�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.apecomics-v1.4.47.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.apecomics.png"1.4(/21.4.47B3��������>	Capitoonspt-BR"https://capitoons.com
�
Apenas Uma Fã,eu.kanade.tachiyomi.extension.pt.apenasumafa�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.apenasumafa-v1.4.13.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.apenasumafa.png"1.4(21.4.13BD��������_Apenas Uma Fãpt-BR"!https://apenasuma-fa.blogspot.com
�
Argos Comics,eu.kanade.tachiyomi.extension.pt.argoscomics�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.argoscomics-v1.4.55.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.argoscomics.png"1.4(721.4.55B5��������%Argos Comicspt-BR"https://aniargos.com
�
Argos Hentai,eu.kanade.tachiyomi.extension.pt.argoshentai�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.argoshentai-v1.4.45.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.argoshentai.png"1.4(-21.4.458B8қ������8Argos Hentaipt-BR"https://argoshentai.xyz
�

Argos Scan*eu.kanade.tachiyomi.extension.pt.argosscan�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.argosscan-v1.4.28.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.argosscan.png"1.4(21.4.28B9��������e
Argos Scanpt-BR"https://argoscomics.online
�
Arthur Scan+eu.kanade.tachiyomi.extension.pt.arthurscan�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.arthurscan-v1.4.57.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.arthurscan.png"1.4(921.4.57B6�����ޤ�Arthur Scanpt-BR"https://arthurscan.xyz
�

Astratoons+eu.kanade.tachiyomi.extension.pt.astratoons�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.astratoons-v1.4.9.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.astratoons.png"1.4(	21.4.9B9����ۮ��
Astratoonspt-BR"https://new.astratoons.com
�
	Atemporal*eu.kanade.tachiyomi.extension.pt.atemporal�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.atemporal-v1.4.47.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.atemporal.png"1.4(/21.4.47B5��Ĳ����=	Atemporalpt-BR"https://atemporal.cloud
�

Azuretoons+eu.kanade.tachiyomi.extension.pt.azuretoons�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.azuretoons-v1.4.3.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.azuretoons.png"1.4(21.4.38B5�������W
Azuretoonspt-BR"https://azuretoons.com
�
Bakai&eu.kanade.tachiyomi.extension.pt.bakai�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.bakai-v1.4.16.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.bakai.png"1.4(21.4.168B+���ߙ���Bakaipt-BR"https://bakai.org
�
Blackout Comics/eu.kanade.tachiyomi.extension.pt.blackoutcomics�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.blackoutcomics-v1.4.9.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.blackoutcomics.png"1.4(	21.4.98B>������ȉDBlackout Comicspt-BR"https://blackoutcomics.com
�

Bladetoons+eu.kanade.tachiyomi.extension.pt.bladetoons�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.bladetoons-v1.4.2.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.bladetoons.png"1.4(21.4.2B5��������j
Bladetoonspt-BR"https://bladetoons.com
�
Boruto Explorer/eu.kanade.tachiyomi.extension.pt.borutoexplorer�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.borutoexplorer-v1.4.52.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.borutoexplorer.png"1.4(421.4.52BH�������)Boruto Explorerpt-BR"$https://leitor.borutoexplorer.com.br
�
Brasil Hentai-eu.kanade.tachiyomi.extension.pt.brasilhentai�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.brasilhentai-v1.4.5.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.brasilhentai.png"1.4(21.4.58B:��oBrasil Hentaipt-BR"https://brasilhentai.com
�

BR Mangás,eu.kanade.tachiyomi.extension.pt.brmangastop�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.brmangastop-v1.4.45.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.brmangastop.png"1.4(-21.4.458B3������Թ7
BR Mangáspt-BR"https://brmangas.top
�
Bruttal(eu.kanade.tachiyomi.extension.pt.bruttal�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.bruttal-v1.4.7.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.bruttal.png"1.4(21.4.7BD���ᣓ��Bruttalpt-BR"(https://originals.omelete.com.br/bruttal
�
BR Yaoi'eu.kanade.tachiyomi.extension.pt.bryaoi�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.bryaoi-v1.4.2.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.bryaoi.png"1.4(21.4.28B.�����0BR Yaoipt-BR"https://bryaoi.com
�
Café com Yaoi,eu.kanade.tachiyomi.extension.pt.cafecomyaoi�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.cafecomyaoi-v1.4.53.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.cafecomyaoi.png"1.4(521.4.538B=��ˁ�և�Café com Yaoipt-BR"https://cafecomyaoi.com.br
�
Cerise Scan,eu.kanade.tachiyomi.extension.pt.cerisescans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.cerisescans-v1.4.61.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.cerisescans.png"1.4(=21.4.618B6�������`Cerise Scanpt-BR"https://loverstoon.com
�

Coven Scan*eu.kanade.tachiyomi.extension.pt.covenscan�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.covenscan-v1.4.52.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.covenscan.png"1.4(421.4.528B;���ԽФ�M
Coven Scanpt-BR"https://covendasbruxonas.com
�

Dango Scan*eu.kanade.tachiyomi.extension.pt.dangoscan�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.dangoscan-v1.4.9.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.dangoscan.png"1.4(	21.4.9B7��۲��I
Dango Scanpt-BR"https://dangoscan.com.br
�
Dianxia Traduções1eu.kanade.tachiyomi.extension.pt.dianxiatraducoes�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.dianxiatraducoes-v1.4.45.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.dianxiatraducoes.png"1.4(-21.4.458B@������ҕnDianxia Traduçõespt-BR"https://dianxiatrads.com
�

Dream Scan*eu.kanade.tachiyomi.extension.pt.dreamscan�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.dreamscan-v1.4.52.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.dreamscan.png"1.4(421.4.52B8�������
Dream Scanpt-BR"https://fairydream.com.br
�
	Ego Toons)eu.kanade.tachiyomi.extension.pt.egotoons�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.egotoons-v1.4.8.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.egotoons.png"1.4(21.4.88B6�����٩�A	Ego Toonspt-BR"https://www.egotoons.com
�
Ero Sect(eu.kanade.tachiyomi.extension.pt.erosect�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.erosect-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.erosect.png"1.4(21.4.18B/�ਬ����?EroSectpt-BR"https://erosect.xyz
�
Euphoria Scan-eu.kanade.tachiyomi.extension.pt.euphoriascan�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.euphoriascan-v1.4.50.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.euphoriascan.png"1.4(221.4.508B:�����ӛ�SEuphoria Scanpt-BR"https://euphoriascan.com
�
ExHentai.net.br.eu.kanade.tachiyomi.extension.pt.exhentainetbr�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.exhentainetbr-v1.4.4.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.exhentainetbr.png"1.4(21.4.48B;ө�맇��ExHentai.net.brpt-BR"https://exhentai.net.br
�
Fênix Manhwas-eu.kanade.tachiyomi.extension.pt.fenixmanhwas�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.fenixmanhwas-v1.4.45.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.fenixmanhwas.png"1.4(-21.4.45B8��唓���Fênix Manhwaspt-BR"https://fenixscan.xyz
�
Fenix Project-eu.kanade.tachiyomi.extension.pt.fenixproject�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.fenixproject-v1.4.52.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.fenixproject.png"1.4(421.4.528B;���Ʊ���zFenix Projectpt-BR"https://fenixproject.site
�
Fleur Blanche-eu.kanade.tachiyomi.extension.pt.fleurblanche�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.fleurblanche-v1.4.55.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.fleurblanche.png"1.4(721.4.558B6ҩ���&Fleur Blanchept-BR"https://fbsquadx.com
�
FlowerManga.net,eu.kanade.tachiyomi.extension.pt.flowermanga�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.flowermanga-v1.4.54.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.flowermanga.png"1.4(621.4.548B<��ؾ����!FlowerManga.netpt-BR"https://flowermangas.net
�
GALAX Scans/eu.kanade.tachiyomi.extension.pt.galaxscanlator�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.galaxscanlator-v1.4.14.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.galaxscanlator.png"1.4(21.4.148BC������MGALAX Scanspt-BR"#https://galaxscanlator.blogspot.com
�
Geass Comics,eu.kanade.tachiyomi.extension.pt.geasscomics�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.geasscomics-v1.4.4.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.geasscomics.png"1.4(21.4.48B8���嚧��lGeass Comicspt-BR"https://geasscomics.xyz
�

Ghost Scan*eu.kanade.tachiyomi.extension.pt.ghostscan�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.ghostscan-v1.4.52.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.ghostscan.png"1.4(421.4.528B4����ؾ��
Ghost Scanpt-BR"https://ghostscan.xyz
�
Goof Fansub+eu.kanade.tachiyomi.extension.pt.gooffansub�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.gooffansub-v1.4.45.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.gooffansub.png"1.4(-21.4.458B6ŏ켎���OGoof Fansubpt-BR"https://gooffansub.com
�
Hanmokku Scan-eu.kanade.tachiyomi.extension.pt.hanmokkuscan�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.hanmokkuscan-v1.4.13.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.hanmokkuscan.png"1.4(21.4.138BC��ݑײ�� Hanmokku Scanpt-BR"!https://hanmokkuscan.blogspot.com
�
Hentai Season-eu.kanade.tachiyomi.extension.pt.hentaiseason�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.hentaiseason-v1.4.7.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.hentaiseason.png"1.4(21.4.78B8�����Hentai Seasonpt-BR"https://hentaiseason.com
�
Hentai Teca+eu.kanade.tachiyomi.extension.pt.hentaiteca�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.hentaiteca-v1.4.48.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.hentaiteca.png"1.4(021.4.488B6���Գ��OHentai Tecapt-BR"https://hentaiteca.net
�
Hentai Tokyo,eu.kanade.tachiyomi.extension.pt.hentaitokyo�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.hentaitokyo-v1.4.7.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.hentaitokyo.png"1.4(21.4.78B8󪆌�ֆ�aHentai Tokyopt-BR"https://hentaitokyo.net
�
Hianato Scan,eu.kanade.tachiyomi.extension.pt.hianatoscan�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.hianatoscan-v1.4.45.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.hianatoscan.png"1.4(-21.4.45B8��һ���Hianato Scanpt-BR"https://hianatoscan.top
�
	HipercooL*eu.kanade.tachiyomi.extension.pt.hipercool�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.hipercool-v1.4.53.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.hipercool.png"1.4(521.4.538B0��̮���!	HipercooLpt-BR"https://hiper.cool
�
Hot Cabaret Scan/eu.kanade.tachiyomi.extension.pt.hotcabaretscan�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.hotcabaretscan-v1.4.51.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.hotcabaretscan.png"1.4(321.4.518B?⿈�ݪ��yHot Cabaret Scanpt-BR"https://hotcabaretscan.com
�
HQ Now!&eu.kanade.tachiyomi.extension.pt.hqnow�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.hqnow-v1.4.8.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.hqnow.png"1.4(21.4.8B2�������HQ Now!pt-BR"https://www.hq-now.com
�
Hunters Scans-eu.kanade.tachiyomi.extension.pt.huntersscans�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.huntersscans-v1.4.61.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.huntersscans.png"1.4(=21.4.618B8�����˘�eHunters Scanpt-BR"https://readhunters.xyz
�
Sagrado Império da Britannia3eu.kanade.tachiyomi.extension.pt.imperiodabritannia�
vhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.imperiodabritannia-v1.4.55.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.imperiodabritannia.png"1.4(721.4.55BP�Ā�����fSagrado Império da Britanniapt-BR"https://imperiodabritannia.net
�
Neroxus-eu.kanade.tachiyomi.extension.pt.imperioscans�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.imperioscans-v1.4.48.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.imperioscans.png"1.4(021.4.488B2��Ж褅�Neroxuspt-BR"https://neroxus.com.br
�
InfinyxScan,eu.kanade.tachiyomi.extension.pt.infinyxscan�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.infinyxscan-v1.4.45.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.infinyxscan.png"1.4(-21.4.45B9�㝇φ��@InfinyxScanpt-BR"https://infinyxscan.cloud
�
Inkapk'eu.kanade.tachiyomi.extension.pt.inkapk�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.inkapk-v1.4.53.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.inkapk.png"1.4(521.4.538B-��ߣȡ�vInkapkpt-BR"https://inkapk.net
�
Kairos Toons,eu.kanade.tachiyomi.extension.pt.kairostoons�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.kairostoons-v1.4.3.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.kairostoons.png"1.4(21.4.3B8���َ��.Kairos Toonspt-BR"https://kairostoons.net
�
Kakusei Project/eu.kanade.tachiyomi.extension.pt.kakuseiproject�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.kakuseiproject-v1.4.54.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.kakuseiproject.png"1.4(621.4.54B>����˄�<Kakusei Projectpt-BR"https://kakuseiproject.org
�
Kami Sama Explorer1eu.kanade.tachiyomi.extension.pt.kamisamaexplorer�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.kamisamaexplorer-v1.4.53.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.kamisamaexplorer.png"1.4(521.4.53BE죥�ܜ��HKami Sama Explorerpt-BR"https://leitor.kamisama.com.br
�
	Kami Toon)eu.kanade.tachiyomi.extension.pt.kamitoon�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.kamitoon-v1.4.45.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.kamitoon.png"1.4(-21.4.458B5��ٳ��6	Kami Toonpt-BR"https://kamitoon.com.br
�

KuroMangas+eu.kanade.tachiyomi.extension.pt.kuromangas�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.kuromangas-v1.4.5.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.kuromangas.png"1.4(21.4.5B:������ڂ
KuroMangaspt-BR"https://beta.kuromangas.com
�
Leitor de Mangá.eu.kanade.tachiyomi.extension.pt.leitordemanga�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.leitordemanga-v1.4.47.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.leitordemanga.png"1.4(/21.4.47B>�ŷ�߳��'Leitor de Mangápt-BR"https://leitordemanga.com
�
Leitor de Mangas/eu.kanade.tachiyomi.extension.pt.leitordemangas�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.leitordemangas-v1.4.50.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.leitordemangas.png"1.4(221.4.508B?�ԭ𸌝�[Leitor de Mangaspt-BR"https://leitordemangas.com
�
Leitura Manga-eu.kanade.tachiyomi.extension.pt.leituramanga�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.leituramanga-v1.4.5.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.leituramanga.png"1.4(21.4.58B;��������Leitura Mangápt-BR"https://leituramanga.net
�
Ler 999'eu.kanade.tachiyomi.extension.pt.ler999�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.ler999-v1.4.14.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.ler999.png"1.4(21.4.14B6����ɉLer 999pt-BR"https://ler999.blogspot.com
�

Ler Hentai*eu.kanade.tachiyomi.extension.pt.lerhentai�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.lerhentai-v1.4.45.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.lerhentai.png"1.4(-21.4.458B4�͵�����
Ler Hentaipt-BR"https://lerhentai.com
�

Ler Mangas*eu.kanade.tachiyomi.extension.pt.lermangas�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.lermangas-v1.4.51.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.lermangas.png"1.4(321.4.518B3��������
Ler Mangaspt-BR"https://lermangas.me
�
	Ler Toons)eu.kanade.tachiyomi.extension.pt.lertoons�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.lertoons-v1.4.4.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.lertoons.png"1.4(21.4.48B8ڙ�㏂�	Ler Toonspt-BR"https://www.readmangas.org
�
Lich Mangas+eu.kanade.tachiyomi.extension.pt.lichmangas�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.lichmangas-v1.4.45.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.lichmangas.png"1.4(-21.4.458B6��ƪ���nLich Mangaspt-BR"https://lichmangas.com
�

Limbo Scan*eu.kanade.tachiyomi.extension.pt.limboscan�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.limboscan-v1.4.51.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.limboscan.png"1.4(321.4.518B7�����֧�

Limbo Scanpt-BR"https://limboscan.com.br
�
Limited Time Project3eu.kanade.tachiyomi.extension.pt.limitedtimeproject�
vhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.limitedtimeproject-v1.4.46.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.limitedtimeproject.png"1.4(.21.4.468BG��������&Limited Time Projectpt-BR"https://limitedtimeproject.com
�
Little Tyrant-eu.kanade.tachiyomi.extension.pt.littletyrant�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.littletyrant-v1.4.57.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.littletyrant.png"1.4(921.4.578B9ϖ������CLittle Tyrantpt-BR"https://tiraninha.world
�
Lycan Toons+eu.kanade.tachiyomi.extension.pt.lycantoons�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.lycantoons-v1.4.3.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.lycantoons.png"1.4(21.4.3B6��ռ��~Lycan Toonspt-BR"https://lycantoons.com
�
	Maid Scan)eu.kanade.tachiyomi.extension.pt.maidscan�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.maidscan-v1.4.61.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.maidscan.png"1.4(=21.4.618B5�ƙ�Ⅵ�i	Maid Scanpt-BR"https://empreguetes.wtf
�
Maid Secret+eu.kanade.tachiyomi.extension.pt.maidsecret�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.maidsecret-v1.4.46.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.maidsecret.png"1.4(.21.4.468B6���Ϥҁ�QMaid Secretpt-BR"https://maidsecret.com
�
Manga BR(eu.kanade.tachiyomi.extension.pt.mangabr�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.mangabr-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.mangabr.png"1.4(21.4.18B0�ۙɩ���dManga BRpt-BR"https://mangabr.net
�
	MangaDash*eu.kanade.tachiyomi.extension.pt.mangadash�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.mangadash-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.mangadash.png"1.4(21.4.18B3�雉����?	MangaDashpt-BR"https://mangadash.net
�

Manga Flix*eu.kanade.tachiyomi.extension.pt.mangaflix�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.mangaflix-v1.4.4.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.mangaflix.png"1.4(21.4.48B3�񡜴���^	MangaFlixpt-BR"https://mangaflix.net
�
Manga Livre+eu.kanade.tachiyomi.extension.pt.mangalivre�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.mangalivre-v1.4.64.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.mangalivre.png"1.4(@21.4.64B5ؕ�܁��'Manga Livrept-BR"https://toonlivre.net
�
Manga Livre Blog/eu.kanade.tachiyomi.extension.pt.mangalivreblog�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.mangalivreblog-v1.4.2.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.mangalivreblog.png"1.4(21.4.2B<܇���ٕManga Livre Blogpt-BR"https://mangalivre.blog
�
Manga Livre.to-eu.kanade.tachiyomi.extension.pt.mangalivreto�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.mangalivreto-v1.4.52.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.mangalivreto.png"1.4(421.4.528B8Ҁ�����Manga Livre.topt-BR"https://mangalivre.to
�
Mangá Mania+eu.kanade.tachiyomi.extension.pt.mangamania�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.mangamania-v1.4.45.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.mangamania.png"1.4(-21.4.458B:��գ����OMangá Maniapt-BR"https://mangamania.com.br
�
Manga Online,eu.kanade.tachiyomi.extension.pt.mangaonline�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.mangaonline-v1.4.53.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.mangaonline.png"1.4(521.4.53B8��ʿ����6Manga Onlinept-BR"https://mangaonline.red
�
Manga Online Blog0eu.kanade.tachiyomi.extension.pt.mangaonlineblog�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.mangaonlineblog-v1.4.45.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.mangaonlineblog.png"1.4(-21.4.45B>�����㎻2Manga Online Blogpt-BR"https://mangaonline.blog
�
Mangas Brasuka.eu.kanade.tachiyomi.extension.pt.mangasbrasuka�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.mangasbrasuka-v1.4.52.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.mangasbrasuka.png"1.4(421.4.528B?��ߔ�ӽ�Mangas Brasukapt-BR"https://mangasbrasuka.com.br
�

Manga Stop*eu.kanade.tachiyomi.extension.pt.mangastop�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.mangastop-v1.4.43.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.mangastop.png"1.4(+21.4.43B4�ഇ����
Manga Stoppt-BR"https://mangastop.net
�
Mango Toons+eu.kanade.tachiyomi.extension.pt.mangotoons�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.mangotoons-v1.4.8.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.mangotoons.png"1.4(21.4.8B6�������|Mango Toonspt-BR"https://mangotoons.com
�
	Manhastro*eu.kanade.tachiyomi.extension.pt.manhastro�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.manhastro-v1.4.58.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.manhastro.png"1.4(:21.4.588B3��ջ�ʍG	Manhastropt-BR"https://manhastro.net
�
Mediocre Toons.eu.kanade.tachiyomi.extension.pt.mediocretoons�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.mediocretoons-v1.4.19.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.mediocretoons.png"1.4(21.4.198B;����ȍ��^Mediocre Toonspt-BR"https://mediocrescan.com
�
MiniTwo Scan,eu.kanade.tachiyomi.extension.pt.minitwoscan�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.minitwoscan-v1.4.51.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.minitwoscan.png"1.4(321.4.518B8�������|MiniTwo Scanpt-BR"https://minitwoscan.com
�
Monsure(eu.kanade.tachiyomi.extension.pt.monsure�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.monsure-v1.4.51.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.monsure.png"1.4(321.4.518B1ڬ������	Monsurept-BR"https://monsuresu.com
�
	Monte Tai)eu.kanade.tachiyomi.extension.pt.montetai�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.montetai-v1.4.53.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.montetai.png"1.4(521.4.53B;��׃�Ќ�g	Monte Taipt-BR"https://montetaiscanlator.xyz
�
	MR Tenzus)eu.kanade.tachiyomi.extension.pt.mrtenzus�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.mrtenzus-v1.4.51.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.mrtenzus.png"1.4(321.4.518B2�њ⇴�;	MR Tenzuspt-BR"https://mrtenzus.com
�
MR Yaoi'eu.kanade.tachiyomi.extension.pt.mryaoi�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.mryaoi-v1.4.45.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.mryaoi.png"1.4(-21.4.458B0Љ�¿���MR Yaoipt-BR"https://mrtenzus.com
�
Mugiwaras Oficial1eu.kanade.tachiyomi.extension.pt.mugiwarasoficial�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.mugiwarasoficial-v1.4.52.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.mugiwarasoficial.png"1.4(421.4.52BB��������Mugiwaras Oficialpt-BR"https://mugiwarasoficial.com
�
Muito Hentai,eu.kanade.tachiyomi.extension.pt.muitohentai�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.muitohentai-v1.4.4.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.muitohentai.png"1.4(21.4.48B<�������Muito Hentaipt-BR"https://www.muitohentai.com
�
Mundo Hentai,eu.kanade.tachiyomi.extension.pt.mundohentai�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.mundohentai-v1.4.10.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.mundohentai.png"1.4(
21.4.108B?��������Mundo Hentaipt-BR"https://mundohentaioficial.com
�
Mystic Moon+eu.kanade.tachiyomi.extension.pt.mysticmoon�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.mysticmoon-v1.4.46.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.mysticmoon.png"1.4(.21.4.46B:���޼��_Mystic Moonpt-BR"https://mysticmagic.com.br
�
Nazarick Scan-eu.kanade.tachiyomi.extension.pt.nazarickscan�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.nazarickscan-v1.4.9.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.nazarickscan.png"1.4(	21.4.9B=�꾘�ѮNazarick Scanpt-BR"https://nazarickscan.com.br
�
Nebulosa Scan-eu.kanade.tachiyomi.extension.pt.nebulosascan�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.nebulosascan-v1.4.51.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.nebulosascan.png"1.4(321.4.518B:�쵯����Nebulosa Scanpt-BR"https://nebulosascan.com
�

Neko Toons*eu.kanade.tachiyomi.extension.pt.nekotoons�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.nekotoons-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.nekotoons.png"1.4(21.4.28B5��������|
Neko Toonspt-BR"https://nekotoons.site
�
	Next Scan)eu.kanade.tachiyomi.extension.pt.nextscan�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.nextscan-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.nextscan.png"1.4(21.4.18B4������¸{	Next Scanpt-BR"https://nextscan.cloud
�

Ninja Scan*eu.kanade.tachiyomi.extension.pt.ninjascan�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.ninjascan-v1.4.53.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.ninjascan.png"1.4(521.4.53B6��������<
Ninja Scanpt-BR"https://ninjacomics.xyz
�
Nocturne Summer/eu.kanade.tachiyomi.extension.pt.nocturnesummer�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.nocturnesummer-v1.4.52.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.nocturnesummer.png"1.4(421.4.528B6��ろ���LNocturne Summerpt-BR"https://nocfsb.com
�
Hanami Heaven,eu.kanade.tachiyomi.extension.pt.noindexscan�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.noindexscan-v1.4.55.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.noindexscan.png"1.4(721.4.558B:������Hanami Heavenpt-BR"https://hanamiheaven.org
�
One Piece TECA-eu.kanade.tachiyomi.extension.pt.onepieceteca�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.onepieceteca-v1.4.45.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.onepieceteca.png"1.4(-21.4.45B;��������tOne Piece TECApt-BR"https://onepieceteca.com
�
Origami Orpheans0eu.kanade.tachiyomi.extension.pt.origamiorpheans�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.origamiorpheans-v1.4.43.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.origamiorpheans.png"1.4(+21.4.438BA����־��8Origami Orpheanspt-BR"https://origami-orpheans.com
�

Osaka Scan*eu.kanade.tachiyomi.extension.pt.osakascan�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.osakascan-v1.4.14.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.osakascan.png"1.4(21.4.148B8˗���ڱ�C
Osaka Scanpt-BR"https://www.osakascan.com
�
Passa Mão Scan-eu.kanade.tachiyomi.extension.pt.passamaoscan�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.passamaoscan-v1.4.45.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.passamaoscan.png"1.4(-21.4.458B<���惧�Passa Mão Scanpt-BR"https://passamaoscan.com
�
	Pink Rosa)eu.kanade.tachiyomi.extension.pt.pinkrosa�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.pinkrosa-v1.4.15.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.pinkrosa.png"1.4(21.4.15B?������˭u	Pink Rosapt-BR"!https://scanpinkrosa.blogspot.com
�
Pink Sea Unicorn/eu.kanade.tachiyomi.extension.pt.pinkseaunicorn�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.pinkseaunicorn-v1.4.52.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.pinkseaunicorn.png"1.4(421.4.528B:����Ƴ�#Pink Sea Unicornpt-BR"https://psunicorn.com
�
Pirulito Rosa-eu.kanade.tachiyomi.extension.pt.pirulitorosa�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.pirulitorosa-v1.4.51.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.pirulitorosa.png"1.4(321.4.518B;������ԇPirulito Rosapt-BR"https://pirulitorosa.site
�
PizzariaScan-eu.kanade.tachiyomi.extension.pt.pizzariascan�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.pizzariascan-v1.4.50.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.pizzariascan.png"1.4(221.4.508B;���ױ���.PizzariaScanpt-BR"https://pizzariacomics.com
�
Pluma Comics,eu.kanade.tachiyomi.extension.pt.plumacomics�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.plumacomics-v1.4.47.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.plumacomics.png"1.4(/21.4.47B:�֪�����4Pluma Comicspt-BR"https://plumacomics.cloud
�
Point Zero Toons/eu.kanade.tachiyomi.extension.pt.pointzerotoons�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.pointzerotoons-v1.4.34.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.pointzerotoons.png"1.4("21.4.34B<��������Point Zero Toonspt-BR"https://kitsuneyako.com
�
Portal Yaoi+eu.kanade.tachiyomi.extension.pt.portalyaoi�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.portalyaoi-v1.4.52.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.portalyaoi.png"1.4(421.4.528B7���Ȍퟻ-Portal Yaoipt-BR"https://lerboyslove.com
�
Seita Celestial,eu.kanade.tachiyomi.extension.pt.prismascans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.prismascans-v1.4.50.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.prismascans.png"1.4(221.4.50B>�����ἭqSeita Celestialpt-BR"https://seitacelestial.com
�
	Lura Toon+eu.kanade.tachiyomi.extension.pt.randomscan�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.randomscan-v1.4.59.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.randomscan.png"1.4(;21.4.59B3�㣿�	Lura Toonpt-BR"https://luratoons.net
�
NoxManga)eu.kanade.tachiyomi.extension.pt.remangas�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.remangas-v1.4.53.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.remangas.png"1.4(521.4.53B1�Ɵ����gNoxMangapt-BR"https://noxtoons.com
�
Revistas e Quadrinhos4eu.kanade.tachiyomi.extension.pt.revistasequadrinhos�
vhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.revistasequadrinhos-v1.4.1.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.revistasequadrinhos.png"1.4(21.4.18BF斄����Revistas e Quadrinhospt"https://revistasequadrinhos.com
�
RF Dragon Scan-eu.kanade.tachiyomi.extension.pt.rfdragonscan�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.rfdragonscan-v1.4.12.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.rfdragonscan.png"1.4(21.4.12B;�������0RF Dragon Scanpt-BR"https://rfdragonscan.net
�

Risentoons+eu.kanade.tachiyomi.extension.pt.risentoons�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.risentoons-v1.4.2.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.risentoons.png"1.4(21.4.2B5��셪ס�D
Risentoonspt-BR"https://risentoons.xyz
�
Roxinha(eu.kanade.tachiyomi.extension.pt.roxinha�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.roxinha-v1.4.2.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.roxinha.png"1.4(21.4.28B2�ʫ󻓥�6Roxinhapt-BR"https://roxinha.online
�
Saikai Scan+eu.kanade.tachiyomi.extension.pt.saikaiscan�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.saikaiscan-v1.4.13.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.saikaiscan.png"1.4(21.4.13B7��������Saikai Scanpt-BR"https://housesaikai.net
�
Sakura Mangás-eu.kanade.tachiyomi.extension.pt.sakuramangas�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.sakuramangas-v1.4.4.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.sakuramangas.png"1.4(21.4.48B;������ISakura Mangáspt-BR"https://sakuramangas.org
�
Shindai Scan,eu.kanade.tachiyomi.extension.pt.shindaiscan�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.shindaiscan-v1.4.45.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.shindaiscan.png"1.4(-21.4.45B7��������OShindai Scanpt-BR"https://shindai.com.br
�
Shirai Scans,eu.kanade.tachiyomi.extension.pt.shiraiscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.shiraiscans-v1.4.1.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.shiraiscans.png"1.4(21.4.18B8Ķ��ƿÎtShirai Scanspt-BR"https://shiraixis.space
�
Silence Scan,eu.kanade.tachiyomi.extension.pt.silencescan�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.silencescan-v1.4.36.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.silencescan.png"1.4($21.4.368B;�ܛ���·?Silence Scanpt-BR"https://silencescan.com.br
�
Nexus Toons-eu.kanade.tachiyomi.extension.pt.spectralscan�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.spectralscan-v1.4.62.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.spectralscan.png"1.4(>21.4.628B4��������INexus Toonspt-BR"https://nx-toons.xyz
�
Yomu Comics-eu.kanade.tachiyomi.extension.pt.sssscanlator�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.sssscanlator-v1.4.49.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.sssscanlator.png"1.4(121.4.498B3�̬�����Yomu Comicspt-BR"https://yomu.com.br
�
Starlight Scan.eu.kanade.tachiyomi.extension.pt.starlightscan�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.starlightscan-v1.4.33.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.starlightscan.png"1.4(!21.4.338B<�÷���nStarlight Scanpt-BR"https://starligthscan.com
�
Sussy Toons*eu.kanade.tachiyomi.extension.pt.sussyscan�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.sussyscan-v1.4.63.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.sussyscan.png"1.4(?21.4.638B:����Ф��`Sussy Toonspt-BR"https://www.sussytoons.wtf
�
Sweet Time Scan.eu.kanade.tachiyomi.extension.pt.sweettimescan�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.sweettimescan-v1.4.47.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.sweettimescan.png"1.4(/21.4.47B9��������&Sweet Time Scanpt-BR"https://sweetscan.net
�
TaimuMangas,eu.kanade.tachiyomi.extension.pt.taimumangas�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.taimumangas-v1.4.2.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.taimumangas.png"1.4(21.4.28B=�������{Taimu Mangaspt-BR"https://beta.taimumangas.com
�
Taiyō&eu.kanade.tachiyomi.extension.pt.taiyo�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.taiyo-v1.4.11.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.taiyo.png"1.4(21.4.118B,���㗄�fTaiyōpt-BR"https://taiyo.moe
�
Tankou Hentai-eu.kanade.tachiyomi.extension.pt.tankouhentai�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.tankouhentai-v1.4.51.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.tankouhentai.png"1.4(321.4.518B:����Т��Tankou Hentaipt-BR"https://tankouhentai.com
�
Tao Sect(eu.kanade.tachiyomi.extension.pt.taosect�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.taosect-v1.4.22.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.taosect.png"1.4(21.4.228B0˿�����
Tao Sectpt-BR"https://taosect.com
�
Tatakae Scan,eu.kanade.tachiyomi.extension.pt.tatakaescan�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.tatakaescan-v1.4.53.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.tatakaescan.png"1.4(521.4.538B8��ۊБڃjTatakae Scanpt-BR"https://tatakaescan.com
�
Temaki mangás-eu.kanade.tachiyomi.extension.pt.temakimangas�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.temakimangas-v1.4.13.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.temakimangas.png"1.4(21.4.138BD����ϓ��	Temaki mangáspt-BR"!https://temakimangas.blogspot.com
�

Tia Manhwa*eu.kanade.tachiyomi.extension.pt.tiamanhwa�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.tiamanhwa-v1.4.53.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.tiamanhwa.png"1.4(521.4.538B4��Ѫ����z
Tia Manhwapt-BR"https://tiamanhwa.com
�
ToonBr'eu.kanade.tachiyomi.extension.pt.toonbr�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.toonbr-v1.4.3.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.toonbr.png"1.4(21.4.3B2܈�����ToonBrpt-BR"https://beta.toonbr.com
�
Traduções do Lipe0eu.kanade.tachiyomi.extension.pt.traducoesdolipe�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.traducoesdolipe-v1.4.14.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.traducoesdolipe.png"1.4(21.4.14BL������2Traduções do Lipept-BR"$https://traducoesdolipe.blogspot.com
�
Tsundoku Traduções2eu.kanade.tachiyomi.extension.pt.tsundokutraducoes�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.tsundokutraducoes-v1.4.42.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.tsundokutraducoes.png"1.4(*21.4.428B@����Tsundoku Traduçõespt-BR"https://tsundoku.com.br
�
Universo Hentai/eu.kanade.tachiyomi.extension.pt.universohentai�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.universohentai-v1.4.7.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.universohentai.png"1.4(21.4.78B>é������:Universo Hentaipt-BR"https://universohentai.com
�
	Vegitoons*eu.kanade.tachiyomi.extension.pt.vegitoons�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.vegitoons-v1.4.10.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.vegitoons.png"1.4(
21.4.108B5ʝ�և݇�b	Vegitoonspt-BR"https://vegitoons.black
�
Verdinha)eu.kanade.tachiyomi.extension.pt.verdinha�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.verdinha-v1.4.10.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.verdinha.png"1.4(
21.4.108B1����ݲ��/Verdinhapt-BR"https://verdinha.wtf
�
	Wind Scan)eu.kanade.tachiyomi.extension.pt.windscan�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.windscan-v1.4.46.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.windscan.png"1.4(.21.4.468B2�������q	Wind Scanpt-BR"https://windscan.xyz
�
Winter Scan+eu.kanade.tachiyomi.extension.pt.winterscan�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.winterscan-v1.4.49.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.winterscan.png"1.4(121.4.49B6ɰ������Winter Scanpt-BR"https://winterscan.com
�

Winter Sun*eu.kanade.tachiyomi.extension.pt.wintersun�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.wintersun-v1.4.45.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.wintersun.png"1.4(-21.4.458B8ۑ������l
Winter Sunpt-BR"https://wintersunscan.xyz
�
Wolftoon)eu.kanade.tachiyomi.extension.pt.wolftoon�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.wolftoon-v1.4.4.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.wolftoon.png"1.4(21.4.4B9�����З�%Wolftoonpt-BR"https://wolftoon.lovable.app
�
Xs Scan'eu.kanade.tachiyomi.extension.pt.xsscan�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.xsscan-v1.4.45.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.xsscan.png"1.4(-21.4.45B.������ۘpXs Scanpt-BR"https://xsscan.xyz
�
XXX Yaoi(eu.kanade.tachiyomi.extension.pt.xxxyaoi�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.xxxyaoi-v1.4.52.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.xxxyaoi.png"1.4(421.4.528B/����ަ��"XXX Yaoipt-BR"https://3xyaoi.com
�
Yaoi Fan Club,eu.kanade.tachiyomi.extension.pt.yaoifanclub�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.yaoifanclub-v1.4.14.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.yaoifanclub.png"1.4(21.4.148B=����ԎƋ2Yaoi Fan Clubpt-BR"https://www.yaoifanclub.com
�
Yomu Mangás+eu.kanade.tachiyomi.extension.pt.yomumangas�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.yomumangas-v1.4.5.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.yomumangas.png"1.4(21.4.58B7ֆۏ����Yomu Mangáspt-BR"https://yomumangas.com
�
Yugen Mangás,eu.kanade.tachiyomi.extension.pt.yugenmangas�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.yugenmangas-v1.4.51.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.yugenmangas.png"1.4(321.4.51BC��������{Yugen Mangáspt-BR"!https://yugenmangasbr.dxtg.online
�
Yuri on Air*eu.kanade.tachiyomi.extension.pt.yuriverso�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.yuriverso-v1.4.55.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.yuriverso.png"1.4(721.4.558B5��Ⱥ���>Yuri on Airpt-BR"https://yurionair.top
�
Yushuke Mangas.eu.kanade.tachiyomi.extension.pt.yushukemangas�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.yushukemangas-v1.4.8.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.yushukemangas.png"1.4(21.4.8B@ӗ���Ț�5Yushuke Mangaspt-BR"https://new.yushukemangas.com
�
ZettaHQ(eu.kanade.tachiyomi.extension.pt.zettahq�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-pt.zettahq-v1.4.3.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.pt.zettahq.png"1.4(21.4.38B/����λ�@ZettaHQpt-BR"https://zettahq.com
�
AComics(eu.kanade.tachiyomi.extension.ru.acomics�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.acomics-v1.4.8.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.acomics.png"1.4(21.4.88B+������ưAComicsru"https://acomics.ru
�
	AllHentai*eu.kanade.tachiyomi.extension.ru.allhentai�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.allhentai-v1.4.65.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.allhentai.png"1.4(A21.4.658B3��㡅�	AllHentairu"https://20.allhen.online
�
Com-X%eu.kanade.tachiyomi.extension.ru.comx�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.comx-v1.4.39.apkuhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.comx.png"1.4('21.4.39B,�ݘ��Е�Com-Xru"https://ru.com-x.life
�
Desu%eu.kanade.tachiyomi.extension.ru.desu�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.desu-v1.4.33.apkuhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.desu.png"1.4(!21.4.338B&ᵒ����\Desuru"https://desu.uno
�
HenChan(eu.kanade.tachiyomi.extension.ru.henchan�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.henchan-v1.4.47.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.henchan.png"1.4(/21.4.478B4�����Ŏ�LHenChanru"https://xxl.hentaichan.live
�
	HentaiLib*eu.kanade.tachiyomi.extension.ru.hentailib�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.hentailib-v1.4.62.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.hentailib.png"1.4(>21.4.628B/�����؟�Y	HentaiLibru"https://hentailib.me
�
InkStory)eu.kanade.tachiyomi.extension.ru.inkstory�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.inkstory-v1.4.3.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.inkstory.png"1.4(21.4.38B.��������InkStoryru"https://inkstory.net
�
	MangaBuff*eu.kanade.tachiyomi.extension.ru.mangabuff�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.mangabuff-v1.4.5.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.mangabuff.png"1.4(21.4.58B/�ı����7	MangaBuffru"https://mangabuff.ru
�
	MangaChan*eu.kanade.tachiyomi.extension.ru.mangachan�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.mangachan-v1.4.22.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.mangachan.png"1.4(21.4.228B+	MangaChanru"https://im.manga-chan.me
�
	MangaClub*eu.kanade.tachiyomi.extension.ru.mangaclub�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.mangaclub-v1.4.12.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.mangaclub.png"1.4(21.4.12B/�ッ���U	MangaClubru"https://mangaclub.ru
�
Mangahub)eu.kanade.tachiyomi.extension.ru.mangahub�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.mangahub-v1.4.23.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.mangahub.png"1.4(21.4.238B-И���Ʌ�wMangahubru"https://mangahub.ru
�
MangaLib)eu.kanade.tachiyomi.extension.ru.mangalib�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.mangalib-v1.4.117.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.mangalib.png"1.4(u21.4.1178B-ա��ﯳ�TMangaLibru"https://mangalib.me
�
Manga Mammy+eu.kanade.tachiyomi.extension.ru.mangamammy�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.mangamammy-v1.4.45.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.mangamammy.png"1.4(-21.4.458B2��ߛ����Manga Mammyru"https://mangamammy.ru
�
MangaMen)eu.kanade.tachiyomi.extension.ru.mangamen�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.mangamen-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.mangamen.png"1.4(21.4.2B.�ګ��항MangaMenru"https://mangamen.com
�

MangaPoisk+eu.kanade.tachiyomi.extension.ru.mangapoisk�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.mangapoisk-v1.4.14.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.mangapoisk.png"1.4(21.4.148B-��������8
MangaPoiskru"https://mangap.ru
�
	Manga-shi)eu.kanade.tachiyomi.extension.ru.mangashi�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.mangashi-v1.4.52.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.mangashi.png"1.4(421.4.528B0��޾늚
	Manga-shiru"https://manga-shi.org
�
	MintManga*eu.kanade.tachiyomi.extension.ru.mintmanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.mintmanga-v1.4.87.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.mintmanga.png"1.4(W21.4.878B*	MintMangaru"https://2.mintmanga.one
�

MultiManga+eu.kanade.tachiyomi.extension.ru.multimanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.multimanga-v1.4.2.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.multimanga.png"1.4(21.4.28B5�ט��먺1
MultiMangaru"https://multi-manga.today
�
NineGrid)eu.kanade.tachiyomi.extension.ru.ninegrid�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.ninegrid-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.ninegrid.png"1.4(21.4.2B*��͈˷��PNineGridru"https://9grid.cc
�
	Nude-Moon)eu.kanade.tachiyomi.extension.ru.nudemoon�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.nudemoon-v1.4.28.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.nudemoon.png"1.4(21.4.288B0��������X	Nude-Moonru"https://nude-moon.org
�
	ReadManga*eu.kanade.tachiyomi.extension.ru.readmanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.readmanga-v1.4.88.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.readmanga.png"1.4(X21.4.88B&	ReadMangaru"https://a.zazaza.me
�
RuMIX&eu.kanade.tachiyomi.extension.ru.rumix�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.rumix-v1.4.42.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.rumix.png"1.4(*21.4.42B'������§\RuMIXru"https://rumix.me
�
SeiManga)eu.kanade.tachiyomi.extension.ru.seimanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.seimanga-v1.4.41.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.seimanga.png"1.4()21.4.418B/���ɾ��WSeiMangaru"https://1.seimanga.me
�
	SelfManga*eu.kanade.tachiyomi.extension.ru.selfmanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.selfmanga-v1.4.63.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.selfmanga.png"1.4(?21.4.63B3������H	SelfMangaru"https://1.selfmanga.live
�

Senkognito+eu.kanade.tachiyomi.extension.ru.senkognito�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.senkognito-v1.4.12.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.senkognito.png"1.4(21.4.128B.���ڼ�پt
Senkognitoru"https://senkuro.me
�
Senkuro(eu.kanade.tachiyomi.extension.ru.senkuro�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.senkuro-v1.4.11.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.senkuro.png"1.4(21.4.11B+ì�ۂ���Senkuroru"https://senkuro.me
�
	UniComics*eu.kanade.tachiyomi.extension.ru.unicomics�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.unicomics-v1.4.10.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.unicomics.png"1.4(
21.4.10B/����呙_	UniComicsru"https://unicomics.ru
�
Usagi&eu.kanade.tachiyomi.extension.ru.usagi�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.usagi-v1.4.41.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.usagi.png"1.4()21.4.418B-�������OUsagiru"https://web.usagi.one/
�
YagamiProject.eu.kanade.tachiyomi.extension.ru.yagamiproject�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.yagamiproject-v1.4.6.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.yagamiproject.png"1.4(21.4.6B5��ձ��KYagamiProjectru"https://read.yagami.me
�
YaoiChan)eu.kanade.tachiyomi.extension.ru.yaoichan�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.yaoichan-v1.4.11.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.yaoichan.png"1.4(21.4.118B.��������"YaoiChanru"https://yaoi-chan.me
�
YaoiLib(eu.kanade.tachiyomi.extension.ru.yaoilib�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-ru.yaoilib-v1.4.47.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.ru.yaoilib.png"1.4(/21.4.478B.Ǐ����%YaoiLibru"https://v2.shlib.life
�
Cat300'eu.kanade.tachiyomi.extension.th.cat300�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.cat300-v1.4.53.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.cat300.png"1.4(521.4.538B+���㦋��TCat300th"https://cat-300.com
�
Catzaa'eu.kanade.tachiyomi.extension.th.catzaa�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.catzaa-v1.4.51.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.catzaa.png"1.4(321.4.518B*�Ĳ�����TCatzaath"https://catzaa.net
�
	Doodmanga*eu.kanade.tachiyomi.extension.th.doodmanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.doodmanga-v1.4.50.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.doodmanga.png"1.4(221.4.50B4ʚ�ߚ�<	Doodmangath"https://www.doodmanga.com
�
	Doujin-Lc)eu.kanade.tachiyomi.extension.th.doujinlc�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.doujinlc-v1.4.50.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.doujinlc.png"1.4(221.4.508B0���Ն��<	Doujin-Lcth"https://doujin-lc.net
�
Doujin Moon+eu.kanade.tachiyomi.extension.th.doujinmoon�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.doujinmoon-v1.4.32.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.doujinmoon.png"1.4( 21.4.32B3��ҥ��Doujin Moonth"https://doujinmoon.com
�
DoujinZa)eu.kanade.tachiyomi.extension.th.doujinza�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.doujinza-v1.4.50.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.doujinza.png"1.4(221.4.508B.��ߖ����3DoujinZath"https://doujinza.com
�
Ecchi-Doujin,eu.kanade.tachiyomi.extension.th.ecchidoujin�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.ecchidoujin-v1.4.32.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.ecchidoujin.png"1.4( 21.4.328B6�꛽����dEcchi-Doujinth"https://ecchi-doujin.com
�
	Fin Manga)eu.kanade.tachiyomi.extension.th.finmanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.finmanga-v1.4.32.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.finmanga.png"1.4( 21.4.328B4��������j	Fin Mangath"https://www.fin-manga.com
�

God-Doujin*eu.kanade.tachiyomi.extension.th.goddoujin�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.goddoujin-v1.4.32.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.goddoujin.png"1.4( 21.4.328B2�����ǿ�2
God-Doujinth"https://god-doujin.com
�
Go Manga(eu.kanade.tachiyomi.extension.th.gomanga�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.gomanga-v1.4.32.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.gomanga.png"1.4( 21.4.328B2ì���Ӂ�
Go Mangath"https://www.go-manga.com
�

Lami-Manga*eu.kanade.tachiyomi.extension.th.lamimanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.lamimanga-v1.4.33.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.lamimanga.png"1.4(!21.4.338B0ɓ��ǳ�
Lami-Mangath"https://mangalami.com
�

Makimaaaaa+eu.kanade.tachiyomi.extension.th.makimaaaaa�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.makimaaaaa-v1.4.32.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.makimaaaaa.png"1.4( 21.4.328B2���˲���T
Makimaaaaath"https://makimaaaaa.com
�
Manga168)eu.kanade.tachiyomi.extension.th.manga168�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.manga168-v1.4.34.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.manga168.png"1.4("21.4.348B/��������sManga168th"https://manga1688.com
�
MangaIsekaiThai0eu.kanade.tachiyomi.extension.th.mangaisekaithai�
shttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.mangaisekaithai-v1.4.51.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.mangaisekaithai.png"1.4(321.4.518B@�΅˱���MangaIsekaiThaith"https://www.mangaisekaithai.net
�
	MangaKimi*eu.kanade.tachiyomi.extension.th.mangakimi�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.mangakimi-v1.4.35.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.mangakimi.png"1.4(#21.4.358B4𑨋����	MangaKimith"https://www.mangakimi.com
�
Manga-Lc(eu.kanade.tachiyomi.extension.th.mangalc�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.mangalc-v1.4.50.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.mangalc.png"1.4(221.4.508B.۶��ע��MManga-Lcth"https://manga-lc.net
�
	Mangastep*eu.kanade.tachiyomi.extension.th.mangastep�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.mangastep-v1.4.32.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.mangastep.png"1.4( 21.4.328B0��������@	Mangastepth"https://mangastep.com
�
	ManhuaBug*eu.kanade.tachiyomi.extension.th.manhuabug�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.manhuabug-v1.4.50.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.manhuabug.png"1.4(221.4.50B4������ε	ManhuaBugth"https://www.manhuabug.com
�
	ManhuaKey*eu.kanade.tachiyomi.extension.th.manhuakey�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.manhuakey-v1.4.50.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.manhuakey.png"1.4(221.4.508B4�ϵ�����o	ManhuaKeyth"https://www.manhuakey.com
�

ManhuaThai+eu.kanade.tachiyomi.extension.th.manhuathai�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.manhuathai-v1.4.50.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.manhuathai.png"1.4(221.4.50B6к٤����m
ManhuaThaith"https://www.manhuathai.com
�
ManhwaBreakup.eu.kanade.tachiyomi.extension.th.manhwabreakup�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.manhwabreakup-v1.4.50.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.manhwabreakup.png"1.4(221.4.50B<�ᆜ�Œ�BManhwaBreakupth"https://www.manhwabreakup.com
�

MikuDoujin+eu.kanade.tachiyomi.extension.th.mikudoujin�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.mikudoujin-v1.4.7.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.mikudoujin.png"1.4(21.4.78B3��������+
MikuDoujinth"https://miku-doujin.com
�
Moodtoon)eu.kanade.tachiyomi.extension.th.moodtoon�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.moodtoon-v1.4.33.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.moodtoon.png"1.4(!21.4.338B/����Ƌ��vMoodtoonth"https://moon-toon.com
�
Nekopost)eu.kanade.tachiyomi.extension.th.nekopost�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.nekopost-v1.4.15.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.nekopost.png"1.4(21.4.158B2����Ǩ�<Nekopostth"https://www.nekopost.net
�
	Niceoppai*eu.kanade.tachiyomi.extension.th.niceoppai�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.niceoppai-v1.4.29.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.niceoppai.png"1.4(21.4.298B4��������k	Niceoppaith"https://www.niceoppai.net
�
	NTR-Manga)eu.kanade.tachiyomi.extension.th.ntrmanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.ntrmanga-v1.4.33.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.ntrmanga.png"1.4(!21.4.338B4���Ѱ��	NTR-Mangath"https://www.ntr-manga.net
�
OneManga)eu.kanade.tachiyomi.extension.th.onemanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.onemanga-v1.4.32.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.onemanga.png"1.4( 21.4.328B0��������	One-Mangath"https://one-manga.com
�
OreManga)eu.kanade.tachiyomi.extension.th.oremanga�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.oremanga-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.oremanga.png"1.4(21.4.18B2��������OreMangath"https://www.oremanga.net
�
	PopsManga*eu.kanade.tachiyomi.extension.th.popsmanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.popsmanga-v1.4.34.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.popsmanga.png"1.4("21.4.348B0��ʰ�G	PopsMangath"https://popsmanga.net
�
ReaperTrans,eu.kanade.tachiyomi.extension.th.reapertrans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.reapertrans-v1.4.32.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.reapertrans.png"1.4( 21.4.328B4㨽Ĕ���}ReaperTransth"https://reapertrans.com
�
	Singmanga*eu.kanade.tachiyomi.extension.th.singmanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.singmanga-v1.4.32.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.singmanga.png"1.4( 21.4.32B5�ݫ����	SingMangath"https://www.sing-manga.com
�

Slow Manga*eu.kanade.tachiyomi.extension.th.slowmanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.slowmanga-v1.4.33.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.slowmanga.png"1.4(!21.4.338B6��������6
Slow Mangath"https://www.slow-manga.net
�
Sodsaime)eu.kanade.tachiyomi.extension.th.sodsaime�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.sodsaime-v1.4.34.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.sodsaime.png"1.4("21.4.348BI�ѷ�����qสดใสเมะth""https://www.xn--l3c0azab5a2gta.com
�
Speed Manga+eu.kanade.tachiyomi.extension.th.speedmanga�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.speedmanga-v1.4.33.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.speedmanga.png"1.4(!21.4.338B4����Քȩ.Speed Mangath"https://speed-manga.net
�
Tanuki-Manga,eu.kanade.tachiyomi.extension.th.tanukimanga�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.tanukimanga-v1.4.33.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.tanukimanga.png"1.4(!21.4.338B:ַȍ����Tanuki-Mangath"https://www.tanuki-manga.net
�
ToomTam-Manga-eu.kanade.tachiyomi.extension.th.toomtammanga�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-th.toomtammanga-v1.4.32.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.th.toomtammanga.png"1.4( 21.4.328B8���ژᅤNToomTam-Mangath"https://toomtam-manga.com
�
Adonis Fansub-eu.kanade.tachiyomi.extension.tr.adonisfansub�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.adonisfansub-v1.4.51.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.adonisfansub.png"1.4(321.4.51B=����ꏰ�|Adonis Fansubtr"https://manga.adonisfansub.com
�
	Adu Manga)eu.kanade.tachiyomi.extension.tr.adumanga�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.adumanga-v1.4.31.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.adumanga.png"1.4(21.4.31B/�����溦	Adu Mangatr"https://adumanga.com
�
Afrodit Scans-eu.kanade.tachiyomi.extension.tr.afroditscans�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.afroditscans-v1.4.36.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.afroditscans.png"1.4($21.4.36B7��䢼��CAfrodit Scanstr"https://afroditscans.com
�
Alucard Scans-eu.kanade.tachiyomi.extension.tr.alucardscans�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.alucardscans-v1.4.31.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.alucardscans.png"1.4(21.4.31B7ӫ������7Alucard Scanstr"https://alucardscans.com
�
Amanga Planet-eu.kanade.tachiyomi.extension.tr.amangaplanet�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.amangaplanet-v1.4.33.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.amangaplanet.png"1.4(!21.4.338B>��ƿ����GAmanga Planettr"https://www.amangaplanet.com.tr
�
Anikiga(eu.kanade.tachiyomi.extension.tr.anikiga�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.anikiga-v1.4.50.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.anikiga.png"1.4(221.4.50B,������їoAnikigatr"https://anikiga.com
�
	ArazNovel*eu.kanade.tachiyomi.extension.tr.araznovel�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.araznovel-v1.4.54.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.araznovel.png"1.4(621.4.54B0���߀��f	ArazNoveltr"https://araznovel.com
�
Arcura Fansub-eu.kanade.tachiyomi.extension.tr.arcurafansub�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.arcurafansub-v1.4.32.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.arcurafansub.png"1.4( 21.4.328B7��ϴĂ��BArcura Fansubtr"https://arcurafansub.com
�
Armoni Scans,eu.kanade.tachiyomi.extension.tr.armoniscans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.armoniscans-v1.4.45.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.armoniscans.png"1.4(-21.4.45B5������cArmoni Scanstr"https://armoniscans.net
�
Asemi Fansub,eu.kanade.tachiyomi.extension.tr.asemifansub�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.asemifansub-v1.4.30.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.asemifansub.png"1.4(21.4.30B5񼛻����Asemi Fansubtr"https://asemifansub.com
�
Asura Scans TR-eu.kanade.tachiyomi.extension.tr.asurascanstr�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.asurascanstr-v1.4.50.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.asurascanstr.png"1.4(221.4.50B9���α��Asura Scans TRtr"https://asurascans.com.tr
�
Athena Manga,eu.kanade.tachiyomi.extension.tr.athenamanga�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.athenamanga-v1.4.30.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.athenamanga.png"1.4(21.4.30B5컧���ϠbAthena Mangatr"https://athenamanga.com
�
ÇaprazManga,eu.kanade.tachiyomi.extension.tr.caprazmanga�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.caprazmanga-v1.4.50.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.caprazmanga.png"1.4(221.4.50B5�湰��ĤeÇaprazMangatr"https://caprazmanga.com
�
DiamondFansub.eu.kanade.tachiyomi.extension.tr.diamondfansub�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.diamondfansub-v1.4.52.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.diamondfansub.png"1.4(421.4.52B8����۩�<DiamondFansubtr"https://diamondfansub.com
�
Domal Fansub,eu.kanade.tachiyomi.extension.tr.domalfansub�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.domalfansub-v1.4.54.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.domalfansub.png"1.4(621.4.548B8������݊Domal Fansubtr"https://dom4lfansub.online
�
Elder Manga+eu.kanade.tachiyomi.extension.tr.eldermanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.eldermanga-v1.4.8.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.eldermanga.png"1.4(21.4.8B3�����ܥ�KElder Mangatr"https://eldermanga.com
�
Eski Mangalar-eu.kanade.tachiyomi.extension.tr.eskimangalar�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.eskimangalar-v1.4.5.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.eskimangalar.png"1.4(21.4.5B7�������Eski Mangalartr"https://eskimangalar.com
�
gafeland)eu.kanade.tachiyomi.extension.tr.gafeland�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.gafeland-v1.4.32.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.gafeland.png"1.4( 21.4.32B.ɋ������-gafelandtr"https://gafeland.com
�
Gaiatoon)eu.kanade.tachiyomi.extension.tr.gaiatoon�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.gaiatoon-v1.4.32.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.gaiatoon.png"1.4( 21.4.32B.�����ՙfGaiatoontr"https://gaiatoon.com
�
Garcia Manga,eu.kanade.tachiyomi.extension.tr.garciamanga�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.garciamanga-v1.4.50.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.garciamanga.png"1.4(221.4.50B5�狺ӗ�DGarcia Mangatr"https://garciamanga.com
�
GhosToon,eu.kanade.tachiyomi.extension.tr.ghosthentai�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.ghosthentai-v1.4.51.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.ghosthentai.png"1.4(321.4.518B.�������pGhosToontr"https://ghostoon.com
�
Gölge Bahçesi-eu.kanade.tachiyomi.extension.tr.golgebahcesi�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.golgebahcesi-v1.4.33.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.golgebahcesi.png"1.4(!21.4.33B9��ל����gGölge Bahçesitr"https://golgebahcesi.com
�
Hattori Manga-eu.kanade.tachiyomi.extension.tr.hattorimanga�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.hattorimanga-v1.4.44.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.hattorimanga.png"1.4(,21.4.448B7��ť����Hattori Mangatr"https://hattorimanga.net
�

Hayalistic+eu.kanade.tachiyomi.extension.tr.hayalistic�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.hayalistic-v1.4.55.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.hayalistic.png"1.4(721.4.55B3�������
Hayalistictr"https://hayalistic.blog
�

Holy Scans*eu.kanade.tachiyomi.extension.tr.holyscans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.holyscans-v1.4.51.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.holyscans.png"1.4(321.4.518B4�����ޠ�N
Holy Scanstr"https://holyscans.com.tr
�
Seraph Manga.eu.kanade.tachiyomi.extension.tr.hyperionscans�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.hyperionscans-v1.4.30.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.hyperionscans.png"1.4(21.4.30B9��Ą����Seraph Mangatr"https://www.seraphmanga.com
�
Kabus Manga+eu.kanade.tachiyomi.extension.tr.kabusmanga�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.kabusmanga-v1.4.50.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.kabusmanga.png"1.4(221.4.508B3���Ŕ��Kabus Mangatr"https://kabusmanga.com
�
Koreli Scans,eu.kanade.tachiyomi.extension.tr.koreliscans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.koreliscans-v1.4.51.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.koreliscans.png"1.4(321.4.51B5�̆����Koreli Scanstr"https://www.nabicix.com
�
Kuroi Manga+eu.kanade.tachiyomi.extension.tr.kuroimanga�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.kuroimanga-v1.4.54.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.kuroimanga.png"1.4(621.4.548B7�㾃���yKuroi Mangatr"https://www.kuroimanga.mom
�
Lavinia Fansub.eu.kanade.tachiyomi.extension.tr.laviniafansub�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.laviniafansub-v1.4.55.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.laviniafansub.png"1.4(721.4.558B9������Ӱ-Lavinia Fansubtr"https://laviniafansub.pro
�
LilyumFansub-eu.kanade.tachiyomi.extension.tr.lilyumfansub�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.lilyumfansub-v1.4.50.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.lilyumfansub.png"1.4(221.4.50B9�猭����zLilyumFansubtr"https://lilyumfansub.com.tr
�
Limon Manga+eu.kanade.tachiyomi.extension.tr.limonmanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.limonmanga-v1.4.5.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.limonmanga.png"1.4(21.4.5B3�ŏ��ӵ�mLimon Mangatr"https://limonmanga.com
�

Luna Scans*eu.kanade.tachiyomi.extension.tr.lunascans�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.lunascans-v1.4.52.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.lunascans.png"1.4(421.4.528B2̦����؀a
Luna Scanstr"https://tuhafscans.com
�
MangaDenizi,eu.kanade.tachiyomi.extension.tr.mangadenizi�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.mangadenizi-v1.4.7.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.mangadenizi.png"1.4(21.4.7B8���̂��GMangaDenizitr"https://www.mangadenizi.net
�
Mangadusleri-eu.kanade.tachiyomi.extension.tr.mangadusleri�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.mangadusleri-v1.4.32.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.mangadusleri.png"1.4( 21.4.328B6ʨԓ��ɃUMangadusleritr"https://mangadusleri.lol
�
MangaGezgini-eu.kanade.tachiyomi.extension.tr.mangagezgini�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.mangagezgini-v1.4.59.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.mangagezgini.png"1.4(;21.4.59B9���Ϥ��ZMangaGezginitr"https://mangagezgini.online
�
Manga Kings+eu.kanade.tachiyomi.extension.tr.mangakings�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.mangakings-v1.4.31.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.mangakings.png"1.4(21.4.31B6����恑�`Manga Kingstr"https://mangakings.com.tr
�

Manga Kusu*eu.kanade.tachiyomi.extension.tr.mangakusu�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.mangakusu-v1.4.33.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.mangakusu.png"1.4(!21.4.33B1ޏ��˩��Y
Manga Kusutr"https://mangakusu.com
�
Manga Oku TR+eu.kanade.tachiyomi.extension.tr.mangaokutr�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.mangaokutr-v1.4.30.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.mangaokutr.png"1.4(21.4.30B4����Ŷ��0Manga Oku TRtr"https://mangaokutr.net
�
Manga Şehri+eu.kanade.tachiyomi.extension.tr.mangasehri�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.mangasehri-v1.4.51.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.mangasehri.png"1.4(321.4.518B5ֆ瑱���
Manga Şehritr"https://manga-sehri.com
�
Manga Şehri.net.eu.kanade.tachiyomi.extension.tr.mangasehrinet�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.mangasehrinet-v1.4.51.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.mangasehrinet.png"1.4(321.4.518B9��Ó����!Manga Şehri.nettr"https://manga-sehri.net
�
Manga Bahçesi*eu.kanade.tachiyomi.extension.tr.mangaship�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.mangaship-v1.4.4.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.mangaship.png"1.4(21.4.48B8Ԏ������bManga Bahçesitr"https://mangabahcesi.com
�
MangaTilkisi-eu.kanade.tachiyomi.extension.tr.mangatilkisi�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.mangatilkisi-v1.4.52.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.mangatilkisi.png"1.4(421.4.52B8��Ϭ��ȢMangaTilkisitr"https://www.tilkiscans.com
�
Manga-TR(eu.kanade.tachiyomi.extension.tr.mangatr�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.mangatr-v1.4.23.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.mangatr.png"1.4(21.4.238B.�����EManga-TRtr"https://manga-tr.com
�
MangaWOW)eu.kanade.tachiyomi.extension.tr.mangawow�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.mangawow-v1.4.50.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.mangawow.png"1.4(221.4.50B.��������#MangaWOWtr"https://mangawow.org
�
MangaWT(eu.kanade.tachiyomi.extension.tr.mangawt�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.mangawt-v1.4.53.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.mangawt.png"1.4(521.4.53B,��􅋑��}MangaWTtr"https://mangawt.com
�
	MangaZure*eu.kanade.tachiyomi.extension.tr.mangazure�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.mangazure-v1.4.50.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.mangazure.png"1.4(221.4.50B0�������F	MangaZuretr"https://mangazure.net
�
Mangitto)eu.kanade.tachiyomi.extension.tr.mangitto�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.mangitto-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.mangitto.png"1.4(21.4.18B-��ᖷ���>Mangittotr"https://mangtto.com
�
Merlin Scans,eu.kanade.tachiyomi.extension.tr.merlinscans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.merlinscans-v1.4.37.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.merlinscans.png"1.4(%21.4.37B4�����І�CMerlin Scanstr"https://merlintoon.com
�
Mikrokosmos Fansub2eu.kanade.tachiyomi.extension.tr.mikrokosmosfansub�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.mikrokosmosfansub-v1.4.14.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.mikrokosmosfansub.png"1.4(21.4.148BF�Ӝ�����Mikrokosmos Fansubtr""https://mikrokosmosfb.blogspot.com
�
MilaSub(eu.kanade.tachiyomi.extension.tr.milasub�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.milasub-v1.4.53.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.milasub.png"1.4(521.4.538B2���ћ���NMilaSubtr"https://www.millascan.com
�
Moon Daisy Scans/eu.kanade.tachiyomi.extension.tr.moondaisyscans�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.moondaisyscans-v1.4.37.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.moondaisyscans.png"1.4(%21.4.378B=�㺼��%Moon Daisy Scanstr"https://moondaisyscans.site
�
Nemesis scans-eu.kanade.tachiyomi.extension.tr.nemesisscans�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.nemesisscans-v1.4.32.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.nemesisscans.png"1.4( 21.4.32B6ᛱ��ķ�<Nemesisscanstr"https://nemesisscans.com
�
Nirvana Manga-eu.kanade.tachiyomi.extension.tr.nirvanamanga�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.nirvanamanga-v1.4.32.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.nirvanamanga.png"1.4( 21.4.32B7��������&Nirvana Mangatr"https://nirvanamanga.com
�
Nivera Fansub-eu.kanade.tachiyomi.extension.tr.niverafansub�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.niverafansub-v1.4.53.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.niverafansub.png"1.4(521.4.538B7޼������5Nivera Fansubtr"https://niverafansub.lol
�
OkuToon(eu.kanade.tachiyomi.extension.tr.okutoon�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.okutoon-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.okutoon.png"1.4(21.4.18B,��������SOkuToontr"https://okutoon.com
�
Opiatoon)eu.kanade.tachiyomi.extension.tr.opiatoon�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.opiatoon-v1.4.53.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.opiatoon.png"1.4(521.4.538B.�őꍐ�Opiatoontr"https://opiatoon.lat
�
Paradox Scans-eu.kanade.tachiyomi.extension.tr.paradoxscans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.paradoxscans-v1.4.5.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.paradoxscans.png"1.4(21.4.5B7�ݭ���3Paradox Scanstr"https://paradoxscans.com
�

Pati Manga*eu.kanade.tachiyomi.extension.tr.patimanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.patimanga-v1.4.32.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.patimanga.png"1.4( 21.4.32B5єЈ���U
Pati Mangatr"https://www.patimanga.com
�
Ragnar Scans,eu.kanade.tachiyomi.extension.tr.ragnarscans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.ragnarscans-v1.4.49.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.ragnarscans.png"1.4(121.4.49B5���Դē�Ragnar Scanstr"https://ragnarscans.com
�
Raindrop Fansub/eu.kanade.tachiyomi.extension.tr.raindropfansub�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.raindropfansub-v1.4.32.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.raindropfansub.png"1.4( 21.4.32B@ߚ����ERaindrop Fansubtr"https://www.raindropteamfan.com
�
Rüya Manga*eu.kanade.tachiyomi.extension.tr.ruyamanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.ruyamanga-v1.4.54.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.ruyamanga.png"1.4(621.4.54B7绐ź���PRüya Mangatr"https://www.ruyamanga2.com
�
Rüya Manga.net-eu.kanade.tachiyomi.extension.tr.ruyamanganet�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.ruyamanganet-v1.4.50.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.ruyamanganet.png"1.4(221.4.50B6����ڀ�LRüya Manga.nettr"https://ruyamanga.net
�
Sadscans)eu.kanade.tachiyomi.extension.tr.sadscans�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.sadscans-v1.4.3.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.sadscans.png"1.4(21.4.3B.�������wSadscanstr"https://sadscans.com
�
Serein Scan+eu.kanade.tachiyomi.extension.tr.sereinscan�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.sereinscan-v1.4.32.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.sereinscan.png"1.4( 21.4.32B3㸨�����Serein Scantr"https://sereinscan.com
�
Shadow Çeviri-eu.kanade.tachiyomi.extension.tr.shadowceviri�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.shadowceviri-v1.4.13.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.shadowceviri.png"1.4(21.4.13BAЃ������5Shadow Çeviritr"!https://shadowceviri.blogspot.com
�
Shijie Scans,eu.kanade.tachiyomi.extension.tr.shijiescans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.shijiescans-v1.4.33.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.shijiescans.png"1.4(!21.4.33B5���ե��Shijie Scanstr"https://shijiescans.com
�
Siyah Melek+eu.kanade.tachiyomi.extension.tr.siyahmelek�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.siyahmelek-v1.4.64.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.siyahmelek.png"1.4(@21.4.648B3�ܰ�����3Siyah Melektr"https://siyahmelek.vip
�
Stray Fansub,eu.kanade.tachiyomi.extension.tr.strayfansub�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.strayfansub-v1.4.54.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.strayfansub.png"1.4(621.4.548B5���؅���hStray Fansubtr"https://strayfansub.net
�

SummerToon+eu.kanade.tachiyomi.extension.tr.summertoon�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.summertoon-v1.4.52.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.summertoon.png"1.4(421.4.52B3��������
SummerToontr"https://summertoons.net
�
Sunset Manga,eu.kanade.tachiyomi.extension.tr.sunsetmanga�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.sunsetmanga-v1.4.50.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.sunsetmanga.png"1.4(221.4.508B5��������XSunset Mangatr"https://sunsetmanga.com
�
Tarot Scans+eu.kanade.tachiyomi.extension.tr.tarotscans�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.tarotscans-v1.4.32.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.tarotscans.png"1.4( 21.4.32B7��駚��oTarot Scanstr"https://www.tarotscans.com
�
Tempest Scans-eu.kanade.tachiyomi.extension.tr.tempestscans�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.tempestscans-v1.4.33.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.tempestscans.png"1.4(!21.4.33B8��̗����ITempest Scanstr"https://tempestmangas.com
�
Tenshi Manga,eu.kanade.tachiyomi.extension.tr.tenshimanga�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.tenshimanga-v1.4.7.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.tenshimanga.png"1.4(21.4.7B5�����ث�QTenshi Mangatr"https://tenshimanga.com
�

TonizuToon+eu.kanade.tachiyomi.extension.tr.tonizutoon�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.tonizutoon-v1.4.53.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.tonizutoon.png"1.4(521.4.538B.��՘���H
TonizuToontr"https://tonizu.top
�
Tortuga Ceviri.eu.kanade.tachiyomi.extension.tr.tortugaceviri�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.tortugaceviri-v1.4.52.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.tortugaceviri.png"1.4(421.4.52B9��������Tortuga Ceviritr"https://tortugaceviri.com
�
Tr Manga(eu.kanade.tachiyomi.extension.tr.trmanga�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.trmanga-v1.4.2.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.trmanga.png"1.4(21.4.28B,譒��dTrMangatr"https://trmanga.com
�
Türkçe Manga Oku/eu.kanade.tachiyomi.extension.tr.turkcemangaoku�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.turkcemangaoku-v1.4.51.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.turkcemangaoku.png"1.4(321.4.51B:ߐ朞���Türkçe Manga Okutr"https://trmangaoku.com
�
Turkce Manga Oku TR1eu.kanade.tachiyomi.extension.tr.turkcemangaokutr�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.turkcemangaokutr-v1.4.50.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.turkcemangaokutr.png"1.4(221.4.508BD�����Ӡ;Türkçe Manga Oku TRtr"https://turkcemangaoku.com.tr
�
Turkmangaoku-eu.kanade.tachiyomi.extension.tr.turkmangaoku�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.turkmangaoku-v1.4.32.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.turkmangaoku.png"1.4( 21.4.328B6夾�����3Turkmangaokutr"https://turkmangaoku.com
�

Uzay Manga*eu.kanade.tachiyomi.extension.tr.uzaymanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.uzaymanga-v1.4.47.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.uzaymanga.png"1.4(/21.4.47B1��������
Uzay Mangatr"https://uzaymanga.com
�
Webtoon Hatti-eu.kanade.tachiyomi.extension.tr.webtoonhatti�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.webtoonhatti-v1.4.57.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.webtoonhatti.png"1.4(921.4.57B8�������{Webtoon Hattitr"https://webtoonhatti.club
�

Webtoon TR*eu.kanade.tachiyomi.extension.tr.webtoontr�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.webtoontr-v1.4.52.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.webtoontr.png"1.4(421.4.528B1��ف��ǣ 
Webtoon TRtr"https://webtoontr.net
�
Yaoibar(eu.kanade.tachiyomi.extension.tr.yaoibar�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.yaoibar-v1.4.51.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.yaoibar.png"1.4(321.4.518B,��˲����%Yaoibartr"https://yaoibar.lol
�
	Yaoi Flix)eu.kanade.tachiyomi.extension.tr.yaoiflix�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.yaoiflix-v1.4.56.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.yaoiflix.png"1.4(821.4.568B/�襚�ۍ�~	Yaoi Flixtr"https://yaoiflix.fit
�
Yaoi Manga Oku-eu.kanade.tachiyomi.extension.tr.yaoimangaoku�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.yaoimangaoku-v1.4.51.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.yaoimangaoku.png"1.4(321.4.518B8�������9Yaoi Manga Okutr"https://yaoimangaoku.net
�
Zenith Scans,eu.kanade.tachiyomi.extension.tr.zenithscans�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-tr.zenithscans-v1.4.32.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.tr.zenithscans.png"1.4( 21.4.32B5��������Zenith Scanstr"https://zenithscans.com
�
DGManga(eu.kanade.tachiyomi.extension.uk.dgmanga�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-uk.dgmanga-v1.4.2.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.uk.dgmanga.png"1.4(21.4.28B,�������qDGMangauk"https://dgmanga.app
�
Faust&eu.kanade.tachiyomi.extension.uk.faust�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-uk.faust-v1.4.1.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.uk.faust.png"1.4(21.4.18B,�������:Faustuk"https://faust-web.com
�

HoneyManga+eu.kanade.tachiyomi.extension.uk.honeymanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-uk.honeymanga-v1.4.8.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.uk.honeymanga.png"1.4(21.4.88B6���䠀˳A
HoneyMangauk"https://honey-manga.com.ua
�
	MangaInUa*eu.kanade.tachiyomi.extension.uk.mangainua�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-uk.mangainua-v1.4.11.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.uk.mangainua.png"1.4(21.4.118B0������ƨgMANGA/in/UAuk"https://manga.in.ua
�
Zenko&eu.kanade.tachiyomi.extension.uk.zenko�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-uk.zenko-v1.4.7.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.uk.zenko.png"1.4(21.4.78B+¯�ө���uZenkouk"https://zenko.online
�
Ariverse)eu.kanade.tachiyomi.extension.vi.ariverse�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.ariverse-v1.4.53.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.ariverse.png"1.4(521.4.538B+��ʈ���>Ariversevi"https://arigl.xyz
�
BaoTangTruyen.eu.kanade.tachiyomi.extension.vi.baotangtruyen�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.baotangtruyen-v1.4.2.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.baotangtruyen.png"1.4(21.4.2B:���ά���kBaoTangTruyenvi"https://baotangtruyen37.top
�
CManga'eu.kanade.tachiyomi.extension.vi.cmanga�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.cmanga-v1.4.3.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.cmanga.png"1.4(21.4.3B-ٻ�љ���RCMangavi"https://cmangax17.com
�
CuuTruyen (unoriginal)-eu.kanade.tachiyomi.extension.vi.cuutruyenmoe�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.cuutruyenmoe-v1.4.2.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.cuutruyenmoe.png"1.4(21.4.28B=��������7CuuTruyen (unoriginal)vi"https://cuutruyen.moe
�

DamCoNuong+eu.kanade.tachiyomi.extension.vi.damconuong�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.damconuong-v1.4.5.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.damconuong.png"1.4(21.4.58B2��躓���%
DamCoNuongvi"https://damconuong.lol
�
	DaoMeoDen*eu.kanade.tachiyomi.extension.vi.daomeoden�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.daomeoden-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.daomeoden.png"1.4(21.4.28B0��������2	DaoMeoDenvi"https://daomeoden.net
�
DocTruyen3Q,eu.kanade.tachiyomi.extension.vi.doctruyen3q�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.doctruyen3q-v1.4.33.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.doctruyen3q.png"1.4(!21.4.338B8������UDocTruyen3Qvi"https://doctruyen3qhub.live
�
DocTruyen5s,eu.kanade.tachiyomi.extension.vi.doctruyen5s�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.doctruyen5s-v1.4.8.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.doctruyen5s.png"1.4(21.4.8B0�����iDocTruyen5svi"https://manga.io.vn
�
Dua Leo Truyen-eu.kanade.tachiyomi.extension.vi.dualeotruyen�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.dualeotruyen-v1.4.20.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.dualeotruyen.png"1.4(21.4.208B=�њ�ł��Dưa Leo Truyệnvi"https://dualeotruyenpy.com
�
FastScan)eu.kanade.tachiyomi.extension.vi.fastscan�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.fastscan-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.fastscan.png"1.4(21.4.2B.��������<FastScanvi"https://fastscan.org
�
Goc Truyen Tranh/eu.kanade.tachiyomi.extension.vi.goctruyentranh�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.goctruyentranh-v1.4.12.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.goctruyentranh.png"1.4(21.4.128B:�Ո����qGocTruyenTranhvi"https://goctruyentranh.com
�
Goc Truyen Tranh Vui2eu.kanade.tachiyomi.extension.vi.goctruyentranhvui�
uhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.goctruyentranhvui-v1.4.15.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.goctruyentranhvui.png"1.4(21.4.15BEƲ��֣��'Goc Truyen Tranh Vuivi"https://goctruyentranhvui30.com
�

HangTruyen+eu.kanade.tachiyomi.extension.vi.hangtruyen�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.hangtruyen-v1.4.4.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.hangtruyen.png"1.4(21.4.48B2�ʷ���ϳ$
HangTruyenvi"https://hangtruyen.app
�
HanulTruyen,eu.kanade.tachiyomi.extension.vi.hanultruyen�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.hanultruyen-v1.4.51.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.hanultruyen.png"1.4(321.4.518B5���ǚ���HanulTruyenvi"https://hanultruyen.info
�
CBHentai+eu.kanade.tachiyomi.extension.vi.hentaicube�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.hentaicube-v1.4.81.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.hentaicube.png"1.4(Q21.4.818B,ƶ���҉�CBHentaivi"https://2tencb.pro
�
HentaiVN.plus-eu.kanade.tachiyomi.extension.vi.hentaivnplus�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.hentaivnplus-v1.4.68.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.hentaivnplus.png"1.4(D21.4.688B4�͔�£��aHentaiVN.plusvi"https://hentaivn.show
�
	HentaiVNx*eu.kanade.tachiyomi.extension.vi.hentaivnx�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.hentaivnx-v1.4.5.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.hentaivnx.png"1.4(21.4.58B4����烎I	HentaiVNxvi"https://www.hentaivnx.com
�
	KamiComic*eu.kanade.tachiyomi.extension.vi.kamicomic�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.kamicomic-v1.4.4.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.kamicomic.png"1.4(21.4.48B/��͓�θ�C	KamiComicvi"https://kamicomi.com
�
KiraKira)eu.kanade.tachiyomi.extension.vi.kirakira�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.kirakira-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.kirakira.png"1.4(21.4.2B0���ڄ҉]KiraKiravi"https://truyenkira.com
�
	LoppyToon*eu.kanade.tachiyomi.extension.vi.loppytoon�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.loppytoon-v1.4.5.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.loppytoon.png"1.4(21.4.58B0���͉���[	LoppyToonvi"https://loppytoon.com
�

LuotTruyen+eu.kanade.tachiyomi.extension.vi.luottruyen�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.luottruyen-v1.4.3.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.luottruyen.png"1.4(21.4.38B3�����錅[
LuotTruyenvi"https://luottruyen7.com
�

LuvEvaLand+eu.kanade.tachiyomi.extension.vi.luvevaland�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.luvevaland-v1.4.2.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.luvevaland.png"1.4(21.4.28B3�������E
LuvEvaLandvi"https://luvevalands2.co
�
LXManga)eu.kanade.tachiyomi.extension.vi.lxhentai�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.lxhentai-v1.4.31.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.lxhentai.png"1.4(21.4.318B.�Ύ���ǒZLXMangavi"https://lxmanga.space
�
MangaVN(eu.kanade.tachiyomi.extension.vi.mangavn�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.mangavn-v1.4.2.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.mangavn.png"1.4(21.4.2B,��������qMangaVNvi"https://mangavn.top
�

ManhuaRock+eu.kanade.tachiyomi.extension.vi.manhuarock�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.manhuarock-v1.4.18.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.manhuarock.png"1.4(21.4.18B4��񀸷��P
ManhuaRockvi"https://manhuarock4.site
�
MeDamTruyen,eu.kanade.tachiyomi.extension.vi.medamtruyen�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.medamtruyen-v1.4.7.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.medamtruyen.png"1.4(21.4.78B5����ϱ��MeDamTruyenvi"https://saytongtaii.site
�
MeHentai)eu.kanade.tachiyomi.extension.vi.mehentai�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.mehentai-v1.4.11.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.mehentai.png"1.4(21.4.118B/�㣦����MeHentaivi"https://mehentai.blog
�
MeoSSS'eu.kanade.tachiyomi.extension.vi.meosss�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.meosss-v1.4.1.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.meosss.png"1.4(21.4.18B*������޸]MeoSSSvi"https://meosss.com
�
MeoSua'eu.kanade.tachiyomi.extension.vi.meosua�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.meosua-v1.4.2.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.meosua.png"1.4(21.4.28B*Џ�ʎ���MeoSuavi"https://meosua.com
�
MiMi%eu.kanade.tachiyomi.extension.vi.mimi�
ghttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.mimi-v1.4.6.apkuhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.mimi.png"1.4(21.4.68B)񘪲ռ��#MiMivi"https://mimimoe.moe
�

MiMiHentai+eu.kanade.tachiyomi.extension.vi.mimihentai�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.mimihentai-v1.4.6.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.mimihentai.png"1.4(21.4.68B2�������o
MiMiHentaivi"https://mimihentai.net
�

MinoTruyen+eu.kanade.tachiyomi.extension.vi.minotruyen�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.minotruyen-v1.4.3.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.minotruyen.png"1.4(21.4.38B:ޞ���΋�MinoTruyen Mangavi"https://minotruyenv5.xyzB;ޥ������4MinoTruyen Comicsvi"https://minotruyenv5.xyzB;���сɲQMinoTruyen Hentaivi"https://minotruyenv5.xyz
�
	MoeTruyen*eu.kanade.tachiyomi.extension.vi.moetruyen�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.moetruyen-v1.4.6.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.moetruyen.png"1.4(21.4.6B0����ی��x	MoeTruyenvi"https://moetruyen.net
�

MoonTruyen+eu.kanade.tachiyomi.extension.vi.moontruyen�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.moontruyen-v1.4.2.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.moontruyen.png"1.4(21.4.28B2���ŕ���]
MoonTruyenvi"https://moontruyen.com
�
	MunTruyen*eu.kanade.tachiyomi.extension.vi.muntruyen�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.muntruyen-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.muntruyen.png"1.4(21.4.28B.�ޛ����t	MunTruyenvi"https://munhihi.icu
�
NetTruyenCO (unoriginal),eu.kanade.tachiyomi.extension.vi.nettruyenco�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.nettruyenco-v1.4.16.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.nettruyenco.png"1.4(21.4.16BA�������1NetTruyenCO (unoriginal)vi"https://nettruyenar.com
�
NetTruyenS (unoriginal)+eu.kanade.tachiyomi.extension.vi.nettruyens�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.nettruyens-v1.4.2.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.nettruyens.png"1.4(21.4.28BA��ࣂ��TNetTruyenS (unoriginal)vi"https://nettruyen10s.com
�
NetTruyenViet (unoriginal).eu.kanade.tachiyomi.extension.vi.nettruyenviet�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.nettruyenviet-v1.4.2.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.nettruyenviet.png"1.4(21.4.2BG��ћ쇀�7NetTruyenViet (unoriginal)vi"https://nettruyenviet10.com
�
NetTruyenX (unoriginal)+eu.kanade.tachiyomi.extension.vi.nettruyenx�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.nettruyenx-v1.4.8.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.nettruyenx.png"1.4(21.4.8B?��������+NetTruyenX (unoriginal)vi"https://nettruyenx.net
�
NewTruyenTranh/eu.kanade.tachiyomi.extension.vi.newtruyentranh�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.newtruyentranh-v1.4.7.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.newtruyentranh.png"1.4(21.4.7B<��������(NewTruyenTranhvi"https://newtruyentranh10.com
�

NhatTruyen+eu.kanade.tachiyomi.extension.vi.nhattruyen�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.nhattruyen-v1.4.29.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.nhattruyen.png"1.4(21.4.29B4�Ԃ�Ȼ�_
NhatTruyenvi"https://nhattruyenqq.com
�
NhentaiClub,eu.kanade.tachiyomi.extension.vi.nhentaiclub�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.nhentaiclub-v1.4.2.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.nhentaiclub.png"1.4(21.4.28B6��ȟ���~NhentaiClubvi"https://nhentaiclub.space
�
Otakusic)eu.kanade.tachiyomi.extension.vi.otakusic�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.otakusic-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.otakusic.png"1.4(21.4.28B.��ςĭ��AOtakusicvi"https://otakusic.com
�
OTruyen(eu.kanade.tachiyomi.extension.vi.otruyen�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.otruyen-v1.4.2.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.otruyen.png"1.4(21.4.2B+���Ӑ�ŀpOTruyenvi"https://otruyen.cc
�
Panomic(eu.kanade.tachiyomi.extension.vi.panomic�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.panomic-v1.4.3.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.panomic.png"1.4(21.4.38B.���Ԯ﬘KPanomicvi"https://panomic1.info
�
	SayHentai*eu.kanade.tachiyomi.extension.vi.sayhentai�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.sayhentai-v1.4.22.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.sayhentai.png"1.4(21.4.228B/��������<	SayHentaivi"https://sayhentai.sh
�
Seikowo(eu.kanade.tachiyomi.extension.vi.seikowo�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.seikowo-v1.4.2.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.seikowo.png"1.4(21.4.28B9��������*Seikowovi" https://seikowo-app.blogspot.com
�
SoaiCaComic,eu.kanade.tachiyomi.extension.vi.soaicacomic�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.soaicacomic-v1.4.3.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.soaicacomic.png"1.4(21.4.38B5���ջ�ŉSoaiCaComicvi"https://soaicacomic2.top
�
Team Lanh Lung-eu.kanade.tachiyomi.extension.vi.teamlanhlung�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.teamlanhlung-v1.4.32.apk}https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.teamlanhlung.png"1.4( 21.4.328B7��������Team Lạnh Lùngvi"https://lunghihi.icu
�
ThienThaiTruyen0eu.kanade.tachiyomi.extension.vi.thienthaitruyen�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.thienthaitruyen-v1.4.3.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.thienthaitruyen.png"1.4(21.4.38B=����׸�=ThienThaiTruyenvi"https://thienthaitruyen9.com
�

Top Truyen*eu.kanade.tachiyomi.extension.vi.toptruyen�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.toptruyen-v1.4.36.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.toptruyen.png"1.4($21.4.368B:�ڱ����
Top Truyenvi"https://www.toptruyenzone3.com
�
Tranh18(eu.kanade.tachiyomi.extension.vi.tranh18�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.tranh18-v1.4.5.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.tranh18.png"1.4(21.4.58B+���˿���Tranh18vi"https://tranh18.cc
�
Truyen18)eu.kanade.tachiyomi.extension.vi.truyen18�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.truyen18-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.truyen18.png"1.4(21.4.28B-���˟鳵gTruyen18vi"https://truyen18.co
�
	FoxTruyen)eu.kanade.tachiyomi.extension.vi.truyengg�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.truyengg-v1.4.13.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.truyengg.png"1.4(21.4.13B1��݌��؟	FoxTruyenvi"https://foxtruyen2.com
�
Truyen Hentai 18+/eu.kanade.tachiyomi.extension.vi.truyenhentai18�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.truyenhentai18-v1.4.11.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.truyenhentai18.png"1.4(21.4.118B?�̹�Ƭ��YTruyện Hentai 18+vi"https://truyenhentai18.net
�
TruyenHentaivn/eu.kanade.tachiyomi.extension.vi.truyenhentaivn�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.truyenhentaivn-v1.4.3.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.truyenhentaivn.png"1.4(21.4.38B:�������"TruyenHentaivnvi"https://truyenhentaivn.lol
�
TruyenHentaiz.eu.kanade.tachiyomi.extension.vi.truyenhentaiz�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.truyenhentaiz-v1.4.2.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.truyenhentaiz.png"1.4(21.4.28B8��կƲcTruyenHentaizvi"https://truyenhentaiz.net
�
TruyenMM)eu.kanade.tachiyomi.extension.vi.truyenmm�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.truyenmm-v1.4.2.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.truyenmm.png"1.4(21.4.28B2��Ѻ���ATruyenMMvi"https://truyenmmhayr.com
�
TruyenQQ)eu.kanade.tachiyomi.extension.vi.truyenqq�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.truyenqq-v1.4.24.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.truyenqq.png"1.4(21.4.24B0�������#TruyenQQvi"https://truyenqqko.com
�
TruyenTranh3Q.eu.kanade.tachiyomi.extension.vi.truyentranh3q�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.truyentranh3q-v1.4.9.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.truyentranh3q.png"1.4(	21.4.98B3�θ�����yTruyenTranh3Qvi"https://manhua3q.com
�
Truyen tranh dam my1eu.kanade.tachiyomi.extension.vi.truyentranhdammy�
thttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.truyentranhdammy-v1.4.53.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.truyentranhdammy.png"1.4(521.4.538BH��ֶ����4Truyện tranh đam mỹvi"https://truyentranhdammyy.site
�
TruyenTuoiTho.eu.kanade.tachiyomi.extension.vi.truyentuoitho�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.truyentuoitho-v1.4.52.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.truyentuoitho.png"1.4(421.4.52B8��Ϗ����TruyenTuoiThovi"https://truyentuoitho.com
�
	TruyenTVN*eu.kanade.tachiyomi.extension.vi.truyentvn�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.truyentvn-v1.4.2.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.truyentvn.png"1.4(21.4.28B0֋������.	TruyenTVNvi"https://truyentvn.net
�
TruyenVN)eu.kanade.tachiyomi.extension.vi.truyenvn�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.truyenvn-v1.4.67.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.truyenvn.png"1.4(C21.4.678B.��褥���OTruyenVNvi"https://truyenvn.sbs
�
	TuiTruyen*eu.kanade.tachiyomi.extension.vi.tuitruyen�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.tuitruyen-v1.4.3.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.tuitruyen.png"1.4(21.4.3B0��������=	TuiTruyenvi"https://tuitruyen.top
�
TuSachXinhXinh/eu.kanade.tachiyomi.extension.vi.tusachxinhxinh�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.tusachxinhxinh-v1.4.3.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.tusachxinhxinh.png"1.4(21.4.38B?��������{TuSachXinhXinhvi"https://tusachxinhxinh12.online
�
	UmeTruyen*eu.kanade.tachiyomi.extension.vi.umetruyen�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.umetruyen-v1.4.9.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.umetruyen.png"1.4(	21.4.98B1�ⷌ�ډ�"	UmeTruyenvi"https://umetruyenz.org
�
Ung Ty Comics,eu.kanade.tachiyomi.extension.vi.ungtycomics�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.ungtycomics-v1.4.4.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.ungtycomics.png"1.4(21.4.48B:ꓐ̧��\Ưng Tỷ Comicsvi"https://ungtycomicsa.com
�
Vcomycs(eu.kanade.tachiyomi.extension.vi.vcomycs�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.vcomycs-v1.4.7.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.vcomycs.png"1.4(21.4.78B0��������MVcomycsvi"https://vivicomi19.info
�
ViHentai)eu.kanade.tachiyomi.extension.vi.vihentai�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.vihentai-v1.4.4.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.vihentai.png"1.4(21.4.48B/歿�����7ViHentaivi"https://vi-hentai.moe
�

VinaHentai+eu.kanade.tachiyomi.extension.vi.vinahentai�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.vinahentai-v1.4.8.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.vinahentai.png"1.4(21.4.88B3߱��ψ��?
VinaHentaivi"https://vinahentai.bond
�

VlogTruyen+eu.kanade.tachiyomi.extension.vi.vlogtruyen�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.vlogtruyen-v1.4.29.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.vlogtruyen.png"1.4(21.4.298B4��������Y
VlogTruyenvi"https://vlogtruyen69.com
�

YuriGarden+eu.kanade.tachiyomi.extension.vi.yurigarden�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.yurigarden-v1.4.9.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.yurigarden.png"1.4(	21.4.98B2���ʥ���
YuriGardenvi"https://yurigarden.moe
�
YuriNeko)eu.kanade.tachiyomi.extension.vi.yurineko�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.yurineko-v1.4.6.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.yurineko.png"1.4(21.4.68B/Ғ����=YuriNekovi"https://yurinekoz.com
�
	ZetTruyen*eu.kanade.tachiyomi.extension.vi.zettruyen�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-vi.zettruyen-v1.4.7.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.vi.zettruyen.png"1.4(21.4.7B6�ڎ���γ	ZetTruyenvi"https://www.zettruyen.today
�
Baimangu (Darpou))eu.kanade.tachiyomi.extension.zh.baimangu�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.baimangu-v1.4.5.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.baimangu.png"1.4(21.4.5B2��������Z	百漫谷zh"https://www.darpou.com/
�
Baka Manhua'eu.kanade.tachiyomi.extension.zh.bakamh�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.bakamh-v1.4.59.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.bakamh.png"1.4(;21.4.598B0��ߞĪ��3巴卡漫画zh"https://bakamh.com
�
Baozi Manhua,eu.kanade.tachiyomi.extension.zh.baozimanhua�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.baozimanhua-v1.4.28.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.baozimanhua.png"1.4(21.4.28B4㣪��O包子漫画zh"https://cn.baozimh.com
�
GoDa+eu.kanade.tachiyomi.extension.zh.baozimhorg�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.baozimhorg-v1.4.35.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.baozimhorg.png"1.4(#21.4.35B�����̓��

GoDa漫画zh"{https://baozimh.org#, https://godamh.com#, https://m.baozimh.one#, https://bzmh.org#, https://g-mh.org#, https://m.g-mh.org
�
BH3$eu.kanade.tachiyomi.extension.zh.bh3�
fhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.bh3-v1.4.4.apkthttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.bh3.png"1.4(21.4.4B9홤�����R《崩坏3》IP站zh"https://comic.bh3.com
�
	BiliManga*eu.kanade.tachiyomi.extension.zh.bilimanga�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.bilimanga-v1.4.10.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.bilimanga.png"1.4(
21.4.108B8����ȏ�eBilimanga.netzh"https://www.bilimanga.net
�
BoyLove(eu.kanade.tachiyomi.extension.zh.boylove�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.boylove-v1.4.17.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.boylove.png"1.4(21.4.178B3��É���香香腐宅zh"https://boylove1.mobi
�
	Cartoon18*eu.kanade.tachiyomi.extension.zh.cartoon18�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.cartoon18-v1.4.4.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.cartoon18.png"1.4(21.4.48B3��Ϡ���2	Cartoon18zh"https://www.cartoon18.com
�
Comicabc)eu.kanade.tachiyomi.extension.zh.comicabc�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.comicabc-v1.4.3.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.comicabc.png"1.4(21.4.3B4�ݰ፷��p無限動漫zh"https://www.8comic.com
�
Creative Comic Collection.eu.kanade.tachiyomi.extension.zh.creativecomic�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.creativecomic-v1.4.2.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.creativecomic.png"1.4(21.4.2B@��ʕ����sCCC追漫台zh-Hant"https://www.creative-comic.tw
�
Dm5$eu.kanade.tachiyomi.extension.zh.dm5�
fhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.dm5-v1.4.9.apkthttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.dm5.png"1.4(	21.4.98B-����˃��	动漫屋zh"https://www.dm5.cn
�
Dongman Manhua.eu.kanade.tachiyomi.extension.zh.dongmanmanhua�
phttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.dongmanmanhua-v1.4.6.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.dongmanmanhua.png"1.4(21.4.6BA�ԗ���:Dongman Manhuazh-Hans"https://www.dongmanmanhua.cn
�
Dumanwu(eu.kanade.tachiyomi.extension.zh.dumanwu�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.dumanwu-v1.4.2.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.dumanwu.png"1.4(21.4.2B1��������c	读漫屋zh"https://m.dumanwu1.com
�
18Manhua/eu.kanade.tachiyomi.extension.zh.eighteenmanhua�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.eighteenmanhua-v1.4.3.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.eighteenmanhua.png"1.4(21.4.38B*��͡�̯�O18漫画zh"https://18mh.org
�
FavComic)eu.kanade.tachiyomi.extension.zh.favcomic�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.favcomic-v1.4.1.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.favcomic.png"1.4(21.4.18B6�ߣ�����喜漫漫画zh"https://www.favcomic.com
�
Hanime1(eu.kanade.tachiyomi.extension.zh.hanime1�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.hanime1-v1.4.2.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.hanime1.png"1.4(21.4.28B0��澧���'
Hanime1.mezh"https://hanimeone.me
�
HANMAN18)eu.kanade.tachiyomi.extension.zh.hanman18�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.hanman18-v1.4.3.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.hanman18.png"1.4(21.4.38B.���ɷ���FHANMAN18zh"https://hanman18.com
�
Happymh(eu.kanade.tachiyomi.extension.zh.happymh�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.happymh-v1.4.24.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.happymh.png"1.4(21.4.24B3�Ŕ�����Z嗨皮漫画zh"https://m.happymh.com
�
H-Comic'eu.kanade.tachiyomi.extension.zh.hcomic�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.hcomic-v1.4.1.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.hcomic.png"1.4(21.4.18B,��Ѫ�H-Comiczh"https://h-comic.com
�
Shenshi Huisuo+eu.kanade.tachiyomi.extension.zh.hentaiclub�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.hentaiclub-v1.4.2.apk{https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.hentaiclub.png"1.4(21.4.28B8�������w绅士会所zh"https://www.hentaiclub.net
�
Iqiyi&eu.kanade.tachiyomi.extension.zh.iqiyi�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.iqiyi-v1.4.4.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.iqiyi.png"1.4(21.4.4BB޻������爱奇艺叭嗒zh-Hans"https://www.iqiyi.com/manhua
�
JComic'eu.kanade.tachiyomi.extension.zh.jcomic�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.jcomic-v1.4.1.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.jcomic.png"1.4(21.4.18B*��������aJComiczh"https://jcomic.net
�
Jinman Tiantang/eu.kanade.tachiyomi.extension.zh.jinmantiantang�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.jinmantiantang-v1.4.57.apkhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.jinmantiantang.png"1.4(921.4.578B1�ݨ���W禁漫天堂zh"https://18comic.vip
�
92Manhua,eu.kanade.tachiyomi.extension.zh.jiuermanhua�
ohttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.jiuermanhua-v1.4.14.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.jiuermanhua.png"1.4(21.4.148B-ꥻ���׍92漫画zh"http://www.92mh.com
�
Komiic'eu.kanade.tachiyomi.extension.zh.komiic�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.komiic-v1.4.7.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.komiic.png"1.4(21.4.78B*�����ÀKomiiczh"https://komiic.com
�
Kuaikanmanhua.eu.kanade.tachiyomi.extension.zh.kuaikanmanhua�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.kuaikanmanhua-v1.4.12.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.kuaikanmanhua.png"1.4(21.4.12B@Ň��ۣ��p快看漫画zh-Hans"https://www.kuaikanmanhua.com
�
Mangabz(eu.kanade.tachiyomi.extension.zh.mangabz�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.mangabz-v1.4.14.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.mangabz.png"1.4(21.4.14BY�¦�����HMangabzzh"@https://mangabz.com#, https://xmanhua.com#, https://yymanhua.com
�
Manga Xiao Si,eu.kanade.tachiyomi.extension.zh.mangaxiaosi�
nhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.mangaxiaosi-v1.4.1.apk|https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.mangaxiaosi.png"1.4(21.4.18B5��ҋ����Manga Xiao Sizh"https://www.jjmhw2.top
�
YKMH*eu.kanade.tachiyomi.extension.zh.manhuadui�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.manhuadui-v1.4.32.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.manhuadui.png"1.4( 21.4.328B2��Ó���优酷漫画zh"https://www.ykmh.net
�
	ManHuaGui*eu.kanade.tachiyomi.extension.zh.manhuagui�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.manhuagui-v1.4.28.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.manhuagui.png"1.4(21.4.288B4ݓ��݊�a	漫画柜zh"https://www.manhuagui.com
�
	Manhuaren*eu.kanade.tachiyomi.extension.zh.manhuaren�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.manhuaren-v1.4.18.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.manhuaren.png"1.4(21.4.18B8��ڙ���2	漫画人zh"http://mangaapi.manhuaren.com
�
	Manhuashe*eu.kanade.tachiyomi.extension.zh.manhuashe�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.manhuashe-v1.4.1.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.manhuashe.png"1.4(21.4.1B/�������V	漫画社zh"https://www.311s.com
�
Manhuawu)eu.kanade.tachiyomi.extension.zh.manhuawu�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.manhuawu-v1.4.9.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.manhuawu.png"1.4(	21.4.9B0�����ٚ�-	漫画屋zh"https://www.mhua5.com
�
Manwa&eu.kanade.tachiyomi.extension.zh.manwa�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.manwa-v1.4.14.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.manwa.png"1.4(21.4.148B(�������漫蛙zh"https://manwa.me
�
MH1234'eu.kanade.tachiyomi.extension.zh.mh1234�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.mh1234-v1.4.3.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.mh1234.png"1.4(21.4.3B1���Ɉ���m
漫画1234zh"https://m.wmh1234.com
�
Miaoqu Manhua'eu.kanade.tachiyomi.extension.zh.miaoqu�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.miaoqu-v1.4.8.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.miaoqu.png"1.4(21.4.8B6��������喵趣漫画zh"https://www.miaoqumh.org
�
MyComic(eu.kanade.tachiyomi.extension.zh.mycomic�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.mycomic-v1.4.4.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.mycomic.png"1.4(21.4.48B,��������~MyComiczh"https://mycomic.com
�
NoyAcg'eu.kanade.tachiyomi.extension.zh.noyacg�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.noyacg-v1.4.4.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.noyacg.png"1.4(21.4.48B3Ũ�톃��mNoyAcgzh"https://beta.noyteam.online
�
	COLAMANGA*eu.kanade.tachiyomi.extension.zh.onemanhua�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.onemanhua-v1.4.26.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.onemanhua.png"1.4(21.4.268B4��򩍜��r	COLAMANGAzh"https://www.colamanga.com
�
	Picacomic*eu.kanade.tachiyomi.extension.zh.picacomic�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.picacomic-v1.4.8.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.picacomic.png"1.4(21.4.88B;�ݪ讗ІP哔咔漫画zh"https://picaapi.picacomic.com
�
Roumanwu)eu.kanade.tachiyomi.extension.zh.roumanwu�
lhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.roumanwu-v1.4.18.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.roumanwu.png"1.4(21.4.188B-�͝�޼��2	肉漫屋zh"https://roum22.xyz
�
Rumanhua)eu.kanade.tachiyomi.extension.zh.rumanhua�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.rumanhua-v1.4.5.apkyhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.rumanhua.png"1.4(21.4.5B2������	如漫画zh"https://m.rumanhua2.com
�
6Manhua&eu.kanade.tachiyomi.extension.zh.sixmh�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.sixmh-v1.4.16.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.sixmh.png"1.4(21.4.168B4�����߷�G	六漫画zh"https://www.liumanhua.com
�
Tencent Comics (ac.qq.com).eu.kanade.tachiyomi.extension.zh.tencentcomics�
qhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.tencentcomics-v1.4.10.apk~https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.tencentcomics.png"1.4(
21.4.108B6���Ʈ���X腾讯动漫zh-Hans"https://m.ac.qq.com
�
Terra Historicus0eu.kanade.tachiyomi.extension.zh.terrahistoricus�
rhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.terrahistoricus-v1.4.4.apk�https://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.terrahistoricus.png"1.4(21.4.4B=�¢���?泰拉记事社zh"https://comic.hypergryph.com
�
Tongli'eu.kanade.tachiyomi.extension.zh.tongli�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.tongli-v1.4.1.apkwhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.tongli.png"1.4(21.4.18B3��������L東立zh"https://ebook.tongli.com.tw
�
Toptoon.net(eu.kanade.tachiyomi.extension.zh.toptoon�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.toptoon-v1.4.1.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.toptoon.png"1.4(21.4.18B6�ƒ���ܨTOPTOON頂通zh"https://www.toptoon.net
�
vomic&eu.kanade.tachiyomi.extension.zh.vomic�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.vomic-v1.4.6.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.vomic.png"1.4(21.4.6B-����򕀛.vomiczh"http://www.vomicmh.com
�
WNACG&eu.kanade.tachiyomi.extension.zh.wnacg�
ihttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.wnacg-v1.4.23.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.wnacg.png"1.4(21.4.238B`��������Z紳士漫畫zh"Bhttps://www.wn05.ru#, https://www.wn04.ru#, https://www.wnacg05.cc
�

Yidan Girl&eu.kanade.tachiyomi.extension.zh.yidan�
hhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.yidan-v1.4.5.apkvhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.yidan.png"1.4(21.4.58B1��ɑ����!一耽女孩zh"https://yidan1.club
�
	Zaimanhua*eu.kanade.tachiyomi.extension.zh.zaimanhua�
mhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.zaimanhua-v1.4.18.apkzhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.zaimanhua.png"1.4(21.4.18B7��̿���	再漫画zh"https://manhua.zaimanhua.com
�
Zazhimi(eu.kanade.tachiyomi.extension.zh.zazhimi�
jhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.zazhimi-v1.4.2.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.zazhimi.png"1.4(21.4.2B2������Y	杂志迷zh"https://www.zazhimi.net
�
Zerobyw(eu.kanade.tachiyomi.extension.zh.zerobyw�
khttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/apk/tachiyomi-zh.zerobyw-v1.4.21.apkxhttps://raw.githubusercontent.com/keiyoushi/extensions/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.zh.zerobyw.png"1.4(21.4.218B7杂��ܘ�yzero搬运网zh"http://www.zerobywai.com